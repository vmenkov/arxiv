package edu.cornell.cs.osmot.reranker;

import java.util.Hashtable;
import java.io.IOException;

import org.apache.lucene.search.*;
import org.apache.lucene.document.*;

import edu.cornell.cs.osmot.options.*;
import edu.cornell.cs.osmot.searcher.*;

public class OriginalScores {

	private String shortFields[];
	private Hashtable origScores; 
	private Hashtable docAges;
	
	private edu.cornell.cs.osmot.searcher.Searcher searcher;
	
	OriginalScores(edu.cornell.cs.osmot.searcher.Searcher srch) {
		origScores = new Hashtable();
		docAges = new Hashtable();
		searcher = srch;
		shortFields = searcher.getFieldsShort();
	}
	
	/**
	 * Gets the age of the document with this docId, caching for speed.
	 * @param s  Unique identifier of the document we want the age of
	 * @return The age of the document (in days)
	 * @throws IOException
	 */
	public int getAge(String s) throws IOException {
				
		Integer age = (Integer)docAges.get(s);
		if (age == null) {
			ScoredDocument sd = searcher.getDoc(s);
			if (sd != null)
				age = new Integer(searcher.getDoc(s).getAge("date"));
			else
				age = new Integer(-1);
			
			docAges.put(s, age);
		}
		
		return age.intValue();
	}
	
	/**
	 * Gets the scores for this document and query
	 * 
	 * @param q
	 * @param doc
	 * @return The scores for each field for this document and query
	 * @throws IOException
	 */
	public double[] getScores(String q, String doc) throws IOException {
		
		Hashtable docFeatures = getDocFeatures(q, doc);

		double scores[] = new double[shortFields.length];

		for (int j=0; j<scores.length; j++) {
			if (docFeatures != null)
				scores[j] = ((Double)docFeatures.get("SCORE-"+shortFields[j])).doubleValue();
			else
				scores[j] = 0;
		}
		
		return scores;
	} 

	/**
	 * Gets the ranks for this document and query
	 * 
	 * @param q
	 * @param doc
	 * @return The rank of this doc for each field for this query
	 * @throws IOException
	 */
	public int[] getRanks(String q, String doc) throws IOException {
		
		Hashtable docFeatures = getDocFeatures(q, doc);
				
		int scores[] = new int[shortFields.length];

		for (int j=0; j<scores.length; j++) {
			if (docFeatures != null)
				scores[j] = ((Integer)docFeatures.get("RANK-"+shortFields[j])).intValue();
			else
				scores[j] = 0;
		}
		
		return scores;
	} 
	
	
	/**
	 * Gets the hash table with features for this document.
	 * 
	 * @param q
	 * @param doc
	 * @return The Hashtable with all the query related features for this document.
	 * @throws IOException
	 */
	private Hashtable getDocFeatures(String q, String doc) throws IOException {
		
		// See if we have the scores for this query
		Hashtable htQuery = (Hashtable)origScores.get(q);

		// If nothing for this query - make an entry for scores
		if (htQuery == null)
			htQuery = new Hashtable();
			
		// See if we have the score for this document
		Hashtable htFeatures = (Hashtable)htQuery.get(doc);
				
		// If nothing for this document, look up the hits
		if (htFeatures == null) {
			
			// See if we have the hits for this query
			Hits[] hits = (Hits[])htQuery.get("HITS");
			
			// If not, make the hits
			if (hits == null) {
				hits = searcher.origHits(q);
				htQuery.put("HITS", hits);
			}
				
			// Features for this document
			htFeatures = new Hashtable();
				
			// For each field, search until we find the document
			for (int j=0; j<shortFields.length; j++) {
				boolean cont = true;
				int rank = 0;

				// No results for this field, so score and rank known
				if (hits[j] == null || hits[j].length() == 0) {
					htFeatures.put("SCORE-"+shortFields[j], new Double(0));
					htFeatures.put("RANK-"+shortFields[j], new Integer(-1));							
					cont = false;
				}
			 	
				while(rank < hits[j].length() && cont) {
					
					// Get the next hit
					Document d = hits[j].doc(rank);
					String uniqId = d.get(Options.get("UNIQ_ID_FIELD"));

					// If we found the document, great
					if (uniqId.equals(doc)) {
						htFeatures.put("SCORE-"+shortFields[j], new Double(hits[j].score(rank)));
						htFeatures.put("RANK-"+shortFields[j], new Integer(rank));
						cont = false;
					}
					
					// If we haven't found the document, try to look one more
					if (cont) {
						rank++;

						// Document not found
						if (rank >= hits[j].length()) {
							htFeatures.put("SCORE-"+shortFields[j], new Double(0));
							htFeatures.put("RANK-"+shortFields[j], new Integer(-1));							
							cont = false;
						}
					} // End of if we are continuing
				} // End of while loop on cont				
			} // End of for loop on all the fields
			
			// Save the feature for this document
			htQuery.put(doc, htFeatures);
			
			// We have update the query, so save it too
			origScores.put(q, htQuery);
			
		} // End of if this document is missing
		
		return htFeatures;
	}
}
