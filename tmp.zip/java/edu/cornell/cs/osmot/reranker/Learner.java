package edu.cornell.cs.osmot.reranker;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.IOException;

import java.util.Hashtable;
import java.util.Arrays;
import java.util.Enumeration;

import edu.cornell.cs.osmot.logger.*;
import edu.cornell.cs.osmot.searcher.*;
import edu.cornell.cs.osmot.options.Options;

import org.apache.lucene.queryParser.ParseException;

// If we need origHits
//import org.apache.lucene.search.Hits;

/**
 * This class implements learning from log files as described in Radlinski, F
 * and Joachims T, Query Chains: Learning to Rank from Implicit Feedback, 2005.
 * 
 * @author Filip Radlinski
 * @version 1.0, May 2005
 */
public class Learner {

	private static String docFile = "";

	private static String labelFile = "";

	private static Searcher searcher = null;

	private static boolean debug = false;
	
	private static FeatureConverter fc;
	private static String fields[];
	
	// These define the score features (to replace rank features). The values
	// must be in decreasing order!
    public static double scoreThresholds[] = { 
    	10, 9.5, 9, 8.5, 8, 7.5, 7, 6.5, 6, 5.75, 5.5, 5.25,
        5.0, 4.75, 4.5, 4.25, 4, 3.8, 3.6, 3.4, 3.2,
        3.0, 2.8, 2.6, 2.5, 2.4, 2.3, 2.2, 2.1,
        2.0, 1.9, 1.8, 1.7, 1.6,
        1.5, 1.45, 1.4, 1.35, 1.3, 1.25, 1.2, 1.15, 1.1, 1.05,
        1.0, 0.95, 0.9, 0.85, 0.8, 0.75, 0.7, 0.65,
        0.6, 0.575, 0.55, 0.525,
        0.5, 0.48, 0.46, 0.44, 0.42,
        0.4, 0.38, 0.36, 0.34, 0.32,
        0.3, 0.28, 0.26, 0.24, 0.22,
        0.2, 0.19, 0.18, 0.17, 0.16, 0.15, 0.14, 0.13, 0.12, 0.11,
        0.1, 0.095, 0.09, 0.085, 0.08, 0.075, 0.07,
        0.065, 0.06, 0.055, 0.05, 0.045, 0.04, 0.035, 0.03, 0.025,
        0.02, 0.015, 0.01, 0};

	/**
	 * Check a preference is valid, if the topic is given (for modelling only).
	 * This is a bit of a hack, but is rarely used.
	 */
	public static void checkPreference(String unclicked, String clicked,
			int topic) throws IOException {

		// Keep a copy of the modelled data around
		if (searcher == null
				&& Options.get("SEARCHER_TYPE").equals("ModelSearcher")) {
			Logger.log("Opening model searcher with docs from " + docFile
					+ " and labels from " + labelFile);
			searcher = new ModelSearcher(docFile, labelFile);
		}

		if (searcher == null) {
			Logger.log("Error: Can't call checkPreference for searchers other than the ModelSearcher");
			return;
		}

		// Look up the relevance of the clicked and unclicked documents.
		String topicLine = searcher.getDoc(unclicked).getDoc().get("topics");
		String tokens[] = topicLine.split(" ");
		double uRel = 0;
		for (int i = 0; i < tokens.length; i++) {
			String parts[] = tokens[i].split(":");
			if (parts.length == 2 && Integer.parseInt(parts[0]) == topic)
				uRel = Double.parseDouble(parts[1]);
		}
		topicLine = searcher.getDoc(clicked).getDoc().get("topics");
		tokens = topicLine.split(" ");
		double cRel = 0;
		for (int i = 0; i < tokens.length; i++) {
			String parts[] = tokens[i].split(":");
			if (parts.length == 2 && Integer.parseInt(parts[0]) == topic)
				cRel = Double.parseDouble(parts[1]);
		}

		// Print out the verdict.
		if (cRel > uRel) {
			System.out.println("Preference VALID.   (Topic " + topic
					+ "; cRel " + clicked + " is " + cRel + "; uRel "
					+ unclicked + " is " + uRel);
		} else if (cRel == uRel) {
			System.out.println("Preference NEUTRAL. (Topic " + topic
					+ "; cRel " + clicked + " is " + cRel + "; uRel "
					+ unclicked + " is " + uRel);
		} else {
			System.out.println("Preference INVALID. (Topic " + topic
					+ "; cRel " + clicked + " is " + cRel + "; uRel "
					+ unclicked + " is " + uRel);
		}

	}

	/**
	 * Create a preference file from a log, as well as a feature mapping
	 * file. Preference generated according to FairPairsQC methodology.
	 * 
	 * @param selectClause
	 * 			  Lets you process only a subset of the log
	 * @param prefFile
	 *            The file where the preferences should be written.
	 * @param useChains
	 *            If true, the preferences will use query chains.
	 * @param humanReadable
	 *            If true, the features are not converted into feature ids
	 */
	public static void clicksToPrefsFairPairs(QueryEntry qe[], String mode,
			String prefFile, boolean useChains, boolean humanReadable)
			throws IOException, ParseException {

		// Don't run with query chains.
		if (useChains) {
			Logger.log("WARNING: clicksToPrefsFairPairs called with query chains. NOT ENABLED.");
			useChains = false;
		}
		
		String c;
		BufferedWriter out;

		// Load the feature list
		fc = new FeatureConverter(Options.get("RERANKER_FEATURE_FILE"));

		// Open the output file
		if (debug)
			Logger.log("FP version. Opening " + prefFile + " for output.");
		out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(
				prefFile)));

		// Make a searcher
		Searcher s;
		if (debug)
			Logger.log("Making a searcher at " + Options.get("INDEX_DIRECTORY"));
		if (Options.get("SEARCHER_TYPE").equals("ModelSearcher"))
			s = new ModelSearcher(docFile, labelFile);
		else if (Options.get("SEARCHER_TYPE").equals("LuceneSearcher"))
			s = new LuceneSearcher(Options.get("INDEX_DIRECTORY"));
		else if (Options.get("SEARCHER_TYPE").equals("NutchSearcher"))
			s = new NutchSearcher(Options.get("INDEX_DIRECTORY"));
		else {
			// We need to create a searcher so we can look up original results
			// when
			// generating preferences. If you wrote your own searcher, add a
			// call to
			// make a new searcher here.
			Logger.log("Error: Don't know how to generate preferences for this type of searcher. Edit clicksToPreferences in Learner.java to fix it (should be easy)");
			return;
		}

		fields = s.getFieldsShort();
		if (debug) {
			System.out.print("Original Score Fields: ");
			for (int i=0; i < fields.length; i++)
				System.out.print(fields[i]+"\t");
			System.out.println("");
		}
			
		OriginalScores os = new OriginalScores(s);
		
		// For every query
		for (int i = 0; i < qe.length; i++) {

			// Look up the original results for this query, so we can
			// look up the original ranks quickly.
			if (debug) {
				Logger.log("Query " + i + ": " + qe[i].getQuery());
				Logger.log("  " + qe[i].getNumClicks() + " clicks.");
			}

			// If something was clicked on, generate the one-query preferences
			if (qe[i].getNumClicks() > 0) {
				if (debug)
					Logger.log("Making one query comparisons:");
				//c = makeComparisonFairPairs(qe[i], qe[i], false, qe[i]
				//		.getQuery(), origHits, s,
				//		humanReadable, pairOffset);
				c = makeComparisonFairPairsFast(qe[i], os, humanReadable);
				out.write(c);
			}

			/* 
			 * FairPairs was never implemented with QueryChains. One day, maybe.
			 * This is a non-working template.
			 *
			// For every other query, if we want query chains
			for (int j = i + 1; useChains && j < qe.length; j++) {

				// If within half an hour and same IP
				if (qe[i].getIP().equals(qe[j].getIP())
						&& qe[j].getTime() - qe[i].getTime() < 30 * 60 * 1000) {

					if (debug)
						Logger.log("Query " + j + " is same chain: "
								+ qe[j].getQuery());

					// Every clicked link in the later one is better
					// than every non-clicked link in the earlier one.
					c = makeComparisonFairPairs(qe[j], qe[i], true, qe[i]
							.getQuery(), origResults, origScores, s,
							humanReadable, pairOffset);
					out.write(c);

					// Print out the one query results for the second
					// query results with repsect to the first query.
					c = makeComparisonFairPairs(qe[j], qe[j], false, qe[i]
							.getQuery(), origResults, origScores, s,
							humanReadable, pairOffset);
					
					makeComparisonFast(qe[j],qe[j], false, qe[i].getQuery(), os, s, humanReadable);
					out.write(c);

				}
			}
			*/			
		}

		out.close();

		// Save the features again
		fc.saveFeatures(Options.get("RERANKER_FEATURE_FILE"));
	}

	/**
	 * Create a preference file from a log file, as well as a feature mapping
	 * file. Preferences generated as per Radlinski & Joachims, KDD 2005.
	 * 
	 * @param logFile
	 *            The log file to parse.
	 * @param prefFile
	 *            The file where the preferences should be written.
	 * @param useChains
	 *            If true, the preferences will use query chains.
	 */
	public static void clicksToPrefs(QueryEntry qe[], String prefFile,
			boolean useChains) throws IOException, ParseException {
		clicksToPrefs(qe, prefFile, useChains, false);
	}

	/**
	 * Create a preference file from a log file, as well as a feature mapping
	 * file. Preferences generated as per Radlinski & Joachims, KDD 2005.
	 * 
	 * @param qe  
	 *            The queries, sorted by date.
	 * @param prefFile
	 *            The file where the preferences should be written.
	 * @param useChains
	 *            If true, the preferences will use query chains.
	 * @param humanReadable
	 *            If true, the features are not converted into feature ids
	 */
	public static void clicksToPrefs(QueryEntry qe[], String prefFile,
			boolean useChains, boolean humanReadable)
			throws IOException, ParseException {

		// Note: We assume the QueryEntries are sorted by date!
		
		String c;
		BufferedWriter out;

		// Load the feature list
		fc = new FeatureConverter(Options.get("RERANKER_FEATURE_FILE"));

		// Open the output file
		if (debug)
			Logger.log("Opening " + prefFile + " for output.");
		out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(
				prefFile)));

		// Make a searcher
		Searcher s;
		if (Options.get("SEARCHER_TYPE").equals("ModelSearcher"))
			s = new ModelSearcher(docFile, labelFile);
		else if (Options.get("SEARCHER_TYPE").equals("LuceneSearcher"))
			s = new LuceneSearcher(Options.get("INDEX_DIRECTORY"));
		else if (Options.get("SEARCHER_TYPE").equals("NutchSearcher"))
			s = new NutchSearcher(Options.get("INDEX_DIRECTORY"));
		else {
			// We need to create a searcher so we can look up original results
			// when
			// generating preferences. If you wrote your own searcher, add a
			// call to
			// make a new searcher here.
			Logger.log("Error: Don't know how to generate preferences for this type of searcher. Edit clicksToPreferences in Learner.java to fix it (should be easy)");
			return;
		}

		OriginalScores os = new OriginalScores(s);
		
		fields = s.getFieldsShort();

		// For every query
		for (int i = 0; i < qe.length; i++) {

			// Look up the original results for this query, so we can
			// look up the original ranks quickly.
			if (debug) {
				Logger.log("Query " + i + ": " + qe[i].getQuery());
				Logger.log("  " + qe[i].getNumClicks() + " clicks.");
			}

			// Used to use this, now we use OriginalScores as a parameter to look
			// up individual documents.
			//Hits[] origHits = s.origHits(qe[i].getQuery());

			// If something was clicked on, generate the one-query preferences
			if (qe[i].getNumClicks() > 0) {
				if (debug)
					Logger.log("Making one query comparisons:");
				c = makeComparisonFast(qe[i], qe[i], false, qe[i].getQuery(),
						os, s, humanReadable);
				out.write(c);
			}

			if (useChains)
				Logger.log("Making two query comparisons.");
			
			// For every other query, if we want query chains
			for (int j = i + 1; useChains && j < qe.length; j++) {

				// If within half an hour and same IP
				if (qe[i].getIP().equals(qe[j].getIP())
						&& qe[j].getTime() - qe[i].getTime() < 30 * 60 * 1000) {

					if (debug)
						Logger.log("Query " + j + " is same chain: "
								+ qe[j].getQuery());

					// Every clicked link in the later one is better
					// than every non-clicked link in the earlier one.
					c = makeComparisonFast(qe[j], qe[i], true, qe[i].getQuery(),
							os, s, humanReadable);
					out.write(c);

					// Print out the one query results for the second
					// query results with repsect to the first query.
					c = makeComparisonFast(qe[j], qe[j], false, qe[i].getQuery(),
							os, s, humanReadable);
					out.write(c);
				}
			}
		}

		out.close();

		// Save the features again
		if (debug)
			Logger.log("Saving features.");
		fc.saveFeatures(Options.get("RERANKER_FEATURE_FILE"));
	}

	/**
	 * Create a preference file as per Radlinski & Joachims, KDD 2005.
	 * 
	 * @param logFile
	 *            The log file to parse.
	 * @param prefFile
	 *            The file where the preferences should be written.
	 * @param useChains
	 *            If true, the preferences will use query chains.
	 * @param humanReadable
	 *            If true, the features are not converted into feature ids
	 * @param debug
	 *            If true, log more debugging info
	 */
	public static void clicksToPrefs(QueryEntry qe[], String prefFile,
			boolean useChains, boolean fairPairs, boolean humanReadable)
			throws IOException, ParseException {

		// NOTE: THIS IS THE NEW VERSION!
		
		String c;
		BufferedWriter out;
		
		// Load the feature list
		fc = new FeatureConverter(Options.get("RERANKER_FEATURE_FILE"));

		// Open the output file
		Logger.log("Opening " + prefFile + " for output.");
		out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(
				prefFile)));

		// Make a searcher
		Searcher s;
		if (Options.get("SEARCHER_TYPE").equals("ModelSearcher"))
			s = new ModelSearcher(docFile, labelFile);
		else if (Options.get("SEARCHER_TYPE").equals("LuceneSearcher"))
			s = new LuceneSearcher(Options.get("INDEX_DIRECTORY"));
		else if (Options.get("SEARCHER_TYPE").equals("NutchSearcher"))
			s = new NutchSearcher(Options.get("INDEX_DIRECTORY"));
		else {
			// We need to create a searcher so we can look up original results
			// when
			// generating preferences. If you wrote your own searcher, add a
			// call to
			// make a new searcher here.
			Logger.log("Error: Don't know how to generate preferences for this type of searcher. Edit clicksToPreferences in Learner.java to fix it (should be easy)");
			return;
		}

		fields = s.getFieldsShort();

		if (fairPairs) {
			// FairPairs Version
			
			// For every query
			for (int i = 0; i < qe.length; i++) {

				// Here we cache scores for individual results as we get them.
				OriginalScores os = new OriginalScores(s);				

				if (debug) Logger.log("Query " + i + ": " + qe[i].getQuery() + ". " + qe[i].getNumClicks() + " clicks.");

				// If something was clicked on, generate the one-query preferences
				if (qe[i].getNumClicks() > 0) {
					
					c = makeComparisonFairPairsFast(qe[i], os, humanReadable);
					out.write(c);
				}
			} // End of loop over all queries

		} else {
			// Not FairPairs

			// For every query
			for (int i = 0; i < qe.length; i++) {
	
				// Here we cache scores for individual results as we get them.
				OriginalScores os = new OriginalScores(s);
				
				if (debug) Logger.log("Query " + i + ": " + qe[i].getQuery() + ". " + qe[i].getNumClicks() + " clicks.");
	
				// If something was clicked on, generate the one-query preferences
				if (qe[i].getNumClicks() > 0) {
					if (debug)
						Logger.log("Making one query comparisons:");
					c = makeComparisonFast(qe[i], qe[i], false, qe[i].getQuery(),
							os, s, humanReadable);
					out.write(c);
				}
	
				// For every other query, if we want query chains
				for (int j = i + 1; useChains && j < qe.length; j++) {
					
					// If within half an hour and same IP
					if (qe[i].getIP().equals(qe[j].getIP())
							&& qe[j].getTime() - qe[i].getTime() < 30 * 60 * 1000) {
	
						if (debug)
							Logger.log("Query " + j + " is same chain: "
									+ qe[j].getQuery());
	
						// Every clicked link in the later one is better
						// than every non-clicked link in the earlier one.
						c = makeComparisonFast(qe[j], qe[i], true, qe[i].getQuery(),
								os, s, humanReadable);
						out.write(c);
	
						// Print out the one query results for the second
						// query results with repsect to the first query.
						c = makeComparisonFast(qe[j], qe[j], false, qe[i].getQuery(),
								os, s, humanReadable);
						out.write(c);
					}
				}
			} // End of loop over all queries
		} // End of if FairPairs
		
		out.close();

		// Save the features again
		fc.saveFeatures(Options.get("RERANKER_FEATURE_FILE"));
	}
	
	/**
	 * Add the hard constraints to inFile and store the combined set in outFile.
	 * 
	 * @param inFile
	 *            The file with the preferences
	 * @param outFile
	 *            The file that the hard constraints should be placed in.
	 * @param addHard
	 *            Set to true if the hard constraints are to be added (not added
	 *            when using FairPairs)
	 */
	public static void preparePrefs(String inFile, String outFile,
			boolean addHard) throws IOException {

		String s[] = new String[1];
		s[0] = inFile;
		preparePrefs(s, outFile, addHard);
	}

	/**
	 * Concatenate the preference files, and add the hard constraints.
	 * 
	 * @param inFiles
	 *            The files with preferences to combine.
	 * @param outFile
	 *            The file where the combined preferences should go.
	 */
	public static void preparePrefs(String inFiles[], String outFile,
			boolean addHard) throws IOException {

		String line;
		BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(outFile)));

		// Combine the preference files
		BufferedReader in;
		for (int i = 0; i < inFiles.length; i++) {
			in = new BufferedReader(new InputStreamReader(new FileInputStream(
					inFiles[i])));
			while ((line = in.readLine()) != null)
				out.write(line + "\n");
			in.close();
		}

		fc = new FeatureConverter(Options.get("RERANKER_FEATURE_FILE"));

		// Add hard constraints to value features
		/*
		if (Options.getBool("LEARNER_VALUE_FEATURES")) {
			Searcher s = new LuceneSearcher(Options.get("INDEX_DIRECTORY"));
			fields = s.getFieldsShort();
			String cost = "cost:"+Options.get("LEARNER_COST");
			for (int i = 0; i < fields.length; i++) {
				String key = "SCORE-" + fields[i];
				long fid = fc.featureId(key);
				if (fid != -1)
				    out.write("0 " + cost + " " + fid + ":" + 1 + "\n");
			}
		}
		*/

		// Add hard constraints
		if (addHard) {
			Logger.log("Adding hard constraints");

		    if (Options.getBool("LEARNER_USE_SCORES")) {
				Searcher s = new LuceneSearcher(Options.get("INDEX_DIRECTORY"));
				fields = s.getFieldsShort();
				String cost = "cost:"+Options.get("LEARNER_COST");
				for (int i = 0; i < fields.length; i++) {
				    for (int j = 0; j < scoreThresholds.length; j++) {
					String key = "SCORE-" + fields[i] + "-" + scoreThresholds[j];
					long fid = fc.featureId(key);
					if (fid != -1)
					    out.write(Options.get("LEARNER_WMIN") + " " + cost 
					    		+ " " + fid + ":" + 1 + "\n");
				    }
				}
		    } else {
				Enumeration e = fc.featureNameEnumeration();
				while (e.hasMoreElements()) {
					String key = (String) e.nextElement();
					if (key.length() > 6 && key.substring(0, 4).equals("TOP-"))
						out.write(Options.get("LEARNER_WMIN") + " cost:"
								+ Options.get("LEARNER_COST") + " "
								+ fc.featureId(key) + ":" + 1 + "\n");
				}
		    }
		}

		out.close();
	}

	public static void learnModel(String prefFile, String modelFile)
			throws IOException {

		// Run an SVM learner
		SvmWrapper.learn("-b 0 -z o ", prefFile, modelFile);
	}

	/**
	 * @deprecated Use the database enabled version of these functions.
	 * 
	 * Print out preferences that all the documents in unclickResults at ranks
	 * unclickList are worse than all documents in clickResults at ranks
	 * clickList for the query.
	 * 
	 * @param qeClicked
	 *            The query entry for the clicked results.
	 * @param qeUnclicked
	 *            The query entry for the unclicked results.
	 * @param twoQueryCase
	 *            Set to true if clickResults != unclickResults.
	 * @param query
	 *            The query with respect to which we infer preferences.
	 * @param origResults
	 *            The original results for the query for each field.
	 * @param origScores
	 *            The scores of the original results for each field, if
	 *            available.
	 * @param s
	 *            A searcher (to be able to pick random documents).
	 * @param fc
	 *            A feature converter for converting feature names to ids.
	 * @param humanReadable
	 *            If true, all comparisons output are human readable.
	 * @param debug
	 *            If true, explain what is going on in the log file.
	 * @return The preferences as a number of entries in SVMLight format.
	 *
	private static String makeComparison(QueryEntry qeClicked,
			QueryEntry qeUnclicked, boolean twoQueryCase, String query,
			String origResults[][], double origScores[][],
			Searcher s, boolean humanReadable) 
		throws IOException {

		int clickList[] = qeClicked.getClicklist();
		String cResults[] = qeClicked.getResults();

		int unclickList[] = qeUnclicked.getUnclicklist();
		String uResults[] = qeUnclicked.getResults();

		String comparisons = "";

		for (int i = 0; i < clickList.length; i++) {
			for (int j = 0; j < unclickList.length; j++) {
				int cRank = clickList[i];
				int uRank = unclickList[j];

				// In the two query case, the ranks don't need to be compared
				// between themselves.
				// We just assume that everything in the unclicklist was looked
				// at before the
				// clicklist entries since they are for different queries.

				// Set to true for modelling (always characterized by using the
				// ModelSearcher)
				boolean modelling = false;
				if (Options.get("SEARCHER_TYPE").equals("ModelSearcher"))
					modelling = true;

				// Only used in the modelling, comment out all but the first
				// line in a real search
				// engine. This is a bit of a hack, but its rarely used so I'm
				// not cleaning it up
				// in this version.
				int topic = 0;
				if (modelling) {
					topic = Integer.parseInt(qeClicked.getReferer().replaceAll(
							"topic-", ""));
				}

				if (twoQueryCase) { 
					// Two query case: preferences between queries.

					if (debug)
						Logger.log("Two query case. Query is " + query);

					// If they are real results (not an "imaginary next doc").
					if (uRank >= 0) {
						if (debug) {
							Logger.log("uRank is " + uRank + " and cRank is " + cRank);
						}
						comparisons += makePreference(uResults[uRank],
								cResults[cRank], query, origResults,
								origScores, humanReadable);
						if (modelling) {
							checkPreference(uResults[uRank], cResults[cRank],
									topic);
						}
					} else {
						if (debug)
							Logger.log("uRank is -1, cRank is " + cRank
									+ ". Random document and "
									+ cResults[cRank] + " compared.");
						// The unclicked result doesn't exist, so we set it
						// random.
						String randDocId = s.randomDocUniqId();
						comparisons += makePreference(randDocId,
								cResults[cRank], query, origResults,
								origScores, humanReadable);
						if (modelling) {
							checkPreference(randDocId, cResults[cRank], topic);
						}
					}

				} else { // One query case: preferences within the
					// same query, though the query given might
					// not be the one that gave these results.

					if (debug)
						Logger.log("One query case. Query is " + query);

					// If its not the "no result" entry, and j comes before i or
					// is in the top 2.
					if ((uRank != -1) && (uRank < cRank || uRank <= 1)) {
						// Todo: In the future: add a check that it
						// wasn't clicked on earlier.

						if (debug)
							Logger.log("uRank is " + uRank + " and cRank is " + cRank);

						// clicked prefered to unclicked for query
						comparisons += makePreference(uResults[uRank],
								cResults[cRank], query, origResults,
								origScores, humanReadable);
						if (modelling) {
							checkPreference(uResults[uRank], cResults[cRank],
									topic);
						}
					}
				}
			}
		}

		// Normalize the preferences we generate: The cost of each
		// contraint is one over the number of constraints generated
		// for this query or pair of queries. This is so that one
		// click on document 200 doesn't make 200 times as many
		// constraints as a click on document 2.
		comparisons = normalizeConstraints(comparisons);

		return comparisons;
	}
	*/
	
	/**
	 * Print out preferences that all the documents in unclickResults at ranks
	 * unclickList are worse than all documents in clickResults at ranks
	 * clickList for the query.
	 * 
	 * @param qeClicked
	 *            The query entry for the clicked results.
	 * @param qeUnclicked
	 *            The query entry for the unclicked results.
	 * @param twoQueryCase
	 *            Set to true if clickResults != unclickResults.
	 * @param query
	 *            The query with respect to which we infer preferences.
	 * @param origResults
	 *            The original results for the query for each field.
	 * @param origScores
	 *            The scores of the original results for each field, if
	 *            available.
	 * @param s
	 *            A searcher (to be able to pick random documents).
	 * @param humanReadable
	 *            If true, all comparisons output are human readable.
	 * @param debug
	 *            If true, explain what is going on in the log file.
	 * @return The preferences as a number of entries in SVMLight format.
	 */
	private static String makeComparisonFast(QueryEntry qeClicked,
			QueryEntry qeUnclicked, boolean twoQueryCase, String query,
			OriginalScores os, Searcher s, boolean humanReadable) 
		throws IOException {

		int clickList[] = qeClicked.getClicklist();
		String cResults[] = qeClicked.getResults();

		int unclickList[] = qeUnclicked.getUnclicklist();
		String uResults[] = qeUnclicked.getResults();

		String comparisons = "";

		for (int i = 0; i < clickList.length; i++) {
			for (int j = 0; j < unclickList.length; j++) {
				int cRank = clickList[i];
				int uRank = unclickList[j];

				// In the two query case, the ranks don't need to be compared
				// between themselves.
				// We just assume that everything in the unclicklist was looked
				// at before the
				// clicklist entries since they are for different queries.

				// Set to true for modelling (always characterized by using the
				// ModelSearcher)
				boolean modelling = false;
				if (Options.get("SEARCHER_TYPE").equals("ModelSearcher"))
					modelling = true;

				// Only used in the modelling, comment out all but the first
				// line in a real search
				// engine. This is a bit of a hack, but its rarely used so I'm
				// not cleaning it up
				// in this version.
				int topic = 0;
				if (modelling) {
					topic = Integer.parseInt(qeClicked.getReferer().replaceAll(
							"topic-", ""));
				}

				if (twoQueryCase) { 
					// Two query case: preferences between queries.

					if (debug)
						Logger.log("Two query case. Query is " + query);

					// If they are real results (not an "imaginary next doc").
					if (uRank >= 0) {
						if (debug) {
							Logger.log("uRank is " + uRank + " and cRank is " + cRank);
						}
						comparisons += makePreferenceFast(uResults[uRank],
								cResults[cRank], query, os, humanReadable);
						if (modelling) {
							checkPreference(uResults[uRank], cResults[cRank],
									topic);
						}
					} else {
						if (debug)
							Logger.log("uRank is -1, cRank is " + cRank
									+ ". Random document and "
									+ cResults[cRank] + " compared.");
						// The unclicked result doesn't exist, so we set it
						// random.
						String randDocId = s.randomDocUniqId();
						comparisons += makePreferenceFast(randDocId,
								cResults[cRank], query,	os, humanReadable);
						if (modelling) {
							checkPreference(randDocId, cResults[cRank], topic);
						}
					}

				} else { // One query case: preferences within the
					// same query, though the query given might
					// not be the one that gave these results.

					if (debug)
						Logger.log("One query case. Query is " + query);

					// If its not the "no result" entry, and j comes before i or
					// is in the top 2.
					if ((uRank != -1) && (uRank < cRank || uRank <= 1)) {
						// Todo: In the future: add a check that it
						// wasn't clicked on earlier.

						if (debug)
							Logger.log("uRank is " + uRank + " and cRank is " + cRank);

						// clicked prefered to unclicked for query
						comparisons += makePreferenceFast(uResults[uRank],
								cResults[cRank], query, os, humanReadable);
						if (modelling) {
							checkPreference(uResults[uRank], cResults[cRank],
									topic);
						}
					}
				}
			}
		}

		// Normalize the preferences we generate: The cost of each
		// contraint is one over the number of constraints generated
		// for this query or pair of queries. This is so that one
		// click on document 200 doesn't make 200 times as many
		// constraints as a click on document 2.
		comparisons = normalizeConstraints(comparisons);

		return comparisons;
	}
	
	/**
	 * @deprecated Use the database version of everything.
	 * 
	 * Print out preferences that all the documents in unclickResults at ranks
	 * unclickList are worse than all documents in clickResults at ranks
	 * clickList for the query.
	 * 
	 * @param qeClicked
	 *            The query entry for the clicked results.
	 * @param qeUnclicked
	 *            The query entry for the unclicked results.
	 * @param twoQueryCase
	 *            Set to true if clickResults != unclickResults.
	 * @param query
	 *            The query with respect to which we infer preferences.
	 * @param origResults
	 *            The original results for the query for each field.
	 * @param origScores
	 *            The scores of the original results, if available
	 * @param s
	 *            A searcher (to be able to pick random documents).
	 * @param fc
	 *            A feature converter for converting feature names to ids.
	 * @param humanReadable
	 *            If true, all comparisons output are human readable.
	 * @param debug
	 *            If true, explain what is going on in the log file.
	 * @return The preferences as a number of entries in SVMLight format.
	 *
	private static String makeComparisonFairPairs(QueryEntry qeClicked,
			QueryEntry prevQuery, boolean twoQueryCase, String query,
			String origResults[][], double origScores[][],
			Searcher s, boolean humanReadable,
			int pairOffset) throws IOException {

		int clickList[] = qeClicked.getClicklist();
		String cResults[] = qeClicked.getResults();

		String prevResults[] = prevQuery.getResults();

		String comparisons = "";

		if (twoQueryCase) {

			// IMPORTANT NOTE: The two query case is never used with FairPairs.
			// This was experimenting with various ways to incorporate QueryChains and
			// FairPairs and is really a big ugly mess.
			
			Logger.log("ERROR: FairPairs run with two query case.");
			
			if (debug)
				Logger.log("Two query case");

			// For every clicked result
			for (int i = 0; i < clickList.length; i++) {
				int cRank = clickList[i];

				// To make sure we don't reverse the ranking, the result not
				// clicked
				// is preferred to the results around the clicked result at the
				// bottom of the original ranking:
				// Q1: a b c ... i j k
				// Q2: x j z ...
				// Generate: j>b, b>i, b>k

				// Work out the matching result in the previous query, and
				// make a preference. Then find the surrounding results and
				// make "correction" preferences to avoid reversal effects.

				String unclicked;
				if (prevResults.length > cRank) {
					if (debug) {
						Logger.log("Making preference that " + cResults[cRank] + "("
								+ cRank + ") >" + prevResults[cRank]);
					}
					unclicked = prevResults[cRank];
					comparisons += makePreference(unclicked,
							cResults[cRank], query, origResults, origScores,
							humanReadable);

				} else { // Not enough results: use a random document.
					String randDocId = s.randomDocUniqId();
					if (debug) {
						Logger.log("Making random preference that " + cResults[cRank]
								+ "(" + cRank + ") >" + randDocId);
					}
					unclicked = randDocId;
					comparisons += makePreference(unclicked, cResults[cRank],
							query, origResults, origScores, humanReadable);
				}

				 * Here we create non-reversal constraints, as an experiment. It creates 
				 * a preference for the two results on either side of the clicked one 
				 * in the earlier query, and says they are less relevant. This was to
				 * avoid reversing the rankings. But we don't do this when not using
				 * query chains. 
				 *
				
				// Find rank of clicked result in earlier query
				int cRankPrev = prevQuery.getRank(cResults[cRank]);
				
				// Find result just before it and just after it
				String beforeRes, afterRes;
				if (cRankPrev == -1 || cRankPrev == 0) {
					beforeRes = s.randomDocUniqId();
				} else {
					beforeRes = prevResults[cRankPrev - 1];
				}

				if (cRankPrev == -1 || cRankPrev + 1 >= prevResults.length) {
					afterRes = s.randomDocUniqId();
				} else {
					afterRes = prevResults[cRankPrev + 1];
				}

				if (debug) {
					Logger.log("Non-reversal preferences: Results used are ("
							+ cRankPrev + ") " + beforeRes + ", " + afterRes);
				}

				// Generate those two preferences
				if (debug) {
					Logger.log("Making random preference that " + unclicked + " > "
							+ beforeRes + ", " + afterRes);
				}
			
				comparisons += makePreference(beforeRes, unclicked, query,
						origResults, origScores, humanReadable);
				comparisons += makePreference(afterRes, unclicked, query,
						origResults, origScores, humanReadable);

			}

		} else {

			if (debug)
				Logger.log("One query case, pair offset is " + pairOffset);

			// For every clicked result
			for (int i = 0; i < clickList.length; i++) {
				int cRank = clickList[i];

				// Work out if we're the second in the current pair. If so, we
				// can
				// make a preference. cRank starts at 0, and
				// what we do depends on odd/even ranks.
				if (cRank % 2 == 1 - pairOffset && cRank > 0) {
					if (debug) {
						Logger.log("Making preference that " + cResults[cRank] + "("
								+ cRank + ") >" + cResults[cRank - 1]);
					}

					comparisons += makePreference(cResults[cRank - 1],
							cResults[cRank], query, origResults, origScores,
							humanReadable);
				}
			}
		}

		return comparisons;
	}
	*/
	
	/**
	 * Print out preferences that all the documents in unclickResults at ranks
	 * unclickList are worse than all documents in clickResults at ranks
	 * clickList for the query.
	 * 
	 * @param qeClicked
	 *            The query entry for the clicked results.
	 * @param qeUnclicked
	 *            The query entry for the unclicked results.
	 * @param twoQueryCase
	 *            Set to true if clickResults != unclickResults.
	 * @param query
	 *            The query with respect to which we infer preferences.
	 * @param origResults
	 *            The original results for the query for each field.
	 * @param origScores
	 *            The scores of the original results, if available
	 * @param s
	 *            A searcher (to be able to pick random documents).
	 * @param fc
	 *            A feature converter for converting feature names to ids.
	 * @param humanReadable
	 *            If true, all comparisons output are human readable.
	 * @param debug
	 *            If true, explain what is going on in the log file.
	 * @return The preferences as a number of entries in SVMLight format.
	 */
	private static String makeComparisonFairPairsFast(QueryEntry qe,
			OriginalScores os, boolean humanReadable) throws IOException {

		String comparisons = "";
		int pairOffset = qe.getFPOffset();
		int setSize = qe.getFPSetSize();
		
		// Non-FairPairs query entry
		if (pairOffset < 0 || setSize < 0)
			return "";
		
		int clickList[] = qe.getClicklist();
		String qResults[] = qe.getResults();
		String query = qe.getQuery();
		
		// For every clicked result
		for (int i = 0; i < clickList.length; i++) {
			int cRank = clickList[i];

			if (debug)
				Logger.log("Clicked on rank "+cRank);
			
			// Work out if we're not the first in the current pair. If so, we
			// can make a preference. cRank starts at 0, and
			// what we do depends on odd/even ranks.
			//if (cRank % 2 == 1 - pairOffset && cRank > 0) {
			if (cRank % setSize != pairOffset && cRank > 0) {
				if (debug) {
					Logger.log("Making preference that " + qResults[cRank] + "("
							+ cRank + ") >" + qResults[cRank - 1]);
				}

				comparisons += makePreferenceFast(qResults[cRank - 1],
						qResults[cRank], query, os,	humanReadable);
			}
		}

		return comparisons;
	}
	
	/**
	 * Normalized the constraings in the comparisons so that the costs sum to 1.
	 * 
	 * @param oldConst
	 *            The constraints to normalize
	 * @return The constraints, with costs adding to 1.
	 */
	private static String normalizeConstraints(String oldConst) {

		String newConst = "";

		String lines[] = oldConst.split("\n");
		if (lines.length > 1) {
			for (int i = 0; i < lines.length; i++) {
				newConst += lines[i].substring(0, 1);
				newConst += " cost:" + (1.0 / lines.length);
				newConst += lines[i].substring(1) + "\n";
			}
		} else {
			newConst = oldConst;
		}

		return newConst;
	}

	/**
	 * @deprecated Use the database enabled version of everything.
	 * 
	 * Return a preference that says that the unclicked document is worse than
	 * the clicked document for this query.
	 * 
	 * @param unclicked
	 *            A unique document identifier for a skipped doc.
	 * @param clicked
	 *            A unique document identifier for a clicked doc.
	 * @param qry
	 *            The query with respect to which we draw this preference.
	 * @param origResults
	 *            The original results for the query, for each field.
	 * @param origScores
	 *            The scores of the original results, for each field, if
	 *            available.
	 * @param fc
	 *            A feature converter for converting feature names to ids.
	 * @param humanReadable
	 *            If true, the feature names aren't converted to ids.
	 * @param debug
	 *            If true, explain what is going on in the log file.
	 * @param twoQueryCase
	 *            Set to true if we don't want to generate rank features, since
	 *            they usually get made negative if we include rank features on
	 *            two query preferences.
	 * @return The preference judgement that we infer.
	 *
	private static String makePreference(String unclicked, String clicked,
			String query, String origResults[][], double origScores[][],
			boolean humanReadable) 
		throws IOException {

		int cLearnerRanks[];

		String preference = "1 ";
		Hashtable features = new Hashtable();

		String name;
		Object key;
		long cFeatureId, uFeatureId;

		if (debug) {
			Logger.log("makePreference: Unclicked: " + unclicked + ", Clicked: "
					+ clicked);
		}

		// Check clicked and unclicked are sane
		if (clicked.equals(""))
			throw new IOException("makePreference called with blank clicked.");
		if (unclicked.equals(""))
			throw new IOException("makePreference called with blank unclicked.");
		if (clicked.equals(unclicked)) {
			Logger.log("Note: Clicked and Unclicked identical: " + clicked);
			return "";
		}

		String tmpArr[] = Options.getStrArr("LEARNER_N_RANKS");
		cLearnerRanks = new int[tmpArr.length];
		for (int i = 0; i < tmpArr.length; i++)
			cLearnerRanks[i] = Integer.parseInt(tmpArr[i]);

		// Make sure all the top-n features exist
		if (!Options.getBool("LEARNER_USE_SCORES")) {
		    for (int i = 0; i < fields.length; i++) {
			for (int j = 0; j < cLearnerRanks.length; j++) {
			    name = "TOP-" + fields[i] + "-" + cLearnerRanks[j];
			    fc.featureId(name, true);
			}
		    }
		}

		double[] clickScores = null;
		double[] unclickScores = null;

		// Find the original ranks of the results we want to reason about.
		int[] clickRanks = origRanks(origResults, clicked);
		int[] unclickRanks = origRanks(origResults, unclicked);

		if (origScores != null) {
			// Find out the original score of the results for this query
			clickScores = origScores(origScores, clickRanks);
			unclickScores = origScores(origScores, unclickRanks);
		}

		int ageClicked = searcher.getDoc(clicked).getAge("date");
		int ageUnclicked = searcher.getDoc(unclicked).getAge("date");
		
		// If the ages are not -1, add features for them
		if (ageClicked != -1 && ageUnclicked != -1 && Options.getBool("LEARNER_USE_AGE")) {

			if (Options.getBool("LEARNER_VALUE_FEATURES")) {

				name = "SCORE-AGE";
				if (humanReadable)
					key = name;
				else
					key = new Long(fc.featureId(name, true));
				addFeature(features, key, ageClicked);
				addFeature(features, key, -ageUnclicked);

			} else {
						
				for (int i=0; i<=ageClicked; i++) {
					name = "AGE-"+i;
					if (humanReadable)
						key = name;
					else
						key = new Long(fc.featureId(name, true));
					addFeature(features, key, 1);
				}
				for (int i=0; i<=ageUnclicked; i++) {
					name = "AGE-"+i;
					if (humanReadable)
						key = name;
					else
						key = new Long(fc.featureId(name, true));
					addFeature(features, key, -1);
				}
			}
		}
			
		// Work out the rank features that are non-zero
		for (int i = 0; i < fields.length; i++) {

			// If we have scores, we want to do score-based features
			if (clickScores != null && unclickScores != null) {

				if (debug) {
					Logger.log("Making SCORE-" + fields[i]);
					Logger.log("clickScores is " + clickScores[i]
							+ ", unclickScores is " + unclickScores[i]);
				}

				// If we learn based on value features for the scores
				if (Options.getBool("LEARNER_VALUE_FEATURES")) {

					name = "SCORE-" + fields[i];
					if (humanReadable)
						key = name;
					else
						key = new Long(fc.featureId(name, true));
					addFeature(features, key, clickScores[i]);
					addFeature(features, key, -unclickScores[i]);

				} else {
					// Else learn based on thresholds for the scores

					// For the clicked document
					for (int j = 0; j < scoreThresholds.length; j++) {
						name = "SCORE-" + fields[i] + "-" + scoreThresholds[j];

						if (clickScores[i] > scoreThresholds[j]) {
							if (debug)
								Logger.log("Adding feature " + name + " at value 1");

							if (humanReadable) {
								key = name;
							} else {
								key = new Long(fc.featureId(name, true));
							}
							addFeature(features, key, 1);
						}
						if (unclickScores[i] > scoreThresholds[j]) {
							if (debug)
								Logger.log("Adding feature " + name + " at value -1");

							if (humanReadable) {
								key = name;
							} else {
								key = new Long(fc.featureId(name, true));
							}

							addFeature(features, key, -1);
						}
					} // End of loop over score thresholds
				} // End of learning using score thresholds

			} else { // We don't have scores so we can't do score-based features (use rank instead)

				// Note: clickRanks starts at 0, and we want to get TOP-1
				// if it is 0, so we include clickRanks[i]+1.
				int maxJ = cLearnerRanks.length - 1;

				if (debug) {
					Logger.log("Making TOP-" + fields[i] + " for top "
							+ cLearnerRanks[maxJ]);
					Logger.log("clickRanks is " + clickRanks[i] + ", unclickRanks is "
							+ unclickRanks[i]);
				}

				// For the clicked document
				if (clickRanks[i] != -1) {
					for (int j = maxJ; j >= 0
							&& (cLearnerRanks[j] >= clickRanks[i] + 1); j--) {
						name = "TOP-" + fields[i] + "-" + cLearnerRanks[j];
						if (debug)
							Logger.log("Adding feature " + name + " at value 1");

						if (humanReadable) {
							key = name;
						} else {
							key = new Long(fc.featureId(name, true));
						}

						addFeature(features, key, 1);
					}
				}

				// For the not clicked document
				if (unclickRanks[i] != -1) {
					for (int j = maxJ; j >= 0
							&& (cLearnerRanks[j] >= unclickRanks[i] + 1); j--) {
						name = "TOP-" + fields[i] + "-" + cLearnerRanks[j];
						if (debug)
							Logger.log("Adding feature " + name + " at value -1");
						if (humanReadable) {
							key = name;
						} else {
							key = new Long(fc.featureId(name, true));
						}

						// If we split the preferences, we set the rank feature
						// to 1
						// for both the clicked and not-clicked document.
						// However, if
						// we don't split the preferences, we set the rank
						// feature for
						// the clicked document to 1 but the rank feature for
						// the non-
						// clicked document to -1 (it has been subtracted from
						// the
						// clicked document). The also applies in later code
						// below.

						addFeature(features, key, -1);
					}
				}
			} // End of if we have score
		} // End of loop over fields

		// For every query word print out the features
		String words[] = Reranker.tokenize(query, true);

		if (Options.getBool("LEARNER_NO_TDF"))
			words = new String[0];

		for (int i = 0; i < words.length; i++) {

			// Here, we never compare identical documents, and
			// multiple word occurrences are ignored so we don't need
			// to worry about previous values.

			// term feature for the clicked document
			name = "W" + words[i].toLowerCase() + "-D" + clicked;
			if (debug)
				Logger.log("Adding feature " + name + "=1");

			if (humanReadable)
				features.put(name, new Double(1));
			else {
				cFeatureId = fc.featureId(name, true);
				features.put(new Long(cFeatureId), new Double(1));
			}

			// term feature for the unclicked document
			name = "W" + words[i].toLowerCase() + "-D" + unclicked;
			if (debug)
				Logger.log("Adding feature " + name + "=-1");

			if (humanReadable) {
				features.put(name, new Double(-1));
			} else {
				uFeatureId = fc.featureId(name, true);
				features.put(new Long(uFeatureId), new Double(-1));
			}
		}

		// Get the features out in a sorted manner
		if (humanReadable) {
			Enumeration e = features.keys();
			while (e.hasMoreElements()) {
				key = (String) e.nextElement();
				double value = ((Double) features.get(key)).doubleValue();

				if (value != 0)
					preference += key + ":" + value + " ";
			}
		} else {
			long featureIds[] = new long[features.size()];

			Enumeration e = features.keys();
			for (int i = 0; i < featureIds.length; i++) {
				featureIds[i] = ((Long) e.nextElement()).longValue();
			}
			Arrays.sort(featureIds);

			for (int i = 0; i < featureIds.length; i++) {
				double value = ((Double) features.get(new Long(featureIds[i])))
						.doubleValue();

				// Ignore zero-values features.
				if (value != 0)
					preference += featureIds[i] + ":" + value + " ";
			}
		}

		preference += "\n";
		return preference;
	}
	*/
	
	/**
	 * Return a preference that says that the unclicked document is worse than
	 * the clicked document for this query.
	 * 
	 * @param unclicked
	 *            A unique document identifier for a skipped doc.
	 * @param clicked
	 *            A unique document identifier for a clicked doc.
	 * @param qry
	 *            The query with respect to which we draw this preference.
	 * @param origResults
	 *            The original results for the query, for each field.
	 * @param origScores
	 *            The scores of the original results, for each field, if
	 *            available.
	 * @param fc
	 *            A feature converter for converting feature names to ids.
	 * @param humanReadable
	 *            If true, the feature names aren't converted to ids.
	 * @param debug
	 *            If true, explain what is going on in the log file.
	 * @param twoQueryCase
	 *            Set to true if we don't want to generate rank features, since
	 *            they usually get made negative if we include rank features on
	 *            two query preferences.
	 * @return The preference judgement that we infer.
	 */
	private static String makePreferenceFast(String unclicked, String clicked,
			String query, OriginalScores os, boolean humanReadable) 
		throws IOException {

		int cLearnerRanks[];

		String preference = "1 ";
		Hashtable features = new Hashtable();

		String name;
		Object key;
		long cFeatureId, uFeatureId;

		if (debug)
			Logger.log("makePreference: Unclicked: " + unclicked + ", Clicked: " + clicked);

		// Check clicked and unclicked are sane
		if (clicked.equals(""))
			throw new IOException("makePreference called with blank clicked.");
		if (unclicked.equals(""))
			throw new IOException("makePreference called with blank unclicked.");
		if (clicked.equals(unclicked)) {
			Logger.log("Note: Clicked and Unclicked identical: " + clicked);
			return "";
		}

		// These are the threshold ranks for rank based features
		String tmpArr[] = Options.getStrArr("LEARNER_N_RANKS");
		cLearnerRanks = new int[tmpArr.length];
		for (int i = 0; i < tmpArr.length; i++)
			cLearnerRanks[i] = Integer.parseInt(tmpArr[i]);

		// Make sure all the top-n features exist
		if (!Options.getBool("LEARNER_USE_SCORES")) {
			if (debug)
				Logger.log("Making sure all TOP- features exist.");
			
		    for (int i = 0; i < fields.length; i++) {
		    	for (int j = 0; j < cLearnerRanks.length; j++) {
		    		name = "TOP-" + fields[i] + "-" + cLearnerRanks[j];
		    		fc.featureId(name, true);
		    	}
		    }
		}
		
		// Get the document ages in years
		if (debug)
			Logger.log("Getting ages of documents.");
		int ageClicked = os.getAge(clicked);
		if (ageClicked > 0)
			ageClicked = (int)(1.0*ageClicked/365.25);
		int ageUnclicked = os.getAge(unclicked);
		if (ageUnclicked > 0)
			ageUnclicked = (int)(1.0*ageUnclicked/365.25);

		// If the ages are not -1, add features for them
		if (ageClicked != -1 && ageUnclicked != -1 && Options.getBool("LEARNER_USE_AGE")) {

			if (debug)
				Logger.log("Making age features");
			
			if (Options.getBool("LEARNER_VALUE_FEATURES")) {

				name = "SCORE-AGE";
				if (humanReadable)
					key = name;
				else
					key = new Long(fc.featureId(name, true));
				addFeature(features, key, ageClicked);
				addFeature(features, key, -ageUnclicked);

			} else {
						
				for (int i=0; i<=ageClicked; i++) {
					name = "AGE-"+i;
					if (humanReadable)
						key = name;
					else
						key = new Long(fc.featureId(name, true));
					addFeature(features, key, 1);
				}
				for (int i=0; i<=ageUnclicked; i++) {
					name = "AGE-"+i;
					if (humanReadable)
						key = name;
					else
						key = new Long(fc.featureId(name, true));
					addFeature(features, key, -1);
				}
			}
		}

		// Find the original document scores or ranks.
		double clickScores[]=null, unclickScores[]=null;
		int clickRanks[]=null, unclickRanks[]=null;
		
		if (Options.getBool("LEARNER_USE_SCORES")) {
			if (debug)
				Logger.log("Getting original scores.");
			clickScores = os.getScores(query, clicked);
			unclickScores = os.getScores(query, unclicked);
		} else {
			if (debug)
				Logger.log("Getting original ranks.");
			clickRanks = os.getRanks(query, clicked);
			unclickRanks = os.getRanks(query, unclicked);
		}
		
		// Work out the rank features that are non-zero
		if (debug)
			Logger.log("Working out rank/score features");
		
		for (int i = 0; i < fields.length; i++) {

			if (debug)
				Logger.log("Processing field "+i+" ("+fields[i]+")");
			
			// If we have scores, we want to do score-based features
			if (Options.getBool("LEARNER_USE_SCORES")) {
				
				if (debug) {
					Logger.log("Making SCORE-" + fields[i]);
					Logger.log("clickScores is " + clickScores[i]
							+ ", unclickScores is " + unclickScores[i]);
				}

				// If we learn based on value features for the scores
				if (Options.getBool("LEARNER_VALUE_FEATURES")) {

					name = "SCORE-" + fields[i];
					if (humanReadable)
						key = name;
					else
						key = new Long(fc.featureId(name, true));
					addFeature(features, key, clickScores[i]);
					addFeature(features, key, -unclickScores[i]);

				} else {
					// Else learn based on thresholds for the scores

					// For the clicked document
					for (int j = 0; j < scoreThresholds.length; j++) {
						name = "SCORE-" + fields[i] + "-" + scoreThresholds[j];

						if (clickScores[i] > scoreThresholds[j]) {
							if (debug)
								Logger.log("Adding feature " + name + " at value 1");

							if (humanReadable) {
								key = name;
							} else {
								key = new Long(fc.featureId(name, true));
							}
							addFeature(features, key, 1);
						}
						if (unclickScores[i] > scoreThresholds[j]) {
							if (debug)
								Logger.log("Adding feature " + name + " at value -1");

							if (humanReadable) {
								key = name;
							} else {
								key = new Long(fc.featureId(name, true));
							}

							addFeature(features, key, -1);
						}
					} // End of loop over score thresholds
				} // End of learning using score thresholds

			} else { // We don't have scores so we can't do score-based features (use rank instead)

				// Note: clickRanks starts at 0, and we want to get TOP-1
				// if it is 0, so we include clickRanks[i]+1.
				int maxJ = cLearnerRanks.length - 1;

				if (debug) {
					Logger.log("Making TOP-" + fields[i] + " for top "
							+ cLearnerRanks[maxJ]);
					Logger.log("clickRanks is " + clickRanks[i] + ", unclickRanks is "
							+ unclickRanks[i]);
				}

				// For the clicked document
				if (clickRanks[i] != -1) {
					for (int j = maxJ; j >= 0
							&& (cLearnerRanks[j] >= clickRanks[i] + 1); j--) {
						name = "TOP-" + fields[i] + "-" + cLearnerRanks[j];
						if (debug)
							Logger.log("Adding feature " + name + " at value 1");

						if (humanReadable) {
							key = name;
						} else {
							key = new Long(fc.featureId(name, true));
						}

						addFeature(features, key, 1);
					}
				}

				// For the not clicked document
				if (unclickRanks[i] != -1) {
					for (int j = maxJ; j >= 0
							&& (cLearnerRanks[j] >= unclickRanks[i] + 1); j--) {
						name = "TOP-" + fields[i] + "-" + cLearnerRanks[j];
						if (debug)
							Logger.log("Adding feature " + name + " at value -1");
						if (humanReadable) {
							key = name;
						} else {
							key = new Long(fc.featureId(name, true));
						}

						// If we split the preferences, we set the rank feature
						// to 1
						// for both the clicked and not-clicked document.
						// However, if
						// we don't split the preferences, we set the rank
						// feature for
						// the clicked document to 1 but the rank feature for
						// the non-
						// clicked document to -1 (it has been subtracted from
						// the
						// clicked document). The also applies in later code
						// below.

						addFeature(features, key, -1);
					}
				}
			} // End of if we have score
		} // End of loop over fields

		// For every query word print out the features
		String words[] = Reranker.tokenize(query, true);

		if (Options.getBool("LEARNER_NO_TDF"))
			words = new String[0];

		if (debug)
			Logger.log("Printing out word features.");
			
		for (int i = 0; i < words.length; i++) {

			// Here, we never compare identical documents, and
			// multiple word occurrences are ignored so we don't need
			// to worry about previous values.

			// term feature for the clicked document
			name = Reranker.tdfFeatureName(words[i], clicked);
			if (debug) Logger.log("Adding feature " + name + "=1");

			if (humanReadable)
				features.put(name, new Double(1));
			else {
				cFeatureId = fc.featureId(name, true);
				features.put(new Long(cFeatureId), new Double(1));
			}

			// term feature for the unclicked document
			name = Reranker.tdfFeatureName(words[i], unclicked);
			if (debug) Logger.log("Adding feature " + name + "=-1");

			if (humanReadable) {
				features.put(name, new Double(-1));
			} else {
				uFeatureId = fc.featureId(name, true);
				features.put(new Long(uFeatureId), new Double(-1));
			}
		}

		// Get the features out in a sorted manner
		if (humanReadable) {
			Enumeration e = features.keys();
			while (e.hasMoreElements()) {
				key = (String) e.nextElement();
				double value = ((Double) features.get(key)).doubleValue();

				if (value != 0)
					preference += key + ":" + value + " ";
			}
		} else {
			long featureIds[] = new long[features.size()];

			Enumeration e = features.keys();
			for (int i = 0; i < featureIds.length; i++) {
				featureIds[i] = ((Long) e.nextElement()).longValue();
			}
			Arrays.sort(featureIds);

			for (int i = 0; i < featureIds.length; i++) {
				double value = ((Double) features.get(new Long(featureIds[i])))
						.doubleValue();

				// Ignore zero-values features.
				if (value != 0)
					preference += featureIds[i] + ":" + value + " ";
			}
		}

		preference += "\n";
		return preference;
	}
	
	/**
	 * Update the feature value with this name by delta.
	 */
	private static void addFeature(Hashtable f, Object name, double delta) {

		Double dValue = (Double) f.get(name);
		double value;
		if (dValue == null)
			value = delta;
		else
			value = dValue.doubleValue() + delta;
		f.put(name, new Double(value));

	}

	/**
	 * @deprecated Use caching versions of all functions.
	 * 
	 * Return the ranks of uniqId in the original results to some query, for
	 * each field.
	 * 
	 * @param origResults
	 *            An array of results for each field.
	 * @param uniqId
	 *            The unique identifier of a document we're looking for.
	 * @return The ranks of uniqId in each of the fields.
	 *
	private static int[] origRanks(String[][] origResults, String uniqId) {

		int ranks[] = new int[origResults.length];
		for (int i = 0; i < origResults.length; i++) {
			ranks[i] = -1;
			for (int j = 0; j < origResults[i].length; j++) {
				if (origResults[i][j].equals(uniqId))
					ranks[i] = j;
			}
		}

		return ranks;
	}
	*/

	/**
	 * @deprecated Use caching versions of all functions.
	 * 
	 * Return the scores of uniqIds in the original results to some query, for
	 * each field.
	 * 
	 * @param origScores
	 *            An array of results for each field.
	 * @param ranks
	 *            The ranks of the documents for each field.
	 * @return The scores in each of the fields.
	 *
	private static double[] origScores(double[][] origScores, int[] ranks) {

		double scores[] = new double[origScores.length];
		for (int i = 0; i < origScores.length; i++) {
			if (ranks[i] != -1)
				scores[i] = origScores[i][ranks[i]];
			else
				scores[i] = 0;
		}

		return scores;
	}
	*/
	
	/** Command line interface for generating preferences and learning. */
	public static void main(String args[]) throws IOException, ParseException {

		debug = Options.getBool("DEBUG");
		
		if (args.length > 0 && args[0].equals("generate")) {

			// This option is used for modelling, and has many more parameters
			// Don't use it for learning for regular web search.

			String prefFile = "";
			String mode = "";
			boolean useChains = false;
			boolean doBoth = false;
			boolean useFairPairs = false;

			for (int i = 1; i < args.length; i++) {
				if (args[i].equals("--prefs") && i + 1 < args.length) {
					prefFile = args[i + 1];
					i++;
				} else if (args[i].equals("--docs") && i + 1 < args.length) {
					docFile = args[i + 1];
					i++;
				} else if (args[i].equals("--fairpairs")) {
					useFairPairs = true;
				} else if (args[i].equals("--labels") && i + 1 < args.length) {
					labelFile = args[i + 1];
					i++;
				} else if (args[i].equals("--mode") && i + 1 < args.length) {
					mode = args[i+1];
					i++;
				} else if (args[i].equals("--chains")
						|| args[i].equals("--usechains")) {
					useChains = true;
				} else if (args[i].equals("--nochains")) {
					useChains = false;
				} else if (args[i].equals("--both")) {
					doBoth = true;
				} else {
					System.err.println("Error: Unknown option " + args[i]);
					System.exit(1);
				}
			}

			if (prefFile.equals("")) {
				System.err.println("Please specify the preference output file (with --prefs)");
				System.exit(1);
			}

			if (mode.equals("")) {
				System.err.println("Please specify the mode you want to process (with --mode)");
				System.exit(1);
			}
			
			if (docFile.equals("")) {
				System.err
						.println("Please specify the document file location (with --docs)");
				System.exit(1);
			}

			if (labelFile.equals("")) {
				System.err
						.println("Please specify the label file location (with --labels)");
				System.exit(1);
			}

			if (useFairPairs) {

				QueryEntry qe[] = LogAnalyzer.loadLog("","3a");
				clicksToPrefsFairPairs(qe, "3a", prefFile, useChains, debug);

				qe = LogAnalyzer.loadLog("","3b");
				clicksToPrefsFairPairs(qe, "3b", prefFile, useChains, debug);
				
			} else if (doBoth) { // Do both chains an nochains

				QueryEntry qe[] = LogAnalyzer.loadLog("", mode);
					
				Logger.log("Writing nochains preferences to " + prefFile+"NC");
				clicksToPrefs(qe, prefFile+"NC", false, debug);

				Logger.log("Writing chains preferences to " + prefFile+"CH");
				clicksToPrefs(qe, prefFile+"CH", true, debug);

			} else { // Just do what we were asked to do without fairpairs.

				QueryEntry qe[] = LogAnalyzer.loadLog("", mode);
				
				clicksToPrefs(qe, prefFile, useChains, debug);
			}

		} else if (args.length > 0 && args[0].equals("allgen")) {

			String prefFile = "";
			boolean useChains = true;
			boolean doBoth = false;

			for (int i = 1; i < args.length; i++) {
				if (args[i].equals("--prefs") && i + 1 < args.length) {
					prefFile = args[i + 1];
					i++;
				} else if (args[i].equals("--chains")) {
					useChains = true;
					/*
					 * Option disabled since it was buggy. } else if
					 * (args[i].equals("--features") && i + 1 < args.length) {
					 * featureFile = args[i + 1]; i++;
					 */
				} else if (args[i].equals("--nochains")) {
					useChains = false;
				} else if (args[i].equals("--both")) {
					doBoth = true;
				} else if (args[i].startsWith("--")) {
					System.err.println("Error: Unknown option " + args[i]);
					System.err.println("(Don't start file names with '--')");
					System.exit(1);
				} else {
					break;
				}
			}

			if (prefFile.equals("")) {
				System.err.println("Please specify the preference output file (with --prefs)");
				System.exit(1);
			}
			
			String modes[] = Searcher.modes;
//			String modes[] = {"3a","3b"};
 			String outFile;
			for (int i = 0; i < modes.length; i++) {
				
				Logger.log("Processing mode " + modes[i]);

				QueryEntry qe[] = LogAnalyzer.loadLog("",modes[i]);
				
				if (useChains || doBoth) {
					outFile = prefFile+"."+modes[i]+".CH.log";
					
					Logger.log("Writing chains preferences to " + outFile);
					if (modes[i].charAt(0) == '3' || modes[i].charAt(0) == '4')
						clicksToPrefsFairPairs(qe, modes[i], outFile, true, debug);
					else
						clicksToPrefs(qe, outFile, true, debug);
				}

				if ((!useChains) || doBoth) {
					outFile = prefFile+"."+modes[i]+".NC.log";
			
					Logger.log("Writing nochains preferences to " + outFile);
					if (modes[i].charAt(0) == '3' || modes[i].charAt(0) == '4')
						clicksToPrefsFairPairs(qe, modes[i], outFile, false, debug);
					else
						clicksToPrefs(qe, outFile, false, debug);
				}
			}

			Logger.log("Finished processing log files.");
			
		} else if (args.length > 3 && args[0].equals("learn")) {

			// Arguments are:
			// 0:learn [1:--fairpairs] 1/2:<combined> 2/3:<model> 3/4:<prefs1>
			// [<prefs2> ...]");

			boolean addHard = true;
			int offset = 3; // Used to get the pref files from the command line

			// If we want to use FairPairs, we don't add hard constraints,
			// and we remove the first argument.
			if (args[1].equals("--fairpairs")) {
			    //addHard = false;
				offset = 4;
			}

			String prefFiles[] = new String[args.length - offset];
			for (int i = offset; i < args.length; i++)
				prefFiles[i - offset] = args[i];

			String combinedPrefs = args[offset - 2];
			String modelFile = args[offset - 1];
			// String featureFile = args[3];

			preparePrefs(prefFiles, combinedPrefs, addHard);
			learnModel(combinedPrefs, modelFile);
		} else {

			System.out.println("Usage:");
			System.out.println("\tLearner learn [--fairpairs] <combined> <model> <prefs1> [<prefs2> ...]");
			System.out.println("\tLearner allgen --pref <pref_prefix> [--chains | --nochains | --both]");

		}
	}
}
