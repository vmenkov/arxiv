package edu.cornell.cs.osmot.reranker;

import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

import edu.cornell.cs.osmot.options.Options;

/** Wrapper for SVM Light */

public class SvmWrapper {

	/** Run svm_learn given the options, example file and model file */
	public static void learn(String opts, String exampleFile, String modelFile)
			throws IOException {

		int i;
		
		String command = Options.get("SVM_LEARN_PATH") + " " + opts + " "
				+ exampleFile + " " + modelFile;
		log("Command is: " + command);

		Process p = Runtime.getRuntime().exec(command);

		BufferedReader in = new BufferedReader(new InputStreamReader(p
				.getInputStream()));

		try {

			while ((i = in.read()) != -1) {
				System.out.print((char)i);
			}
		} catch (IOException e) {
			System.exit(0);
		}

	}

	private static void log(String msg) {
		System.out.println(msg);
	}

}
