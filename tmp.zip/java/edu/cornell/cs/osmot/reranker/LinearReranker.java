package edu.cornell.cs.osmot.reranker;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Hashtable;
import java.util.HashSet;
import java.util.StringTokenizer;
import java.util.Enumeration;
import java.util.Arrays;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;

import edu.cornell.cs.osmot.searcher.ScoredDocument;
import edu.cornell.cs.osmot.searcher.Searcher;
import edu.cornell.cs.osmot.logger.Logger;
import edu.cornell.cs.osmot.options.Options;
import edu.cornell.cs.osmot.reranker.Reranker;

/**
 * This class implements the basic linear ranker with a linear weight for th
 * raw fields. 
 * 
 * @author Yisong Yue
 * @version 1.0, October 2009
 */
public class LinearReranker extends Reranker {

    public LinearReranker(String[] fields, double[] weights)
        throws IOException {

		debug = Options.getBool("DEBUG");
		this.fields = fields;

		// The long version of the field names are passed. We need to
		// use the short versions when loading the features, so we 
		// need to convert.
		shortFields = new String[fields.length];
		for (int i=0; i<fields.length; i++) 
			shortFields[i] = fields[i].toUpperCase().replaceAll("-", "");

        if (fields != null) {
			featureScores = new double[fields.length];
            for (int i = 0; i < fields.length; i++) 
                featureScores[i] = weights[i];
        }

        useScores = true;
        isValueBased = true;
    }

}
