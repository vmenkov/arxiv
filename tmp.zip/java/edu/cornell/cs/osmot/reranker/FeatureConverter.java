package edu.cornell.cs.osmot.reranker;

import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Enumeration;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.File;
 
import edu.cornell.cs.osmot.logger.Logger;
import edu.cornell.cs.osmot.options.Options;

/**
 * This class implements converting between feature names and numbers. It is
 * used by our learned ranking function.
 * 
 * @author Filip Radlinski
 * @version 1.0, April 2005
 */
public class FeatureConverter {

	// We store the list of all features we know in two hash tables. The first
	// maps names to ids, the second maps ids to names. The names in FeatureIds
	// are made ALL CAPS to make them case insensitive. The names in FeatureNames
	// are not made all caps so as to preserve the way users like them displayed.
	private Hashtable featureIds;
	private Hashtable featureNames;

	private static boolean debug = Options.getBool("DEBUG");
	
	private long maxId;

	/**
	 * The constructor just loads a list of features from a file.
	 * 
	 * @param featureFile
	 *            The file with the list of features.
	 */
	public FeatureConverter(String featureFile) throws IOException {

		maxId = 0;
		loadFeatures(featureFile);
	}

	/** Loads the features from the file specified */
	private synchronized void loadFeatures(String filename) throws IOException {

		if(debug) Logger.log("Loading features from "+filename);

		featureIds = new Hashtable(10000);
		featureNames = new Hashtable(10000);
		
		// Open the model file, if it exists (if not, there are just no
		// features)
		File f = new File(filename);
		if (!f.canRead())
			return;

		BufferedReader in = new BufferedReader(new InputStreamReader(
				new FileInputStream(filename)));

		String line = in.readLine();
		while (line != null) {
			
			// There is one feature per line.
			StringTokenizer st = new StringTokenizer(line);

			while (st.hasMoreTokens()) {

				// Its the name followed by the ID
				String name = st.nextToken();
				String idStr = st.nextToken();
				
				long id = Integer.parseInt(idStr);

				// Record the maximum id seen
				if (id > maxId)
					maxId = id;

				// Make the feature
				makeFeature(name, id);
			}
			line = in.readLine();
		}
		//log("Features loaded.");
		in.close();
	}

	/**
	 * Save the features to a file.
	 * 
	 * @param filename
	 *            The name of the file where to save the features.
	 */
	public synchronized void saveFeatures(String filename) throws IOException {

		Enumeration e = featureNameEnumeration();
		
		BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(filename)));

		if (debug) Logger.log("Saving features to "+filename+".");
		
		while (e.hasMoreElements()) {
			String key = (String) e.nextElement();
			
			if (key == null)
				 Logger.log("Error: null key when saving features.");
				 
			//System.out.println("Key is "+key+", calling featureId");
			
			out.write(key + " " + featureId(key) + "\n");
			
			//System.out.println("Feature id is "+featureId(key));
		}

		out.close();
	}

	/**
	 * Return an enumeration of all the feature names present.
	 * 
	 * @return An enumeration of all the feature names present.
	 */
	public Enumeration featureNameEnumeration() {
		//Logger.log("Feature enumeration has "+featureNames.size()+" entries.");
		
		return featureNames.elements();
	}

	/**
	 * Return the id of a feature with a given name, creating it if create is
	 * true and the feature does not exist.
	 * 
	 * @param name
	 *            The feature name
	 * @param create
	 *            If true, the feature is created if it does not exist.
	 * @return The id of the feature with the given name, or -1 if create is
	 *         false and it doesn't exist.
	 */
	public synchronized long featureId(String name, boolean create)
			throws IOException {

		// If we don't create, just call the regular lookup.
		if (create == false) {

			return featureId(name);

		} else {

			long id = featureId(name);

			// If it wasn't found, create it.
			if (id == -1) {
				//System.out.println("Asked for feature "+name+", missing so creating.");
				maxId++;
				id = maxId;
				makeFeature(name, id);
			}

			return id;
		}
	}

	/** Create a feature with this name and id */
	private synchronized void makeFeature(String name, long id)
			throws IOException {

		//System.out.println("Making a feature "+name+" "+id);
		
		featureIds.put(name.toUpperCase(), new Long(id));
		featureNames.put(new Long(id), name);

	}

	/**
	 * Return the id of a feature with a given name.
	 * 
	 * @return The id of a feature with a given name, or -1 if it doesn't exist.
	 */
	public long featureId(String name) {

		String wanted = name.toUpperCase();
		
		Long i = (Long) featureIds.get(wanted);
		if (i != null)
			return i.longValue();
		
		return -1;
	}
	
	public String featureName(long id) {
		String s = (String) featureNames.get(new Long(id));

		// Should we return null or something else?
		if (s == null)
			return null;

		return s;
	}
	
	public long numFeatures() {
		return featureIds.size();
	}
}
