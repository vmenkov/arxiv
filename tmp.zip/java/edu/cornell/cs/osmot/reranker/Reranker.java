package edu.cornell.cs.osmot.reranker;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Hashtable;
import java.util.HashSet;
import java.util.StringTokenizer;
import java.util.Enumeration;
import java.util.Arrays;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;

import edu.cornell.cs.osmot.searcher.ScoredDocument;
import edu.cornell.cs.osmot.searcher.Searcher;
import edu.cornell.cs.osmot.logger.Logger;
import edu.cornell.cs.osmot.options.Options;

/**
 * This class implements the learned ranking function for the search engine. It
 * allows ranking functions to call it to compute learned scores based on the
 * original scores. 
 * 
 * @author Filip Radlinski
 * @version 2.0, May 2006
 */
public class Reranker {

	/* We store the model in three parts for quick access. 
	 * 1. modelTDFs: The term/document features are stored as a hashtable 
	 * of hashtables by word then document.
	 * 3. modelWeights: All the other features are stored here.
	 */ 
	
	private Hashtable tdfWeights; // The term-document features are stored here
	private Hashtable otherWeights;
	
	private String modelFile;
	protected String fields[];
	protected String shortFields[];
	
	protected double rankWeights[][];
	protected double scoreWeights[][];
	
	// This is used for an experiment where we use the actual scores returned
	// in a very direct way. Assume its false in trying to understand the code.
	protected boolean isValueBased = false;
	protected double featureScores[];
	
	private FeatureConverter fc;
	
	protected boolean useScores;
	
	protected boolean debug;
	
	/**
	 * Create a new reranker given the specified model file.
	 * 
	 * @param modelFile   The filename the SVM model is stored in.
	 * @param fConv       Converts feature names to and from ids
	 * @param fields      The names of the fields in the index
	 * @param scoreBased  Are we using the score features, or rank features?
	 * @param valueBased  If scoreBased, if this is true we just have a
	 *                    constant factor to multiply the scores on each 
	 *                    field by.
	 */
	public Reranker(String mFile, FeatureConverter fConv, String[] fields,
			boolean scoreBased, boolean valueBased)
			throws IOException {

		String name, fname;

		debug = Options.getBool("DEBUG");
		
		this.modelFile = mFile;
		this.fields = fields;
		
		// The long version of the field names are passed. We need to
		// use the short versions when loading the features, so we 
		// need to convert.
		shortFields = new String[fields.length];
		for (int i=0; i<fields.length; i++) 
			shortFields[i] = fields[i].toUpperCase().replaceAll("-", "");
		
		this.fc = fConv;
		
		// Load the model
		tdfWeights = new Hashtable();
		otherWeights = new Hashtable();
		loadModel(modelFile, tdfWeights, otherWeights);
		if (debug) log("Models loaded.");
		
		// Compute the score for being in the top-n results for each field.
		if (fields != null) {
			rankWeights = new double[fields.length][];
			for (int i = 0; i < fields.length; i++) {
				fname = shortFields[i];

				rankWeights[i] = new double[100];
				name = "TOP-" + fname + "-100";
				rankWeights[i][99] = modelValue(name);
				if (debug) log(name + " => " + rankWeights[i][99]);
				for (int j = 99; j >= 1; j--) {
					name = "TOP-" + fname + "-" + j;

					rankWeights[i][j - 1] = rankWeights[i][j]
							+ modelValue(name);
					if(debug) log(name + " => " + rankWeights[i][j - 1]);
				}
			}
		} else {
			rankWeights = new double[0][];
		}
		
		// Compute the score for getting specific sub-scores for each field.
		if (fields != null) {
			scoreWeights = new double[fields.length][];

			// Unused unless isValueBased is true. Used to multiply
			// incoming scores by some constant.
			featureScores = new double[fields.length];

			for (int i = 0; i < fields.length; i++) {
				fname = shortFields[i];
			
				name = "SCORE-"+fname;
				featureScores[i] = modelValue(name);
				
				scoreWeights[i] = new double[Learner.scoreThresholds.length];
				for (int j=Learner.scoreThresholds.length-1; j>=0; j--) {
					name = "SCORE-"+fname+"-"+Learner.scoreThresholds[j];		
					if (j != Learner.scoreThresholds.length-1)
						scoreWeights[i][j] = scoreWeights[i][j+1] + modelValue(name);
					else
						scoreWeights[i][j] = modelValue(name);
					if(debug) log(name + " => " + scoreWeights[i][j]);
				}
			}
		}
		
		useScores = scoreBased;
		isValueBased = valueBased;
	}

    public Reranker() throws IOException {

    }

	public boolean useScores() {
		return useScores;
	}
	
	public boolean useRanks() {
		return !useScores;
	}

	public boolean valueBased() {
		return isValueBased;
	}
	
	/** 
	 * Return a brief id of the model files, so we know which version we're using
	 */
	public String getId() {
		String id = "r";

		// The hash of the file name
		id += Math.abs(modelFile.hashCode() % 1000);
		
		// The 1000s of seconds of the last modified date
		long lmod = new java.io.File(modelFile).lastModified();
		id += "." + Math.abs((lmod / 1000) % 1000);
	
		return id;
	}
	
	/**
	 * Return the fields this reranker knows about.
	 * 
	 * @return the fields this reranker knows about.
 	 */
	public String[] getFields() {
		return fields;
	}
	
	/**
	 * Return the score according to what the reranker says it should be, translating
	 * from the rank or the original score of the document.
	 */
	public double score(int fieldId, double score) {
		if (useScores)
			return scoreScore(fieldId, score);
		else // this is a rank, not a score
			return rankScore(fieldId, (int)score);
	}
	
	/**
	 * Return the score according to the learner ranking model for being ranked
	 * rank according to field number fieldNo. The is the sum of TOP-field-1
	 * through TOP-field-(rank+1). This is the dot product of the rank weights
	 * with the rank features.
	 * 
	 * @param fieldNo
	 *            The field this document was ranked on
	 * @param rank
	 *            The rank of this document accourding to this field.
	 * @return The score for being ranked here by this field.
	 */
	private double rankScore(int fieldNo, int rank) {
		if (fieldNo < rankWeights.length && rank < rankWeights[fieldNo].length)
			return rankWeights[fieldNo][rank];

		// Ranked below the number of ranked weights we actually think about.
		return 0;
	}
	
	/**
	 * Return the score according to the learner ranking model for being score
	 * by a searcher on a given field with field number fieldNo. The is the sum 
	 * of SCORE-field-(low score) through SCORE-field-(just below this score). 
	 * 
	 * @param fieldNo
	 *            The field this document was ranked on
	 * @param origScore
	 *            The original score accourding to this field.
	 * @return The score for being ranked here by this field.
	 */
	private double scoreScore(int fieldNo, double origScore) {
		if (isValueBased) 
			return origScore * featureScores[fieldNo];
			
		if (fieldNo < rankWeights.length) {
			for (int i=0; i<Learner.scoreThresholds.length; i++) {
				if (origScore >= Learner.scoreThresholds[i])
					return scoreWeights[fieldNo][i];
			}
		}
				
		// Ranked below the number of ranked weights we actually think about.
		return 0;
	}

	/**
	 * Returns the documents that have non-zero term document scores for this query
	 */
	public HashSet tdfDocs(String query) {
		
		HashSet tdfDocs = new HashSet(100);
		
		if (!Options.getBool("LEARNER_NO_TDF")) {
			
			// Split on non-words characters.
			String[] queryWords = tokenize(query.toUpperCase(), true);
			
			// For each non-empty word, add the document ids (keys in the hashtable)
			for (int j = 0; j < queryWords.length; j++) {
				if (queryWords[j] != null && queryWords[j].length() > 0) {
					Hashtable ht = (Hashtable)tdfWeights.get(queryWords[j]);
					if (debug) log("Looking up '"+queryWords[j]+"' gives "+ht);
					if (ht != null)
						tdfDocs.addAll(ht.keySet());
				}
			}
			
			if (debug) log("The "+queryWords.length+" words in "+query+" are associated with "+tdfDocs.size()+" docs");

		}
				
		return tdfDocs;
	}
	
	/** 
	 * Add the TDF score to this scored document given this query, as well as anything
	 * else we have for it (e.g. the age, personalization features, etc).
	 */
	public void addTDFScore(ScoredDocument sd, String query) throws IOException {
		
		// Update the age
		int age = sd.getAge("date") / 365;
		double ageScore = 0;
		
		if (Options.getBool("LEARNER_VALUE_FEATURES")) {
			String name = "SCORE-AGE";
			ageScore = modelValue(name) * age;
		} else {
			if (age != -1) {
				for (int j=0; j<=age; j++) {
					String name = "AGE-"+j;
					ageScore += modelValue(name);
				}
			}
		}
			
		sd.updateScore(ageScore, "Age is "+age);

		// Split on non-words characters.
		String[] queryWords = tokenize(query.toUpperCase(), true);

		// For each non-empty word, update the score
		for (int j = 0; j < queryWords.length; j++) {
			if (queryWords[j] != null && queryWords[j].length() > 0) {
				
				String featureName = tdfFeatureName(queryWords[j], sd.getUniqId());
				double weight = modelValue(featureName);
				if (weight != 0)
					sd.updateScore(weight, "Term/Doc feature "+featureName);
			}
		}
	}
	
	/**
	 * @deprecated You should call scoreScore, rankScore, addTDFScore and tdfDocs instead.
	 * 
	 * Reranks the results using the term/document features. The feature
	 * converter is a parameter since multiple rerankers share the same feature
	 * converter for efficiency.
	 * 
	 * @param results
	 *            The results to rerank, collected using the rank features.
	 * @param query
	 *            The query.
	 * @param fc
	 *            A featureConverter to convert feature names to ids.
	 * @param s
	 *            An Searcher, so we can fetch documents we don't have in
	 *            results.
	 * @param ip
	 *            The ip address that asked for the results (will be used in the
	 *            future).
	 */
	public ScoredDocument[] rerank(ScoredDocument[] results, String query,
			FeatureConverter fc, Searcher s, String ip) throws IOException {

		// In the future, we will include features that are IP specific for
		// personalized searching. This line is here to stop the compiler from
		// giving us a warning that the variable is ignored.
		if (ip == null || ip.equals(""))
			ip = "Ignore";
		
		// Make a hash table of the results
		Hashtable hResults = new Hashtable(results.length);

		for (int i = 0; i < results.length; i++) {
			int age = results[i].getAge("date");

			// Update the score based on the age before inserting the document
			double ageScore = 0;

			if (Options.getBool("LEARNER_VALUE_FEATURES")) {

				ageScore = modelValue("SCORE-AGE") * age;

			} else {

				if (age != -1) {
					for (int j=0; j<=age; j++) {
						ageScore += modelValue("AGE-"+j);
					}
				}
			}
				
			results[i].updateScore(ageScore, "Age is "+age);
			hResults.put(results[i].getUniqId(), results[i]);
		}
		
		// Get the category in the query, if present, for filtering.
		String category = getCategory(query);

		// Split on non-words characters.
		String[] queryWords = tokenize(query, true);

		// If we didn't learn the word weights, there is no point
		// updating the scores this way.
		if (Options.getBool("LEARNER_NO_TDF"))
		    queryWords = new String[0];

		// For each non-empty word
		for (int j = 0; j < queryWords.length; j++) {
			if (queryWords[j].length() > 0) {

				// For each feature for this word
				Hashtable h = (Hashtable)tdfWeights.get(queryWords[j]);
				if (h != null) {
					Enumeration e = h.keys();
					while (e.hasMoreElements()) {

						// Get the unique identifier of the term/document,
						// as well as the associated weight in the model.
						String uniqId = (String) e.nextElement();
						double value = modelValue(tdfFeatureName(queryWords[j],uniqId));

						if (value != 0) {

							// Get the document result, add if its not in the
							// results yet.
							ScoredDocument sd = (ScoredDocument) hResults
									.get(uniqId);
							if (sd != null) {

								// Just update the score, reinsert into results.
								sd.updateScore(value, "Word " + queryWords[j]
										+ " and Doc " + uniqId);
								hResults.remove(uniqId);
								hResults.put(uniqId, sd);

							} else {
								// Add to the results, the document isn't there
								// yet.
								// Also check if the document is in the right
								// category.

								// Fetch the document.
								sd = s.getDoc(uniqId);

								// Here we check the category of the document
								// matches. The one
								// line is collection specific (we assume there
								// is a field
								// category but if it doesn't exist, this code
								// shouldn't
								// hurt).
								boolean ok = true;
								if (category != null
										&& sd.getDoc().get("category") != null) {
									if (!sd.getDoc().get("category").equals(
											category))
										ok = false;
								}

								if (ok) {
									sd.updateScore(value, "Word "
											+ queryWords[j] + " and Doc "
											+ uniqId);
									hResults.put(uniqId, sd);
								}
							}
						}
					} // End of loop over documents
				} // End of check if h null
			} // End of check if word length non-zero
		}

		/**
		 * These are features that we currently do not use, but may be
		 * considered in later versions of this code. This code here is not
		 * tested but has been left to illustrate what other features may be
		 * useful.
		 *  // For IP-based features, currently not used String ips[] =
		 * ip.split("\\.");
		 * 
		 * String name, uniqId, category; int age;
		 *  // We only apply these features to documents already in the //
		 * results for the sake of efficiency.
		 * 
		 * Enumeration = results.keys(); while(e.hasMoreElements()) {
		 * 
		 * uniqId = (String)e.nextElement(); ScoredDocument sd =
		 * (ScoredDocument)results.get(uniqId);
		 * 
		 * category = sd.getField(Options.UNIQ_ID_FIELD); category =
		 * category.replaceFirst("\\/.*","");
		 * 
		 * String authors[] = sd.getField("authors").split("[^A-Za-z-]+"); 
		 * 
		 *  // Aauthor-Ccategory, Qword-Aauthor for(int j=0; j <authors.length;
		 * j++) { name = "A"+authors[j]+"-C"+category; featureId =
		 * fc.featureId(name); sd.updateScore(modelValue(featureId),name);
		 * 
		 * for(int k=0; k <queryWords.length; k++) { name =
		 * "Q"+queryWords[k]+"-A"+authors[j]; featureId = fc.featureId(name);
		 * sd.updateScore(modelValue(featureId), name); } }
		 *  // IP specific features. for(int j=2; j <=4; j++) { name = "IP";
		 * 
		 * for(int k=0; k <j; k++) { name = name+ips[k]; if (k!=j-1) name =
		 * name+"."; } featureId = fc.featureId(name+"-C"+category);
		 * sd.updateScore(modelValue(featureId), name+"-C"+category); for(int
		 * k=0; k <authors.length; k++) { featureId =
		 * fc.featureId(name+"-A"+authors[k]);
		 * sd.updateScore(modelValue(featureId), name+"-A"+authors[k]); } }
		 * 
		 * results.remove(uniqId); results.put(uniqId, sd); }
		 *  
		 */

		ScoredDocument[] newResults = Searcher.hashtableToArray(hResults);
		Arrays.sort(newResults);

		// Convert back to an array and return
		return newResults;
	}

	/**
	 * Return the name of the model file used for this reranker.
	 * 
	 * @return The name of the model file used for this reranker.
	 */
	public String getModelFile() {
		return modelFile;
	}
	
	/**
	 * Load a linear SVM model by adding the feature scores weighted by the
	 * alpha values of each of the support vectors. Note that this only makes
	 * sense for a linear model.
	 * 
	 * @param filename
	 *            The file containing the SVM model to load.
	 * @return A hashtable containing the model in a compressed form (suport
	 *         vectors have been collapsed).
	 */
	private void loadModel(String filename, Hashtable tdfs, 
			Hashtable otherWeights) throws IOException {

		// Weights go through this hashtable first
		Hashtable allWeights = new Hashtable(10000);
		
		if(debug) log("Attempting to read model " + filename);

		// Open the model file
		BufferedReader in = new BufferedReader(new InputStreamReader(
				new FileInputStream(filename)));

		// Skip the first 7 lines, we want the line with highest feature index
		if (in.readLine() == null)
			// No model, blank file was just created
			return; 
		
		for (int i = 0; i < 6; i++)
			in.readLine();

		// Extract the highest feature index
		String line = in.readLine();
		int highestFeatureIndex = Integer.parseInt(line.substring(0, line
				.indexOf(" ")));

		// Skip the next 4 lines until the start of the support vectors
		for (int i = 0; i < 3; i++)
			in.readLine();

		if(debug) log("There are up to " + highestFeatureIndex + " features in the model");

		// For every support vector
		line = in.readLine();
		while (line != null) {

			// For every feature
			StringTokenizer st = new StringTokenizer(line);
			double alpha = Double.parseDouble(st.nextToken());
			while (st.hasMoreTokens()) {

				String token = st.nextToken();
				String split[] = token.split(":");

				// The new version of SVM light has support vector lines ending
				// with a # then comments.
				if (split.length == 1)
					break;
				if (split[0].charAt(0) == '#')
					break;

				long featureIndex = Long.parseLong(split[0]);
				Long index = new Long(featureIndex);

				double value = alpha * Double.parseDouble(split[1]);

				// Add old value, if present
				Double oldValue = (Double) allWeights.get(index);
				if (oldValue != null)
					value += oldValue.doubleValue();

				// Remove a zero value, otherwise add the value (this replaces
				// any old value).
				if (value == 0) {
					allWeights.remove(index);
				} else {
					allWeights.put(index, new Double(value));
				}
			}
			line = in.readLine();
		}

		in.close();

		// Split the weights among two sets: the term document features
		// and the other features.
		Enumeration e = allWeights.keys();
		
		while (e.hasMoreElements()) {
			Long featureId = (Long)e.nextElement();
			String name = fc.featureName(featureId.longValue());
			Double weight = (Double)allWeights.get(featureId);
			
			// tdf Weights are of the form "W<term>-D<document>". They go in a hashtable
			// of hashtables. Other weights just go straight in. We have to remember
			// to make sure no new features start with W.
			
			if (debug) log("Loading feature "+name+" with id "+featureId+" and weight "+weight);
			
			if (isTDF(name)) {

				String term = tdfTerm(name);
				String document = tdfDocument(name);

				if (debug) log("It is a TDF for term "+term+" and doc "+document);
				
				Hashtable docTable = (Hashtable)tdfs.get(term);
				if (docTable == null)
					docTable = new Hashtable(10);
				docTable.put(document, weight);
				tdfs.put(term, docTable);
				
			} else {
				
				if (debug) log("It is not a TDF");
				
				otherWeights.put(name, weight);
			}

		}
	}
	
	/**
	 * Return the value of the given feature name from the model.
	 * 
	 * @param name The name of the feature.
	 * @return The value of this feature.
	 */	
	public double modelValue(String name) {
	
		if (name == null)
			return 0;
		
		double weight = 0;
		
		if (isTDF(name)) {
			Hashtable ht = (Hashtable)tdfWeights.get(tdfTerm(name));
			if (ht != null) {
				Double d = (Double)ht.get(tdfDocument(name));
				if (d != null)
				weight = d.doubleValue();
			}
		} else {
			Double d = (Double)otherWeights.get(name);
			if (d != null)
				weight = d.doubleValue();
		}
		
		return weight;
	}

	/**
	 * Returns true if this is a term/document feature, which are marked as
	 * starting with a "W"
	 *  
	 * @param name The name of the feature
	 * @return True if the feature is a term/document feature, false otherwise
	 */
	public static boolean isTDF(String name) {
		if (name == null)
			return false;
		 
		if (name.toUpperCase().substring(0,1).equals("W"))
			return true;

		return false;
	}
	
	public static String tdfTerm(String name) {
		return name.substring(1, name.indexOf('-')).toUpperCase();
	}
	
	public static String tdfDocument(String name) {
		return name.substring(name.indexOf('-') + 2);
	}
	
	public static String tdfFeatureName(String term, String document) {
		return "W"+term.toUpperCase()+"-D"+document;
	}
	
	/**
	 * Return a string representation of the model.
	 */
	public void printModel(PrintStream s) {

		String result;

		Enumeration e = fc.featureNameEnumeration();
		while (e.hasMoreElements()) {

			result = "";
			
			String feature = (String) e.nextElement();
			if (isTDF(feature)) {

				Hashtable ht = (Hashtable)tdfWeights.get(tdfTerm(feature));
				Enumeration e2 = ht.keys();

				while (e2.hasMoreElements()) {

					String document = (String) e2.nextElement();
					long featureId = fc.featureId(feature);
					double value = ((Double)tdfWeights.get(document)).doubleValue();

					if (value != 0)
						result = feature + " \t" + featureId
								+ ":\t" + value;
				}
			} else if (feature.equals("TOTAL_FEATURES")) {
				// Don't output, its special
			} else {
				long featureId = fc.featureId(feature);
				double value = ((Double)otherWeights.get(feature)).doubleValue();
				if (value != 0)
					result = feature + " \t" + featureId + ":\t" + value;
			}
			
			if (result.length() > 0)
				s.println(result);
		}
	}

	/**
	 * Tokenize the query into our features.
	 * 
	 * @param query
	 *            The query
	 * @return The query, tokenized.
	 */
	public static String[] tokenize(String query, boolean removeStopwords) {

		// Remove the category if its specified, as well as any
		// occurrences of the word AND and special characters.
		String newQuery = query.replaceAll("category:[a-z]+", "").replaceAll(
				" AND ", " ");
		newQuery = newQuery.replaceAll("^AND", " ").replaceAll(" AND$", " ");
		newQuery = newQuery.replaceAll("[\\+\\*\\?\\,\\(\\)]+", "").replaceAll(
				" +", " ");

		// Check for strings that look like a paper id, don't break
		// those: Replace the [-./] with a "Z" as a marker. For
		// example cs.ab/1234567 would become csZabZ1234567. Since
		// this is consistently done both when learning and searching,
		// we won't have any trouble. What we want to avoid is a
		// search for cs.ab/1234567 being broken into cs, ab, 1234567
		// and then in learning term-feature weights the parts. Yes,
		// this is a terrible hack.
		Pattern p = Pattern
				.compile("(^|\\W)([a-z\\.-]{2,9}/[0-9]{7,7})($|\\W)");
		Matcher m = p.matcher(newQuery);
		while (m.find()) {
			String paperName = m.group(2);
			paperName = m.group(1)
					+ paperName.replaceAll("\\.", "Z").replaceAll("-", "Z")
							.replaceAll("/", "Z") + m.group(3);
			newQuery = m.replaceFirst(paperName);
			m = p.matcher(newQuery);
		}

		// Split on non-words characters.
		String split[] = newQuery.split("\\W+");

		// Just take the non-blank splits (split does weird things)
		int tokens = 0;
		for (int i = 0; i < split.length; i++) {
			if (!split[i].equals("") && (!removeStopwords || !isStopword(split[i])))
				tokens++;
		}
		String cleanSplit[] = new String[tokens];
		int curPos = 0;
		for (int i = 0; i < tokens; i++) {
			// Find the next good token
			boolean notOk = true;
			while (curPos < split.length && notOk) {
				notOk = false;
				if (split[curPos].equals(""))
					notOk = true;
				if (removeStopwords && isStopword(split[curPos]))
					notOk = true;

				if (notOk)
					curPos++;
			}

			// Save it & move on to the next potential word
			if (curPos < split.length)
				cleanSplit[i] = split[curPos];
			curPos++;
		}

		/*
		 * log("query "+query+" was split into "); String msg = ":"; for(int
		 * i=0; i < cleanSplit.length; i++) { msg += cleanSplit[i]+":"; }
		 * log(msg);
		 */

		return cleanSplit;
	}

	/*
	 * Returns true of the string s is not a stopword. Uses a Lucene table of
	 * stopwords. @param s The word to test. @return true of s is not a
	 * stopword.
	 */
	private static boolean isStopword(String s) {
		String[] sw = org.apache.lucene.analysis.standard.StandardAnalyzer.STOP_WORDS;
		s = s.toLowerCase();

		for (int i = 0; i < sw.length; i++) {
			if (s.equals(sw[i]))
				return true;
		}

		return false;
	}

	/**
	 * Returns the category in the query, if any.
	 * 
	 * @param query
	 *            The query
	 * @return The category the query requires, or null if none is present.
	 */
	private static String getCategory(String query) {

		String pattern = "[^a-z]category:([a-z]*)";
		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(query.toLowerCase());
		if (m.find()) {
			return m.group(1);
		}

		return null;
	}

	/**
	 * Allows printing of the model for debugging purposes.
	 */
	public static void main(String args[]) {

		Reranker r;

		if (args.length == 1) {

			try {
				FeatureConverter fc = new FeatureConverter(Options.get("RERANKER_FEATURE_FILE"));
				r = new Reranker(args[0], fc, null, Options.getBool("SEARCHER_USE_SCORES"), false);
			} catch (IOException e) {
				System.err.println(e);
				return;
			}

			r.printModel(System.out);

		} else {
			System.out.println("Usage:\n\tReranker <model>\n");
		}
	}

	/**
	 * Log a message to the general log file.
	 * 
	 * @param msg
	 *            The message to log.
	 */
	private static void log(String msg) {
		Logger.log(msg);
	}
	
	public String toString() {
		return "Reranker from "+modelFile+". "+tdfWeights.size()+" TDF words, "+otherWeights.size()+" other weights.";
	}
}

// Used to store term/document features. We keep these twice: once
// so that we can look them up by id, and a second time sorted by
// score.
class TermDocFeature implements Comparable {
	public int featureId;
	public String featureName;
	public double featureWeight;
	
	TermDocFeature(int id, String name, double weight) {
		featureId = id;
		featureName = name;
		featureWeight = weight;
	}
	
	public int compareTo(Object obj) {
		double weight = ((TermDocFeature)obj).featureWeight;

		if (weight == this.featureWeight)
			return 0;
		else if (this.featureWeight < weight)
			return -1;

		return 1;
	}
}
