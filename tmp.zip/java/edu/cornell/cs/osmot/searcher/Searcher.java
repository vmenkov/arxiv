package edu.cornell.cs.osmot.searcher;

import org.apache.lucene.document.Document;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.Hits;

import java.util.Hashtable;
import java.util.Random;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Arrays;
import java.lang.StringBuffer;

import java.io.IOException;

import edu.cornell.cs.osmot.logger.Logger;
import edu.cornell.cs.osmot.options.Options;
import edu.cornell.cs.osmot.reranker.Reranker;

/**
 * This class implements the biggest chunk of the search engine. Given a query
 * and a search mode, it runs the query and returns ranked results.
 * 
 * @author Filip Radlinski
 * @version 1.0, April 2005
 */
public abstract class Searcher {

	public static String modes[] = { "1a", "1b", "1c", "2a", "2b", "2c", "3a", "3b", 
				"dt", "4a", "4b", "4c", "4d", "5a", "5b", "5c", "5d", "5e", 
				"6a", "6b", "6c", "6d", "6e", "6f", "7a", "7b", "7c", "7d", "7e", 
				"7f", "8a", "8b", "8c", "8d", "9a", "9b", "9c", "9d", "9e" , "9f", "9g", "9h",
                "90a", "90b", "90c", "90d", "90e", "90f", "90g", "90h",
                "9ab", "9ac", "9ad", "9ae", "9af", "9ag", "9ah",
                "9bc", "9bd", "9be", "9bf", "9bg", "9bh",
                "9cd", "9ce", "9cf", "9cg", "9ch",
                "9de", "9df", "9dg", "9dh",
                "9ef", "9eg", "9eh",
                "9fg", "9fh",
                "9gh",
                "Aa", "Ab", "Ac","Bab", "Bac", "Bbc", "Aab", "Aac", "Abc"};
	
	protected boolean debug;
	private Random fpRandom;
	private Random wsRandom;
	
	protected String fields[]; // The full field names

	protected String fieldsShort[]; // Field names without dashes

	/**
	 * Initializes the searcher.
	 */
	private void init() throws IOException {

		// Get the fields that exist in the document collection.
		fields = loadFields();
		fieldsShort = new String[fields.length];
		for (int i = 0; i < fields.length; i++) {
			fieldsShort[i] = fields[i].toUpperCase().replaceAll("-", "");
		}
	}

	/**
	 * Create a new searcher with no learned ranking functions. We'll just use
	 * the default ranking function defined below in this class.
	 * 
	 * @param indexDir
	 *            The directory where the Lucene index is stored.
	 */
	public Searcher(String indexDir) throws IOException {
		fpRandom = new Random();
		debug = Options.getBool("DEBUG");
		init();
	}

	/**
	 * Create a blank searcher. Java requires that this exists.
	 */
	public Searcher() {
		fpRandom = new Random();
		wsRandom = new Random();
		debug = Options.getBool("DEBUG");
	}

	/**
	 * Return the original results for this query on each field, returning the hits
	 * 
	 */
	public abstract Hits[] origHits(String query) throws IOException;
	
	/** 
	 * Return a new set of positions for the results. The set should have the length
	 * specified, with the first few positions potentially not reordered (depending 
	 * on the mode).  
	 * Given ranking 1-2-3-4-5-6, return with equal probability consider reversing 
	 * each pair in as 1-2-3-4-5-6, (2-1)-(4-3)-(6-5) and 1-(3-2)-(5-4)-6 (i.e. 
	 * flip pairs in the possible ways).
	 * 
	 * @param setSize  How large the groups to consider reordering should be
	 * @param mode     The flips are done with different offsets, determined by the
	 * 			       mode: 3a or 3b, 4a-4d.
	 * @param randSeed The random seed to use.
	 * @param length   The length of the total result set to run through
	 * @return Potentially slightly reordered results according to FairPairs
	 */
	public int[] FairPairs(int setSize, String mode, String randSeed, int length) {

		int offset = -1;
		fpRandom.setSeed(randSeed.hashCode());
		
		if (mode.substring(1,2).equals("a"))
			offset = 0;
		else if (mode.substring(1,2).equals("b"))
			offset = 1;
		else if (mode.substring(1,2).equals("c"))
			offset = 2;
		else if (mode.substring(1,2).equals("d"))
			offset = 3;

		if (offset >= setSize || offset == -1) {
			log("Error: FP called with offset bigger than set size, or bad mode "+mode+".");
			return null;
		}
		
		if (debug)
			log("FP: Set size "+setSize+" offset is "+offset+" for "+length+" results");
		
		int results[] = new int[length];
		for (int i=0; i<length; i++)
			results[i] = i;

		double flset[] = new double[setSize];
		int tmp[] = new int[setSize];
		
		//potentially shuffle offset through offset+3
		for (int i=offset; i+setSize-1<results.length; i+=setSize) {
			
			// Randomly order the numbers 0 through 3
			for (int j=0; j<setSize; j++)
				flset[j] = (int)(fpRandom.nextDouble()*100)+0.1*j;
			Arrays.sort(flset);

			// Get the integers back from the random list (its the part after then .) 
			// and use them to make a temporary set of results
			for (int j=0; j<setSize; j++) {
				int k = (int)Math.round(10.0*(flset[j]-Math.floor(flset[j])));
				flset[j] = k;
				tmp[j] = results[i+k];
			}
									
			// Put tmp back into results
			for (int j=0; j<setSize; j++)
				results[i+j] = tmp[j];
			
		}
		
		// If there are at least 50 results, there is an 90% chance
		// that one of the top 8 results is randomly swapped with 
		// result 50
		if (results.length >= 50 && fpRandom.nextDouble() < 0.9) {
			int pos = fpRandom.nextInt(8);
			tmp[0] = results[pos];
			results[pos] = results[49];
			results[49] = tmp[0];
		}
		
		if (debug) {
			Logger.log("FairPairs complete: ");
			StringBuffer s = new StringBuffer();
			for (int i=0; i<results.length; i++)
 				s = s.append(" ").append(results[i]);
 			Logger.log(s.toString());
		}
		
		return results;
	}

	/** 
	 * Return a new set of positions for the results. The set should has length 10
	 * with a fixed number of swaps between the top 5 and bottom 5. This is done 
	 * to intentially degrade the performance of a ranking.
	 * 
	 * @param numFlips The number of flips
	 * @param randSeed The random seed to use.
	 * @return Tweaked ranking order of 10 ints
	 */
	public int[] WorseShuffle(int numFlips, String randSeed, int length) {
		return WorseShuffle(numFlips, randSeed, length, 5);
	}
	
	/** 
	 * Return a new set of positions for the results. The set should has length 10
	 * with a fixed number of swaps between the top 5 and bottom 5. This is done 
	 * to intentially degrade the performance of a ranking.
	 * 
	 * @param numFlips The number of flips
	 * @param randSeed The random seed to use.
     * @param halfLength Each interval of 2*halfLength has its first half swapped with second half
	 * @return Tweaked ranking order of 2*halfLength hits
	 */
	public int[] WorseShuffle(int numFlips, String randSeed, int length, int halfLength) {

		wsRandom.setSeed(randSeed.hashCode());
		
		if (debug)
			log("WorseShuffle: "+numFlips+" flips, seed is "+randSeed+" half length is "+halfLength);
		
		int results[];

		if (length >= 10) {
			results = new int[length];
			for (int i=0; i<length; i++)
				results[i] = i;
			
			for (int i=0; i<numFlips; i++) {
				// Pick a random int in 0 to halfLenght-1, make sure it is new
				int picked = wsRandom.nextInt(halfLength);
				while (results[picked] != picked)
					picked = wsRandom.nextInt(halfLength);
				
				// Now pick a target
				int target = wsRandom.nextInt(halfLength)+halfLength;
				while (results[target] != target)
					target = wsRandom.nextInt(halfLength)+halfLength;
	
				// Do the swap
				int tmp = results[target];
				results[target] = results[picked];
				results[picked] = tmp;
			}
			
			// Now replicate this same shuffle throughout
			int full = 2*halfLength;
			for (int i=full; i<length - length%full; i++)
				results[i] = results[i%full]+(i-i%full);
			
			// Print out the shuffle we came up with for debugging.
			if (debug) {
				Logger.log("WorseShuffle complete: ");
				StringBuffer s = new StringBuffer();
				for (int i=0; i<results.length; i++)
	 				s = s.append(" ").append(results[i]);
	 			Logger.log(s.toString());
			}
						
		} else {
			results = new int[length];
			for (int i=0; i<length; i++)
				results[i] = i;
		}
			
		return results;
	}	
	
	/**
	 * Return a snippet for this document for this query. Some searchers may 
	 * want to over-ride this.
	 * 
	 * @param d     The document to get a snippet of.
	 * @param query The query to return a snippet for.
	 * @return The snippet to display.
	 */
	public String getSnippet(ScoredDocument d, String query) {
		return Snippeter.getSnippet(d.getDoc(), query, false, false);
	}

	/**
	 * Return an extended snippet for this document for this query. Some searchers may 
	 * want to over-ride this.
	 * 
	 * @param d     The document to get a snippet of.
	 * @param query The query to return a snippet for.
	 * @return The snippet to display.
	 */
	public String getLongSnippet(Document d, String query) {
		return Snippeter.getSnippet(d, query, true, false);
	}

	/**
	 * Return an extended snippet for this document for this query. Some searchers may 
	 * want to over-ride this.
	 * 
	 * @param d     The document to get a snippet of.
	 * @param query The query to return a snippet for.
	 * @return The snippet to display.
	 */
	public String getPaperSnippet(Document d, String query) { 
		return Snippeter.getSnippet(d, query, true, true);
	}
	
	/**
	 * Return an extended snippet for this document for this query. Some searchers may 
	 * want to over-ride this.
	 * 
	 * @param d     The document to get a snippet of.
	 * @param query The query to return a snippet for.
	 * @return The snippet to display.
	 */
	public String getAbstractSnippet(Document d, String query) { 
		return Snippeter.getAbstractSnippet(d, query, false);
	}
	
	/**
	 * Search for this query, then rerank the results with the specified
	 * reranker.
	 * 
	 * @param query
	 *            The query to run
	 * @param reranker
	 *            The reranker to use (for rank features), or null of none.
	 *            ip-dependent rerankings.
	 * @return The ranked results of the search.
	 */
	public abstract RerankedHits search(String query, Reranker reranker)
			throws IOException, ParseException;
	
	/**
	 * Returns the fields in the index searched by this searcher.
	 * 
	 * @return The fields in the index searched by this searcher
	 */
	public final String[] getFields() {
		return fields;
	}

	/**
	 * Returns the document with this id in the searcher
	 * @param docId  Document id in the searcher
	 */
	public abstract Document getDoc(int docId) throws IOException;
	
	/**
	 * Returns the fields in the index searched by this searcher, with dashes
	 * removed from the names.
	 * 
	 * @return The fields in the index with dashes removed.
	 */
	public final String[] getFieldsShort() {
		return fieldsShort;
	}

	/** Load the fields in the index. */
	protected abstract String[] loadFields() throws IOException;

	/**
	 * Pick a random document from the collection.
	 * 
	 * @return The id of a random valid document in the index.
	 */
	protected abstract int randomDoc() throws IOException;

	/**
	 * Pick a random document from the collection in a specific category.
	 * 
	 * @param category
	 *            The category the document should be in
	 * @return The document id
	 */
	protected abstract int randomDoc(String category) throws IOException;

	/**
	 * Return the HTML link of a scored document that should be displayed.
	 * This is collection specific, which is why it is here, despite it being
	 * a method that should intuitively belong in ScoredDocument
	 * @param sd The scored document to generate the link
	 * @return Title string in HTML
	 */
	public abstract String toHtml(ScoredDocument sd);
	
	/**
	 * @deprecated Use the version that combined RerankedHits
	 * 
	 * Combine two sets of results as described in Joachims, T (2003) Evaluating
	 * retrieval performance using clickthrough data. In J Franke, G
	 * Nakhaeizadeh, and I Renz, editors, Text Mining, pages 79-96,
	 * Physica/Springer Verlag, 2003. This allows unbiased comparison of two
	 * ranking functions by intertwining the results.
	 * 
	 * @param results1
	 *            First set of results.
	 * @param results2
	 *            Second set of results.
	 * @param category
	 *            If not null, make sure all documents are in this category.
	 * @param seed
	 *            Random number generator seed.
	 * @return A combined ranking.
	 */
	protected final ScoredDocument[] combine(ScoredDocument[] results1,
			ScoredDocument[] results2, String category, long seed)
			throws IOException {

		if (debug) {
			Logger.log("Combining two result sets. Lengths are " + results1.length + " and " + results2.length);
		}
		
		// Somewhere to store the combined results.
		int maxLength = Math.max(results1.length, results2.length);
		ScoredDocument[] combinedResults = new ScoredDocument[2 * maxLength];

		int indexCombined = 0;
		int index1 = 0; // Index of first element in A not in combined
		int index2 = 0; // Index of first element in B not in combined

		// Used to pick if results1 or results2 gets preference
		Random gen = new Random(seed);
		boolean randomBit = gen.nextBoolean();

		// Make a hash table of document ids to ranks in the two result sets
		Hashtable h1 = new Hashtable(results1.length);
		for (int i = 0; i < results1.length; i++)
			h1.put(results1[i].getUniqId(), new Integer(i));
		Hashtable h2 = new Hashtable(results2.length);
		for (int i = 0; i < results2.length; i++)
			h2.put(results2[i].getUniqId(), new Integer(i));
		Hashtable hCombined = new Hashtable(results1.length + results2.length);

		// Return at most Options.SEARCHER_MAX_DOCS in combined results.
		while (indexCombined < Options.getInt("SEARCHER_MAX_DOCS") + 1
				&& (index1 < results1.length || index2 < results2.length)) {

			// If equal and A has priority, or A is smaller, add A
			if (((index1 == index2) && (!randomBit)) || (index1 < index2)) {

				if (index1 < results1.length) {

					// Check results1 hasn't ended
					String uniqDocId = results1[index1].getUniqId();
					combinedResults[indexCombined] = results1[index1];
					combinedResults[indexCombined].setRanks(getRank(h1, uniqDocId),
							getRank(h2, uniqDocId));
					hCombined.put(uniqDocId,	new Integer(indexCombined));
					index1++;

				} else {

					// If A has ended, pick something random not in A
					// or the combined set

					String docUniqId = "";
					while (docUniqId.equals("")) {
						docUniqId = randomDocUniqId(category);
						if (h1.get(docUniqId) != null
								|| hCombined.get(docUniqId) != null)
							docUniqId = "";
					}

					combinedResults[indexCombined] = getDoc(docUniqId);
					combinedResults[indexCombined].setRanks(index1, getRank(h2,
							docUniqId));
					hCombined.put(docUniqId, new Integer(indexCombined));

					// We need to increment here since we don't get
					// into increment loop below.
					index1++;
				}
			} else { // Else equal and B has priority, or B is smaller
				if (index2 < results2.length) {

					// Check B hasn't ended
					String uniqDocId = results2[index2].getUniqId();
					combinedResults[indexCombined] = results2[index2];
					combinedResults[indexCombined].setRanks(getRank(h1, uniqDocId),
							getRank(h2, uniqDocId));
					hCombined.put(uniqDocId, new Integer(indexCombined));
					index2++;

				} else {
					// If B has ended, pick something random not in B
					// or the combined set

					String uniqDocId = "";
					while (uniqDocId.equals("")) {
						uniqDocId = randomDocUniqId(category);
						if (h2.get(uniqDocId) != null
								|| hCombined.get(uniqDocId) != null)
							uniqDocId = "";
					}

					combinedResults[indexCombined] = getDoc(uniqDocId);
					combinedResults[indexCombined].setRanks(getRank(h1, uniqDocId),
							index2);
					hCombined.put(uniqDocId, new Integer(indexCombined));

					// We need to increment here since we don't get
					// into increment loop below.
					index2++;
				}
			}

			// Update index1 and index2 to be the number of top n elements from
			// restuls1 and results2 to be in the combined list.
			while ((index1 <= indexCombined) && (index1 < results1.length)
					&& (getRank(hCombined, results1[index1].getUniqId()) != -1))
				index1++;

			while ((index2 <= indexCombined) && (index2 < results2.length)
					&& (getRank(hCombined, results2[index2].getUniqId()) != -1))
				index2++;

			indexCombined++;
		}

		// Reset combined to be shorter if we got repeats
		// (Can you shrink an array in Java?)
		ScoredDocument[] combined2 = new ScoredDocument[indexCombined];
		for (int i = 0; i < indexCombined; i++) {
			combined2[i] = combinedResults[i];
		}

		return combined2;
	}

	/**
	 * Combine two sets of results as described in Joachims, T (2003) Evaluating
	 * retrieval performance using clickthrough data. In J Franke, G
	 * Nakhaeizadeh, and I Renz, editors, Text Mining, pages 79-96,
	 * Physica/Springer Verlag, 2003. This allows unbiased comparison of two
	 * ranking functions by intertwining the results.
	 * 
	 * @param results1
	 *            First set of results.
	 * @param results2
	 *            Second set of results.
	 * @param category
	 *            If not null, make sure all documents are in this category.
	 * @param seed
	 *            Random number generator seed.
	 * @return A combined ranking.
	 */
	protected final RerankedHits combine(RerankedHits results1, RerankedHits results2, 
			String category, long seed) throws IOException {
		
		int pl1 = results1.prefixLength();
		int pl2 = results2.prefixLength();
	
		if (debug) {
			Logger.log("Combining two result sets. Prefix lengths are " + pl1 + " and " + pl2);
		}
		
		// Somewhere to store the combined results.
		int maxLength = Math.max(pl1, pl2);
		ScoredDocument[] combinedResults = new ScoredDocument[2 * maxLength];

		int indexCombined = 0;
		int index1 = 0; // Index of first element in A not in combined
		int index2 = 0; // Index of first element in B not in combined

		// Used to pick if results1 or results2 gets preference
		Random gen = new Random(seed);
		boolean randomBit = gen.nextBoolean();

		// Make a hash table of document ids to ranks in the two result sets
		Hashtable h1 = new Hashtable(pl1);
		for (int i = 0; i < pl1; i++)
			h1.put(results1.doc(i).getUniqId(), new Integer(i));
		Hashtable h2 = new Hashtable(pl2);
		for (int i = 0; i < pl2; i++)
			h2.put(results2.doc(i).getUniqId(), new Integer(i));
		Hashtable hCombined = new Hashtable(pl1 + pl2);

		// Combine them all.
		while (index1 < pl1 || index2 < pl2) {

			String uniqDocId = "";
			int rank1 = 0;
			int rank2 = 0;

			// If equal and A has priority, or A is smaller, add A
			if (((index1 == index2) && (!randomBit)) || (index1 < index2)) {
				if (index1 < pl1) {

					// Check results1 hasn't ended
					uniqDocId = results1.doc(index1).getUniqId();
					rank1 = getRank(h1, uniqDocId);
					rank2 = getRank(h2, uniqDocId);

				} else {

					// If A has ended, pick something random not in A
					// or the combined set
					uniqDocId = randomFromCategory(category, hCombined, h1);
					rank1 = index1;
					rank2 = getRank(h2, uniqDocId);
				}

				// We need to increment here since we don't get
				// into increment loop below.
				index1++;
				
			} else { // Else equal and B has priority, or B is smaller
				if (index2 < pl2) {

					// Check B hasn't ended
					uniqDocId = results2.doc(index2).getUniqId();
					rank1 = getRank(h1, uniqDocId);
					rank2 = getRank(h2, uniqDocId);

				} else {
					// If B has ended, pick something random not in B
					// or the combined set
					uniqDocId = randomFromCategory(category, hCombined, h2);
					rank1 = getRank(h1, uniqDocId);
					rank2 = index2;
				}
				// We need to increment here since we don't get
				// into increment loop below.
				index2++;
			}

			// Common processing in any case
			combinedResults[indexCombined] = getDoc(uniqDocId);
			if (debug) Logger.log("Ranks for "+uniqDocId+" are "+rank1+","+rank2);
			combinedResults[indexCombined].setRanks(rank1, rank2);
			hCombined.put(uniqDocId, new Integer(indexCombined));
			
			// Update index1 and index2 to be the number of top n elements from
			// results1 and results2 to be in the combined list.
			while ((index1 <= indexCombined) && (index1 < pl1)
					&& (getRank(hCombined, results1.doc(index1).getUniqId()) != -1))
				index1++;

			while ((index2 <= indexCombined) && (index2 < pl2)
					&& (getRank(hCombined, results2.doc(index2).getUniqId()) != -1))
				index2++;

			indexCombined++;
		}

		// Reset combined to be shorter if we got repeats
		ScoredDocument[] combined2 = new ScoredDocument[indexCombined];
		for (int i = 0; i < indexCombined; i++) {
			combined2[i] = combinedResults[i];
		}

		if (debug) {
			int ranks[] = combined2[0].getRanks();
			Logger.log("After combining before wrapping, first doc has ranks "+ranks[0]+","+ranks[1]);
		}
		
		// The combined set goes first, padded with the original results
		// as needed (i.e. we serve combined 2 until they run out, then
		// continue with new results in results1).
		return new RerankedHits(combined2, results1.hits(), results1.getByDate(), null);
	}

	/**
	 * Combine two sets of results as described in Joachims, T (2003) Evaluating
	 * retrieval performance using clickthrough data. In J Franke, G
	 * Nakhaeizadeh, and I Renz, editors, Text Mining, pages 79-96,
	 * Physica/Springer Verlag, 2003. This allows unbiased comparison of two
	 * ranking functions by intertwining the results.
	 * 
	 * @param results1
	 *            First set of results.
	 * @param results2
	 *            Second set of results.
	 * @param category
	 *            If not null, make sure all documents are in this category.
	 * @param seed
	 *            Random number generator seed.
	 * @return A combined ranking.
	 */
	protected final RerankedHits combineGameSelection(RerankedHits results1, RerankedHits results2, 
			String category, long seed) throws IOException {
		
		int pl1 = results1.prefixLength();
		int pl2 = results2.prefixLength();
	
		if (debug) {
			Logger.log("Combining two result sets. Prefix lengths are " + pl1 + " and " + pl2);
			Logger.log("Unique seed used for query " + seed);
		}
		
		// Somewhere to store the combined results.
		int maxLength = Math.max(pl1, pl2);
		ScoredDocument[] combinedResults = new ScoredDocument[2 * maxLength];
		boolean[] combinedBits = new boolean[2 * maxLength];

		int indexCombined = 0;
		int index1 = 0; // Index of first element in A not in combined
		int index2 = 0; // Index of first element in B not in combined

		// Used to pick if results1 or results2 gets preference
		Random gen = new Random(seed);
		boolean randomBit = gen.nextBoolean();
		int twostep = 0;

		// Make a hash table of document ids to ranks in the two result sets
		Hashtable h1 = new Hashtable(pl1);
		for (int i = 0; i < pl1; i++)
			h1.put(results1.doc(i).getUniqId(), new Integer(i));
		Hashtable h2 = new Hashtable(pl2);
		for (int i = 0; i < pl2; i++)
			h2.put(results2.doc(i).getUniqId(), new Integer(i));
		Hashtable hCombined = new Hashtable(pl1 + pl2);

		// Combine them in the game selection style
		// Here, each turn the contributing source *has* to provide
		// a previously non combined result
		while ((index1 < pl1) || (index2 < pl2)) {

			// Every time you finish a set of choices
			// Flip coin to reset prob
			if(twostep == 2) {
				twostep = 0;
				randomBit = gen.nextBoolean();
			}
			twostep++;
			
			// Common variables for processing
			String uniqDocId = "";
			int rank1 = 0;
			int rank2 = 0;

			if(!randomBit) {
			
				// A has priority
				do
				{
					// Get for either results, or cookup random
					if(index1 < pl1) 
                    {
                        ScoredDocument sd1 = results1.doc(index1);
                        if(debug) Logger.log("doc1: " + sd1);
						uniqDocId = sd1.getUniqId();
                        if(debug) Logger.log("doc1 ID: " + uniqDocId);
                    }
					else 
                    {
                        if(debug) Logger.log("grabbing low doc1");
						uniqDocId = randomFromCategory(category, hCombined, h1);
                    }
					index1++;		
				} while (getRank(hCombined, uniqDocId) != -1);
				
				rank1 = index1-1;
				rank2 = getRank(h2, uniqDocId);
			}
			else {
				
				// B has priority
				do
				{
					// Get for either results, or cookup random
					if(index2 < pl2) 
                    {
                        ScoredDocument sd2 = results2.doc(index2);
                        if(debug) Logger.log("doc2: " + sd2);
						uniqDocId = sd2.getUniqId();
                        if(debug) Logger.log("doc2 ID: " + uniqDocId);
                    }
					else 
                    {
                        if(debug) Logger.log("grabbing low doc2");
						uniqDocId = randomFromCategory(category, hCombined, h2);
                    }
					index2++;		
				} while (getRank(hCombined, uniqDocId) != -1);
			
				rank1 = getRank(h1, uniqDocId);
				rank2 = index2-1;
			}
	
			// debug
			if(debug) {
				Logger.log("Ranks for "+uniqDocId+" are "+rank1+","+rank2);
				Logger.log("Randombit "+randomBit+" ResetCounter = " + twostep);
			}

			// Common processing in any case
			combinedResults[indexCombined] = getDoc(uniqDocId);
			combinedResults[indexCombined].setRanks(rank1, rank2);
			combinedBits[indexCombined] = randomBit;
			hCombined.put(uniqDocId, new Integer(indexCombined));

			// Next step in loop
			indexCombined++;
			randomBit = !randomBit;
		}

		// Reset combined to be shorter if we got repeats
		ScoredDocument[] combined2 = new ScoredDocument[indexCombined];
		boolean[] combinedBits2 = new boolean[indexCombined];
		for (int i = 0; i < indexCombined; i++) {
			combined2[i] = combinedResults[i];
			combinedBits2[i] = combinedBits[i];
		}

		if (debug) {
			int ranks[] = combined2[0].getRanks();
			Logger.log("After combining before wrapping, first doc has ranks "+ranks[0]+","+ranks[1]);
		}
		
		// The combined set goes first, padded with the original results
		// as needed (i.e. we serve combined 2 until they run out, then
		// continue with new results in results1).
		return new RerankedHits(combined2, results1.hits(), results1.getByDate(), combinedBits2);
	}
	
	/**
	 * Similar to:
	 * Combine two sets of results as described in Joachims, T (2003) Evaluating
	 * retrieval performance using clickthrough data. In J Franke, G
	 * Nakhaeizadeh, and I Renz, editors, Text Mining, pages 79-96,
	 * Physica/Springer Verlag, 2003. This allows unbiased comparison of two
	 * ranking functions by intertwining the results.
	 * 
	 * @param howMany
	 *            How many sources are being provided
	 * @param results
	 *            Array of results from different sources.
	 * @param category
	 *            If not null, make sure all documents are in this category.
	 * @param seed
	 *            Random number generator seed.
	 * @return A combined ranking.
	 */
	protected final RerankedHits combineN(int howMany, RerankedHits[] results, 
			String category, long seed) throws IOException {
	
		int[] pl = new int[howMany];
		int maxLength = -1;
		int totalResults = 0;
		for(int i=0;i<howMany;i++) {
			if(results[i] != null) 
				pl[i] = results[i].prefixLength();
			maxLength = Math.max(maxLength, pl[i]);
			totalResults += pl[i];
		}
			
		if (debug) {
			Logger.log("Combining " + howMany + " result sets. Prefix lengths are :");
			for(int i=0;i<howMany;i++) {
				Logger.log("Source " + i + " has " + pl[i] + " results.");
			}
		}
		
		// Somewhere to store the combined results.
		ScoredDocument[] combinedResults = new ScoredDocument[totalResults];

		// Order array used to pick which source gets preference
		int[] order = new int[howMany];
		int[] index = new int[howMany];
		Random gen = new Random(seed);
		for(int i=0;i<howMany;i++) {
			order[i] = i;
			index[i] = 1;
		}
		int n = howMany;
		while(--n > 0) {
			int k = gen.nextInt(n+1);
			int temp = order[n];
			order[n] = order[k];
			order[k] = temp;	
		}

		// Make a hash table of document ids to ranks in the two result sets
		Hashtable hCombined = new Hashtable(totalResults);
		Hashtable[] h = new Hashtable[howMany];
		for(int i=0;i<howMany;i++) {
			h[i] = new Hashtable(pl[i]);
			for(int j=0;j<pl[i];j++)
				h[i].put(results[i].doc(j).getUniqId(), new Integer(j));
		}

		// One Ranking to rule them all; One Ranking to find them; 
		// One Ranking to bring them all and in the ordering, bind them.
		int bind = 1;
		int[] ranks = new int[howMany];
		int indexCombined = 0;
		int leftToDo = totalResults - howMany;
		while (leftToDo > 0) {

  			if(debug) Logger.log("Remaining " + leftToDo + " at step " + bind);
			int current = order[bind];
			if(debug) Logger.log("Which is the " + current + " source, which is currently at " + index[current] + " result");
			if(index[current] < pl[current]) {

				String uniqDocId = results[current].doc(index[current]).getUniqId();

				while((index[current] < pl[current]) && (getRank(hCombined, uniqDocId) != -1)) {

					// we've already added it in sometime ago, move down, looking for something unique to add
					if(debug) Logger.log("Skipping the result at " + current);
					index[current]++;	
					leftToDo--;
					uniqDocId = results[current].doc(index[current]).getUniqId();
				}

				// Check if this source has any promise at all
				if(index[current] < pl[current]) {
			
					// brand new result, not seen so far, unique contribution of this source
					if(debug) Logger.log("Added documentid " + uniqDocId + " as result " + indexCombined);
					combinedResults[indexCombined] = results[current].doc(index[current]);

					for(int i=0;i<howMany;i++) {
						ranks[i] = getRank(h[i], uniqDocId);
						if(debug) Logger.log("Ranks for " + uniqDocId + " for source = " + i + " = " + ranks[i]);
					}
					combinedResults[indexCombined].setNRanks(ranks);
					hCombined.put(uniqDocId, new Integer(indexCombined));
					index[current]++;
					indexCombined++;
					leftToDo--;
				}
			}
			
			// move to next source
			bind = (++bind)%howMany;
		}

		// Reset combined to be shorter if we got repeats
		ScoredDocument[] combined2 = new ScoredDocument[indexCombined];
		for (int i = 0; i < indexCombined; i++) {
			combined2[i] = combinedResults[i];
		}

		if (debug) {
			int Ranks[] = combined2[0].getRanks();
			Logger.log("After combining before wrapping, first doc has ranks of size "+Ranks.length);
		}
		
		// The combined set goes first, padded with the original results
		// as needed (i.e. we serve combined 2 until they run out, then
		// continue with new results in results1).
		return new RerankedHits(combined2, results[0].hits(), results[0].getByDate(), null);
	}

	/**
	 * Get a random doc from the appropriate category that is not present already or in the other ranking
	 * 
	 * @param category
	 *            Category we are interested in
	 * @param hCombined
	 *            The combined hash table
	 * @param other
	 *            The hash table of the other ranking
	 * @return The rank of this document id, or -1 if its not present.
	 */
	protected final String randomFromCategory(String category, Hashtable hCombined, 
			Hashtable other) throws IOException {

		String uniqDocId = "";
		while (uniqDocId == null || uniqDocId.equals("")) {
			uniqDocId = randomDocUniqId(category);
            if (debug) Logger.log("Random from category " + category + ": " + uniqDocId);
			if (uniqDocId != null && (other.get(uniqDocId) != null || hCombined.get(uniqDocId) != null))
				uniqDocId = "";
		}
		return uniqDocId;
	}
	
	/**
	 * Get the rank of document docId in the hashtable of results h.
	 * 
	 * @param h
	 *            Hashtable storing document ids and the rank of the document.
	 * @param docId
	 *            The document id we want to look up.
	 * @return The rank of this document id, or -1 if its not present.
	 */
	protected final int getRank(Hashtable h, String uniqDocId) {

		Integer r = (Integer) h.get(uniqDocId);
		if (r == null)
			return -1;
		else
			return r.intValue();
	}

	/**
	 * Returns the category in the query, if any.
	 * 
	 * @param query
	 *            The query
	 * @return The category the query requires, or null if none is present.
	 */
	protected final static String getCategory(String query) {

		String pattern = "[^a-z]category:([a-z]*)";
		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(query.toLowerCase());
		if (m.find()) {
			return m.group(1);
		}

		return null;
	}

	/** Log the message s to the general log file. */
	protected final void log(String s) {
		Logger.log(s);
	}

	/**
	 * Convert a hashtable containing scored documents to an array of scored
	 * documents.
	 */
	public static final ScoredDocument[] hashtableToArray(Hashtable h) {

		if (h == null)
			return null;

		return (ScoredDocument[]) (h.values()).toArray(new ScoredDocument[0]);
	}

	/**
	 * Return the unique identifier of a random document in the collection or
	 * null on failure.
	 */
	public abstract String randomDocUniqId() throws IOException;

	/**
	 * Return the unique identifier of a random document in the collection or
	 * null on failure, such that the document is in the given category.
	 */	
	public abstract String randomDocUniqId(String category) throws IOException;

	
	/**
	 * Return the document with this unique identifier, or null if it doesn't
	 * exist. Sets the document and document id, but sets the score to 0.
	 */
	public abstract ScoredDocument getDoc(String uniqId) throws IOException;

}
