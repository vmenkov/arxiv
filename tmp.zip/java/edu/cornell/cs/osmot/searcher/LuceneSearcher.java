package edu.cornell.cs.osmot.searcher;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.DateTools;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.analysis.PerFieldAnalyzerWrapper;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.*;

import java.util.*;

import java.io.IOException;

import edu.cornell.cs.osmot.options.Options;
import edu.cornell.cs.osmot.reranker.Reranker;
import edu.cornell.cs.osmot.logger.Logger;

/**
 * Compare two documents based on their id
 */
class IdComparer implements Comparator {
	public int compare(Object obj1, Object obj2) {
		int id1 = ((ScoredDocument)obj1).getId();
		int id2 = ((ScoredDocument)obj2).getId();

		if (id1 == id2)
			return 0;
		else if (id1 < id2)
			return -1;

		return 1;		
	}
}

/**
 * This class implements searching a Lucene index.
 * 
 * @author Filip Radlinski
 * @version 1.0, April 2005
 */
public class LuceneSearcher extends Searcher {

	protected String indexDir;
	
	private int uniqIdField;
	private static String idField = Options.get("UNIQ_ID_FIELD");	

	private IndexSearcher is;

	private PerFieldAnalyzerWrapper analyzer;

	private Date lastUpdate;

	// One parser per searchable field: each parser by default runs a search
	// on a different field. We then combine these results using the learned
	// ranking function if present, or we just take an average score.
	private QueryParser qp[];
	private QueryParser qpAndField;

	private Sort dateSort;
	
	/**
	 * Initializes the searcher.
	 * 
	 * @param indexDir
	 *            the directory where the index is stored.
	 */
	protected void init(String idxDir) throws IOException {
		
		this.indexDir = idxDir;

		// Get the fields that exist in the document collection.
		fields = loadFields();

		if (debug)
			log("LuceneSearcher initializing with "+fields.length+" fields.");
		
		fieldsShort = new String[fields.length];
		for (int i = 0; i < fields.length; i++) {
			if (fields[i].equals(Options.get("UNIQ_ID_FIELD")))
				uniqIdField = i;
			fieldsShort[i] = fields[i].toUpperCase().replaceAll("-", "");
		}

		// Set up IndexSearcher, Analyzer and a QueryParses for each field.
		this.is = new IndexSearcher(indexDir);

		if (is == null) {
			throw new IOException("Can't open index at " + indexDir);
		}

		// We only split the the UNIQ_ID_FIELD using whitespace, others use the
		// standard analyzer
		analyzer = new PerFieldAnalyzerWrapper(new StandardAnalyzer());
		analyzer.addAnalyzer(Options.get("UNIQ_ID_FIELD"),
				new WhitespaceAnalyzer());
		qp = new QueryParser[fields.length];

		qpAndField = null;
		
		// Set up one parser per field
		for (int i = 0; i < fields.length; i++) {
            if (fields[i].equals(Options.get("SEARCHER_AND_FIELD"))) {
            	qpAndField = new QueryParser(fields[i], analyzer);
            	qpAndField.setDefaultOperator(QueryParser.AND_OPERATOR);
            }
            	
			qp[i] = new QueryParser(fields[i], analyzer);
			// Search for ANY of the words, not ALL the words (that would be AND_OPERATOR)
			qp[i].setDefaultOperator(QueryParser.OR_OPERATOR);
		}

		if (qpAndField == null) {
			log("WARNING: AND Operator field not found: "+Options.get("SEARCHER_AND_FIELD"));
			log("WARNING: Switching to " + fields[0] + " as the AND Operator");
			qpAndField = new QueryParser(fields[0], analyzer);
		}

		// Used for sorting by date
		dateSort = new Sort("date", true);
		
		// This determines when we reload the index next.
		lastUpdate = new Date();
	}

	/**
	 * Create a new searcher with no learned ranking functions. We'll just use
	 * the default ranking function defined below in this class.
	 * 
	 * @param indexDir
	 *            The directory where the Lucene index is stored.
	 */
	public LuceneSearcher(String indexDir) throws IOException {

		init(indexDir);
	}

	/**
	 * Create a new searcher with no learned ranking functions. We'll just use
	 * the default ranking function defined below in this class.
	 * 
	 */
	public LuceneSearcher() throws IOException {

	}

	/**
	 * Return the original results for this query on each field, returning the hits
	 * 
	 */
	public Hits[] origHits(String query) {

		Hits[] hits = new Hits[fields.length];

		query = query.trim().toLowerCase();
		
		if (query.equals("")) {
			for (int i = 0; i < hits.length; i++)
				hits[i] = null;
			return hits;
		}

		// A stray AND at the end of a query can confuse the parser.
		if (query.length() > 4) {
			if (query.substring(query.length() - 3, query.length()).equals(
					" and")) {
				//log("Warning: Removed an AND at the end of query "+query);
				query = query.substring(0, query.length() - 4);
			}
		}
		
		for (int j=0; j<fields.length; j++) {
			try {
				hits[j] = is.search(qp[j].parse(query));
			} catch (ParseException e) {
				log("Warning: origResults couldn't parse query " + query);
				log(e.toString());
				hits = null;
			} catch (Exception e) {
				log("Error: Strange exception when trying to rerun query "
						+ query);
				log(e.toString());
				hits = null;
			}			
		}
		
		if (debug) {
			for (int x = 0; x < fields.length; x++) {
				Logger.log("Field " + fields[x]);
				if (hits[x] != null) {
					String logStr = "Results: ";
					try {
						for (int j = 0; j < Math.min(hits[x].length(), 50); j++)
							logStr += hits[x].doc(j).getField(idField).stringValue() + ",";
					} catch (IOException e) {
						// Ignore, the result string ends
						logStr += "<IO Exception>";
					}
					if (hits[x].length() > 0)
						Logger.log(logStr);
					else
						Logger.log("No results. ");
				}
			}
		}
		
		return hits;
	}
	
	/**
	 * @deprecated Use origHits()
	 * 
	 * Return the original results for this query for each field.
	 * 
	 * @param query
	 *            The query to run.
	 * @return An array of results for each field.
	 */
	public String[][] origResults(String query) throws IOException, ParseException {

		ScoreDoc[] hits;
		String[][] oResults = new String[fields.length][];
		int maxDocs = Options.getInt("SEARCHER_MAX_DOCS")+1;

		query = query.trim().toLowerCase();
		
		if (query.equals("")) {
			for (int i = 0; i < oResults.length; i++)
				oResults[i] = new String[0];
			return oResults;
		}

		// A stray AND at the end of a query can confuse the parser.
		if (query.length() > 4) {
			if (query.substring(query.length() - 3, query.length()).equals(
					" and")) {
				//log("Warning: Removed an AND at the end of query "+query);
				query = query.substring(0, query.length() - 4);
			}
		}

		QueryFilter qFilter = new QueryFilter(qpAndField.parse(query));
		
		for (int j = 0; j < fields.length; j++) {

			try {
				hits = is.search(qp[j].parse(query), qFilter, maxDocs).scoreDocs;
			} catch (ParseException e) {
				log("Warning: origResults couldn't parse query " + query);
				log(e.toString());
				hits = new ScoreDoc[0];
			} catch (Exception e) {
				log("Error: Strange exception when trying to rerun query "
						+ query);
				log(e.toString());
				hits = new ScoreDoc[0];
			}

			oResults[j] = new String[hits.length];
			for (int i = 0; i < hits.length; i++)
				oResults[j][i] = is.doc(hits[i].doc).get(
						Options.get("UNIQ_ID_FIELD"));
		}

		return oResults;
	}

	/**
	 * @deprecated Use origHits() now.
	 * 
	 * Return the original scores for this query for each field.
	 * The results are returned by origResults. This is a separate
	 * function since we didn't need the scores originally, and this
	 * is an experiment to see if they help the learner. 
	 * 
	 * @param query
	 *            The query to run.
	 * @return An array of results for each field.
	 */
	public double[][] origScores(String query) throws ParseException {

		ScoreDoc[] hits;
		double[][] oScores = new double[fields.length][];

		int maxDocs = Options.getInt("SEARCHER_MAX_DOCS")+1;
		
		query = query.trim().toLowerCase();

		if (query.equals("")) {
			for (int i = 0; i < oScores.length; i++)
				oScores[i] = new double[0];
			return oScores;
		}

		// A stray AND at the end of a query can confuse the parser.
		if (query.length() > 4) {
			if (query.substring(query.length() - 3, query.length()).equals(
					" and")) {
				//log("Warning: Removed an AND at the end of query "+query);
				query = query.substring(0, query.length() - 4);
			}
		}

		QueryFilter qFilter = new QueryFilter(qpAndField.parse(query));

		for (int j = 0; j < fields.length; j++) {

			try {
				hits = is.search(qp[j].parse(query), qFilter, maxDocs).scoreDocs;
			} catch (ParseException e) {
				log("Warning: origResults couldn't parse query " + query);
				log(e.toString());
				hits = new ScoreDoc[0];
			} catch (Exception e) {
				log("Error: Strange exception when trying to rerun query "
						+ query);
				log(e.toString());
				hits = new ScoreDoc[0];
			}

			oScores[j] = new double[hits.length];
			for (int i = 0; i < hits.length; i++)
				oScores[j][i] = hits[i].score;
		}

		return oScores;
	}
	
	/**
	 * Reload the searcher if we need to - it has a lifetime before we are guaranteed
	 * to reload it so as to see any changes.
	 *
	 */
	public void updateSearcher(boolean force) {
		
		try {
			// Check if we need to update the searcher. If so, reload the index
			// searcher.
			long openTime = new Date().getTime() - lastUpdate.getTime();
			openTime = openTime / (1000 * 60); 
                        if (force || openTime > Options.getInt("SEARCHER_LIFETIME")) {
				Logger.log("Reloading Searcher. Open time was "+openTime);
				is.close();
				is = new IndexSearcher(indexDir);
				lastUpdate = new Date();
			}
		} catch (Exception e) {
			Logger.log("Exception reloading index: "+e.toString()+": "+e.getMessage());
		}
	}
		
	/** 
	 * Like search, but faster. Document are only retrieved when we need them.
	 * Returns the full set of document ids, unlike search(). You can specify which
	 * documents you want the actual content from.
	 * 
	 * @param query       The query to run
	 * @param reranker    The reranked to use when getting scores
	 */
	public RerankedHits search(String query, Reranker reranker) 
			throws ParseException, IOException {

		if (debug) Logger.log("LuceneSearcher.SearchFast: Called with query "+query+" and reranker "+reranker);
		
		// We either use scores or ranks when reranking
		String uniqIdFieldName = Options.get("UNIQ_ID_FIELD");
		int fieldResults = Options.getInt("SEARCHER_NUM_FIELD_RESULTS");
		
		updateSearcher(false);
		
		// Get the set of documents that have term/document scores 
		// for this query
		HashSet tdfDocs = new HashSet();
		if (reranker != null)
			tdfDocs = reranker.tdfDocs(query);
		
		if (debug) Logger.log("tdfDocs has "+tdfDocs.size()+" documents.");
		
		// Make a set of queries, one for each field
		Query allQueries[] = new Query[fields.length];
		for (int j=0; j<allQueries.length; j++) 
			allQueries[j] = qp[j].parse(query);

		if (debug) Logger.log(allQueries.length+" field queries created. Here is the first: "+qp[0]);

		// Get the complete set of results (i.e. hits), just to have all results if users 
		// look that far. However, we'll only look at these results after looking at the
		// top results that we actually rerank.
		// At the same time, we make a filter for per-field queries: documents must match
		// everything everywhere
		BooleanQuery allHitsQ = new BooleanQuery();
		Query tmpQ = qpAndField.parse(query);
		QueryFilter mustMatchQF = new QueryFilter(tmpQ);
		tmpQ.setBoost(0.0001f);
		allHitsQ.add(tmpQ, BooleanClause.Occur.MUST);	
		for (int j=0; j<allQueries.length; j++) {
			allQueries[j].setBoost(1.0f);	
			allHitsQ.add(allQueries[j], BooleanClause.Occur.SHOULD);
		}
		Hits hits = is.search(allHitsQ);		
		
		if (debug) Logger.log("General hits query returned "+hits.length()+" results.");
		
		// This filter will let us get the documents in our top set: These documents are
		// in the top-n for at least one of the queries, or have TDF weights. We will then 
		// the score for each of these documents on all fields and rerank based on them
		// (we don't do this for all documents since its slow). 
		BooleanQuery bq = new BooleanQuery();
		BooleanQuery.setMaxClauseCount(allQueries.length * fieldResults + tdfDocs.size());
		
		// For every field, find the top 200 documents that match part of the query and
		// also include all words somewhere. At the same time, remove those results from 
		// the tdfDocs (so it becomes just the results that aren't retrieved otherwise)
		Double scores[];
		for (int j=0; j<allQueries.length; j++) {
			Hits hitsTmp = is.search(allQueries[j], mustMatchQF);
			if (debug) Logger.log("Field "+fields[j]+" has "+hitsTmp.length()+" results. Processing first "+fieldResults);
			for (int r=0; r<fieldResults && r<hitsTmp.length(); r++) {
				String uniqId = hitsTmp.doc(r).get(uniqIdFieldName);
				tdfDocs.remove(uniqId);
				
				// We want this document selected by our query filter
				if (debug) Logger.log("Adding unique id "+uniqId+" to QP");
				bq.add(qp[uniqIdField].parse(uniqId),BooleanClause.Occur.SHOULD);
			}
			if (debug) Logger.log("Filtering query bq selects for these documents: "+bq.toString());
			if (debug) Logger.log("tdfDocs now has "+tdfDocs.size()+" results.");
		}

		// This holds the final result set
		Hashtable allResults = new Hashtable(2*fieldResults);
		
		if (debug) Logger.log("Making filter for all documents we want to look at.");
		
		// Add the documents with only TDF scores to our filter
		Iterator i = tdfDocs.iterator();
		while (i.hasNext()) {
			String uniqId = (String)i.next();
			bq.add(qp[uniqIdField].parse(uniqId), BooleanClause.Occur.SHOULD);
		}

		// Make our filter
		QueryFilter topSetQF = new QueryFilter(bq);
		
		// For every result we have, get the complete scores
		// and reweight the scores using the reranker, adding
		// term/doc scores, etc.
		
		if (debug) Logger.log("Fetching complete score sets of all.");
		
		// rerun the query on each field, this time filtering for the results we
		// actually want. Then for every result, add the score to our scores
		for (int j=0; j<fields.length; j++) {
			Query q = qp[j].parse(query);
			Hits h = is.search(q, topSetQF);
			if (debug) Logger.log("Field "+fields[j]+" produced "+h.length()+" results.");
			for (int r=0; r<h.length(); r++) {
				Integer id = new Integer(h.id(r));
				scores = (Double[])allResults.get(id);
				if (scores == null) {
					scores = new Double[fields.length];
					for(int k=0; k<scores.length; k++)
						scores[k] = new Double(0);
				}
				if (reranker == null || reranker.useScores())
					scores[j] = new Double(h.score(r));
				else
					scores[j] = new Double(r);
				
				if (debug) Logger.log("Updating doc "+id);
				allResults.put(id, scores);
			}
			if (debug) Logger.log("AllResults now has "+allResults.size()+" documents.");
		}
		
		if (debug) Logger.log("all results from queries now have all scores. Adding up.");
		
		// Add the scores up, make ScoredDocuments
		Enumeration e = allResults.keys();
		while (e.hasMoreElements()) {
			Integer Id = (Integer)e.nextElement();
			scores = (Double[])allResults.get(Id);

			Document doc = is.doc(Id.intValue());
			ScoredDocument sd = new ScoredDocument(doc, Id.intValue(), 0);

			if (debug) Logger.log("Reprocessing document "+sd.getUniqId());
			
			// Make ScoredDocuments out of this
			double update, score;
			for (int j=0; j<fields.length; j++) {
				score = scores[j].doubleValue();

                if(debug && score > 0.0001) Logger.log("Field " + fields[j] + ", score " + score);

				if (reranker != null) {
					update = reranker.score(j, score);
					if (update != 0) {
						if (reranker.useScores())
							sd.updateScore(update, "Field " + fields[j] + ", score " + score);
						else
							sd.updateScore(update, "Field " + fields[j] + ", top " + score);
					}
				} else {
					if (score != 0)
						sd.updateScore(score, "Score on Field "+fields[j]);
				}
			}

            if(debug) Logger.log("Total score: " + sd.getScore());

			// Add the term/document features, remove from the list of docs we must
			// make sure we look at.
			if (reranker != null) {
				reranker.addTDFScore(sd, query);
			}
			
			// Put the scored document in the hashtable
			allResults.put(Id, sd);
		}

		if (debug) Logger.log("Adding missing TDF only documents. There are "+allResults.size()+" results.");
		
		// Add any missing documents with only TDF scores
		if (reranker != null) {
			i = tdfDocs.iterator();
			while (i.hasNext()) {
				String uniqId = (String)i.next();
				ScoredDocument sdTmp = getDoc(uniqId);
				if (sdTmp == null) 
					Logger.log("LuceneSearcher.searchFast Warning: Missing document "+uniqId+" has TDF features");
				else {
					Integer id = new Integer(sdTmp.getId());
					ScoredDocument sd = (ScoredDocument)allResults.get(id);
				
					// If document was already in there, we don't need to do anything
					if (sd == null) {
						sd = sdTmp;
	
						// The score on fields is 0, but that might get mapped to something		
						// non-zero.
						for (int j=0; j<fields.length; j++) {
							double update = 0;
							update = reranker.score(j, 0);
							if (update != 0) {
								if (reranker.useScores())
									sd.updateScore(update, "Field " + fields[j] + ", score 0");
								else
									sd.updateScore(update, "Field " + fields[j] + ", top 0");
							}
						}
	
						reranker.addTDFScore(sd, query);
						allResults.put(id, sd);
						
					} // End of if was sd null - if it was not null, it was already these so skip it				
				} // End of if document was found in index. If missing, we can't add it to results
			} // End of loop over TdfDocs
		} // End of if reranker is not null
		
		if (debug) Logger.log("allResults reprocessed. There are "+allResults.size()+" results.");
						
		// Extract into an array and sort by score
		ScoredDocument sortedResults[] = (ScoredDocument[])allResults.values().toArray(new ScoredDocument[0]);
		Arrays.sort(sortedResults);

		if (debug) Logger.log("Results sorted.");
				
		// Make a new RerankedHits and return that
		RerankedHits rh = new RerankedHits(sortedResults, hits);
		
		if (debug) Logger.log("After wrapping, there are "+rh.length()+" results.");
		
		return rh;
	}

	/**
	 * Search by date
	 */
	public RerankedHits searchDate(String query, Reranker reranker) 
			throws ParseException, IOException {
		
		updateSearcher(false);

		Hashtable tdfResultsHT = null;
		ScoredDocument tdfResults[] = new ScoredDocument[0];
		
		// Get the set of documents that have term/document scores 
		// for this query
		if (reranker != null) {
			HashSet tdfDocs = new HashSet();

			tdfDocs = reranker.tdfDocs(query);
			tdfResultsHT = new Hashtable(tdfDocs.size());

			// Get those documents, put them in the result set
			Iterator i = tdfDocs.iterator();
			while (i.hasNext()) {
				String uniqId = (String)i.next();
				ScoredDocument sd = getDoc(uniqId);
				sd.updateScore(1, "Non-zero score: sorting by date");
				reranker.addTDFScore(sd, query);
			
				tdfResultsHT.put(new Integer(sd.getId()), sd);
			}
			
			if (tdfDocs.size() > 0) {
				tdfResults = (ScoredDocument[])tdfResultsHT.values().toArray(new ScoredDocument[0]);
				Arrays.sort(tdfResults, new DateComparator());
		
			}
		}
				
		// Get the complete set of results using the regular query (i.e. hits)
		BooleanQuery finalQ = new BooleanQuery();
		Query tmpQ = qpAndField.parse(query);
		tmpQ.setBoost(0.0001f);
		finalQ.add(tmpQ, BooleanClause.Occur.MUST);	
		for (int j=0; j<fields.length; j++) {
			// Make a set of queries, one for each field
			Query tmpQuery = qp[j].parse(query);
			tmpQuery.setBoost(1.0f);	
			finalQ.add(tmpQuery, BooleanClause.Occur.SHOULD);
		}
		
		// Run a search, sorting by decreasing date.
		Hits hits = is.search(finalQ, dateSort);
		
		// Make a new RerankedHits and return that - its sorted by date
		RerankedHits rh = new RerankedHits(tdfResults, hits, true, null);
		
		return rh;
	}
	
	/**
	 *  Get the score of a specific document. Needed for reranking (it will move) 
	 */
	public float getScore(String uniqId, Query q) {
		try { 
			Logger.log(q.toString());
			BooleanQuery finalQ = new BooleanQuery();
			Query qId = qp[uniqIdField].parse(fields[uniqIdField]+":"+uniqId);
			qId.setBoost(0.0001f);
			finalQ.add(qId, BooleanClause.Occur.MUST);
			finalQ.add(q, BooleanClause.Occur.MUST);
			Logger.log(finalQ.toString());
			TopDocs td = is.search(finalQ, null, 1);
			Logger.log("Hits: "+td.totalHits);
			return td.getMaxScore();
		} catch (Exception e) {
			return 0;
		}	
	}	

	/**
	 * Return the fields present in the document collection.
	 * 
	 * @return An array of the fields present in the index.
	 */
	protected String[] loadFields() throws IOException {

		String[] tmpFields;
		IndexReader reader = IndexReader.open(indexDir);

		Collection fn = reader.getFieldNames(IndexReader.FieldOption.INDEXED);
		int size = fn.size();

		tmpFields = new String[fn.size()];

		Iterator it = fn.iterator();

		for (int i = 0; i < size; i++) {
			tmpFields[i] = (String) it.next();
		}

		reader.close();

		return tmpFields;
	}

	/**
	 * Pick a random document from the collection.
	 * 
	 * @return The id of a random valid document in the index.
	 */
	protected int randomDoc() throws IOException {

		int maxDoc = is.maxDoc();
		int docNo;

		while (true) {
			docNo = (int) Math.floor(Math.random() * maxDoc);
			try {
				if (is.doc(docNo) != null)
					return docNo;
			} catch (Exception e) {
				// Ignore (we might for example pick a deleted document)
			}
		}
	}

	/**
	 * Pick a random document from the collection in the category specified.
	 * This is terribly inefficient!
	 * 
	 * @return The id of a random valid document in this category, or -1 if we
	 *         fail in finding on.
	 */
	protected int randomDoc(String category) throws IOException {

		int counter = 0;

		if (category == null)
			return randomDoc();

		while (counter < 1000) {
			int i = randomDoc();
			String s = is.doc(i).get("category");
			if (s.equals(category))
				return i;

			counter++;
		}

		return -1;
	}

	/**
	 * Pick a random document from the collection in the category specified.
	 * This is terribly inefficient!
	 * 
	 * @return The id of a random valid document in this category, or -1 if we
	 *         fail in finding on.
	 */
	public String randomDocUniqId(String category) throws IOException {

		int counter = 0;

		if (category == null)
			return randomDocUniqId();

		while (counter < 1000) {
			int i = randomDoc();
			String s = is.doc(i).get("category");
			if (s.equals(category))
				return is.doc(i).get(Options.get("UNIQ_ID_FIELD"));

			counter++;
		}

		return null;
	}
	/**
	 * Return the unique identifier of a random document in the collection.
	 * 
	 * @return A random document identifier that is valid.
	 */
	public String randomDocUniqId() throws IOException {

		int docId = randomDoc();
		Document d = null;

		if (docId != -1)
			d = is.doc(docId);

		if (d != null)
			return d.get(Options.get("UNIQ_ID_FIELD"));

		return null;
	}

	/** Returns the document with this unique ID, or null if id doesn't exist. */
	public ScoredDocument getDoc(String uniqId) throws IOException {

		ScoredDocument sd = null;
		ScoreDoc[] hits = null;

		try {
			hits = is.search(qp[uniqIdField].parse(uniqId), null, 2).scoreDocs;
		} catch (ParseException pe) {
			hits = null;
		}

		if (hits == null || hits.length == 0)
			log("LuceneSearcher.getDoc Warning: Document " + uniqId + " not found.");
		else
			sd = new ScoredDocument(is.doc(hits[0].doc), hits[0].doc, 0);

		return sd;
	}
	
	/**
	 * Used to run searches from the command line. There are a number of usage
	 * modes: If there is one argument, just run the query. If there is one
	 * argument and its "MULTI", repeatedly wait for a query and document. If
	 * there is a query and document, return stats about the document for that
	 * query.
	 */
	public static void main(String[] args) throws IOException, ParseException {

		if (args.length == 1) {
			// Run a query
			
			String queryString = args[0];

			Searcher s = new LuceneSearcher(Options.get("INDEX_DIRECTORY"));
			RerankedHits r = s.search(queryString, null);

			System.out.println("Query is: " + queryString);
			System.out.println("Found " + r.length() + " hits.\n");

			for (int i = 0; i < r.length(); i++) {
				Document doc = r.doc(i).getDoc();
				System.out.println((i + 1) + ". "
						+ doc.get(Options.get("UNIQ_ID_FIELD")) + ": score = "
						+ r.score(i) + ", id: " + r.doc(i).getUniqId());
				System.out.println(Snippeter.getSnippet(doc, queryString, false, false));
				System.out.println("");
			}

		} else if (args.length >= 2) {
			// Its asking for a document and stats about it. If length of arguments is 3,
			// the person only wants a found/not found.

			String queryString;
			String wantedDoc;
			boolean justCount;
			if (args.length == 2) {
				queryString = args[0];
				wantedDoc = args[1];
				justCount = false;
			} else {
				queryString = args[1];
				wantedDoc = args[2];
				justCount = true;
			}
				
			Searcher s = new LuceneSearcher(Options.get("INDEX_DIRECTORY"));
			RerankedHits r = s.search(queryString, null);

			if (!justCount) {
				System.out.println("Query is: " + queryString);
				System.out.println("Found " + r.length() + " hits.\n");
			}
				
			boolean found = false;
			for (int i = 0; i < r.length(); i++) {
				try {
					Document doc = r.doc(i).getDoc();
					if (doc.get(Options.get("UNIQ_ID_FIELD")).equals(wantedDoc)) {
						if (justCount) {
							System.out.println("FOUND");
							found = true;
						} else {
							System.out.println((i + 1) + ". "
								+ doc.get(Options.get("UNIQ_ID_FIELD"))
								+ ": score = " + r.score(i) + ", id: "
								+ r.doc(i).getUniqId());
							System.out.println(Snippeter.getSnippet(doc, queryString, false, false));
							System.out.println("");
						}
					}
				} catch (IOException e) {
					// Do nothing, result count probably updated.
				}
			}
			if (justCount && !found)
				System.out.println("NOT FOUND!");

		} else {

			System.out
					.println("Usage:\n\tSearcher <query>          : Run query.");
			System.out
					.println("\tSearcher <uniqId> <query> : Print match of document to query.");
			System.out
					.println("\tSearcher MULTI            : Print match of many documents to many queries.");
		}

	}

	/**
	 * Return the maximum document id present in the index.
	 * 
	 * @return The maximum document id present in the index.
	 */
	public long getIndexSize() {
		long size = 0;
		try {
			size = is.maxDoc();
		} catch (IOException e) {
			log("Error: Exception in getIndexSize");
			log(e.toString());
		}
		return size;
	}
	
	/**
	 * Return a HTML version of the document. This is collection specific, so
	 * you want to change it to match your collection.
	 */
	public String toHtml(ScoredDocument sd) {

		Document doc = sd.getDoc();
		
		if (doc == null) {
			return "Error: Null Document";
		}
		
		Calendar c = new GregorianCalendar();

		String author = doc.get("authors");
		if (author == null)
			author = "";

		// Filter affiliations out of author strings
		author = author.replaceAll("\\([^\\)]*\\)","");
		
		// If the list of authors is too long, break at the third comma
		if (author.length() > 45) {
			int pos = 0;
			for (int i=0; i<3 && pos != -1; i++)
				pos = author.indexOf(',', pos+1);
			if (pos > 0)
				author = author.substring(0, pos)+" et al.";
		}
		
		String title = doc.get("title");
		if (title == null)
			title = "";

		Date date = sd.getDate();

		// Get rid of things in parenthesis from the author field
		int len = 0;
		while (len != author.length()) {
			len = author.length();
			author = author.replaceAll("\\([^\\)\\(]*\\)", "").trim();
		}

		String st_year = "";
		if (date != null) {
			c.setTime(date);
			int year = c.get(Calendar.YEAR);
			st_year = " (<span class=\"year\">" + year + "</span>)";
		}

		String result = "";
		if (author.length() > 0)
			result += "<span class=\"author\">" + author + "</span>, ";
		if (title.length() > 0)
			result += "<span class=\"title\">" + title + "</span>";
		if (st_year.length() > 0)
			result += st_year;

		return result;
	}
	
	public String makeList(Date afterDate, int sizeLimit) throws IOException, ParseException {
		StringBuffer result = new StringBuffer();
		
		if (afterDate == null) {
			if (sizeLimit < 0) {
				Document d;
				IndexReader ir = is.getIndexReader();
				for (int i=0; i<is.maxDoc(); i++) {
					if (!ir.isDeleted(i)) {
						d = ir.document(i);
						result.append(listLine(d));
					}
				}
			} else { //SizeLimit => 0
				QueryParser qpLocal = new QueryParser("dateIndexed", analyzer);
				Query q = qpLocal.parse("articleLength:["+sizeLimit+" to 99999999]");
				Hits h = is.search(q);
				Document d;
				for (int i=0; i<h.length(); i++) {
					d = h.doc(i);
					result.append(listLine(d));
				}
			}
		} else { // afterDate is not null
			if (sizeLimit < 0) {

				// Note, this will only work on new format dates. Old ones will probably show
				// up as non-existent.
				QueryParser qpLocal = new QueryParser("dateIndexed", analyzer);
				Query q = qpLocal.parse("afterDate:["+DateTools.dateToString(afterDate,DateTools.Resolution.DAY)+" to 20991231]");
				Hits h = is.search(q);
				Document d;
				for (int i=0; i<h.length(); i++) {
					d = h.doc(i);
					result.append(listLine(d));
				}
				
			} else { // SizeLimit >= 0
				
				QueryParser qpLocal = new QueryParser("dateIndexed", analyzer);
				Query q = qpLocal.parse("articleLength:["+sizeLimit+" to 99999999] afterDate:["+DateTools.dateToString(afterDate,DateTools.Resolution.DAY)+" to 20991231]");
				Hits h = is.search(q);
				Document d;
				for (int i=0; i<h.length(); i++) {
					d = h.doc(i);
					result.append(listLine(d));
				}
			
			}
		}

		return result.toString();
	}
	
	private StringBuffer listLine(Document d) {
		StringBuffer b = new StringBuffer();
		if (d != null) {
			String fields[] = {"paper","dateIndexed","articleLength","title"};
			for (int f=0; f<fields.length; f++) {
				String values[] = d.getValues(fields[f]);
				if (values != null)
					b.append(values[0]);
				if (f < fields.length-1)
					b.append(",");
				else
					b.append("<br>\n");
			}
		}
		return b;
	}
	
	public Document getDoc(int id) throws IOException {
		return is.doc(id);
	}
}
