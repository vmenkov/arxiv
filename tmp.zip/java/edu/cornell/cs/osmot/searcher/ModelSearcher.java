package edu.cornell.cs.osmot.searcher;

import java.util.Hashtable;
import java.util.Arrays;
import java.util.Enumeration;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.Hits;

import edu.cornell.cs.osmot.options.Options;
import edu.cornell.cs.osmot.reranker.Reranker;

/**
 * This class implements searching a data file as used in the modelling.
 * 
 * @author Filip Radlinski
 * @version 1.0, May 2005
 */
public class ModelSearcher extends Searcher {

	private Document[] documents;

	private double[] docSizes;

	private String documentFile;
	private String labelFile;

	private Hashtable invIndex;

	/**
	 * Initializes the searcher.
	 * 
	 * @param indexDir
	 *            the directory where the documents are.
	 */
	private void init(String docFile, String labFile) throws IOException {

		this.documentFile = docFile;
		this.labelFile = labFile;

		fields = loadFields();
		fieldsShort = new String[fields.length];
		for (int i = 0; i < fields.length; i++) {
			fieldsShort[i] = fields[i].toUpperCase().replaceAll("-", "");
		}
		
		// Load the documents
		loadDocuments(documentFile, labelFile);

		// Work out the sizes
		docSizes = new double[documents.length];
		for (int i = 0; i < documents.length; i++) {
			docSizes[i] = docSize(documents[i]);
		}

		// Make the inverted index
		invIndex = makeInvIndex();
	}

	/**
	 * Create a new searcher with no learned ranking functions. We'll just use
	 * the default ranking function defined below in this class.
	 * 
	 * @param docFile
	 *            The file defining the documents.
	 * @param labFile
	 *            The file with the document labels.
	 */
	public ModelSearcher(String docFile, String labFile) throws IOException {

		init(docFile, labFile);
	}

	/**
	 * Return the original results for this query for each field.
	 * 
	 * @param query
	 *            The query to run.
	 * @return An array of results for each field.
	 */
	public String[][] origResults(String query) throws IOException, ParseException {

		String[][] oResults = new String[2][];

		if (query.equals("")) {
			for (int i = 0; i < oResults.length; i++)
				oResults[i] = new String[0];
			return oResults;
		}

		RerankedHits rh = search(query, null);
		int numResults = rh.length();
		if (numResults > 200)
			numResults = 200;
		oResults[0] = new String[numResults];
		for (int i = 0; i < numResults; i++) {
			oResults[0][i] = "" + rh.doc(i).getUniqId();
		}

		oResults[1] = new String[0];

		return oResults;
	}

	/**
	 * Return the original scores for this query for each field.
	 * The results are returned by origResults. This is a separate
	 * function since we didn't need the scores originally, and this
	 * is an experiment to see if they help the learner. So its not
	 * yet used, so its not implemented.
	 * 
	 * @param query
	 *            The query to run.
	 * @return An array of results for each field.
	 */
	public double[][] origScores(String query) throws IOException {

		return null;
	}
	
	/**
	 * Return the original results for this query for each field.
	 * The results are returned by origResults. This is a separate
	 * function since we didn't need the scores originally, and this
	 * is an experiment to see if they help the learner. So its not
	 * yet used, so its not implemented.
	 * 
	 * @param query
	 *            The query to run.
	 * @return The results for each field.
	 */
	public Hits[] origHits(String query) throws IOException {

		return null;
	}	
	
	/**
	 * Search for this query. This is slow and inefficient but it works.
	 * 
	 * @param query
	 *            The query to run
	 * @param reranker
	 *            The reranker to use. Set to null for no reranking.
	 * @return The ranked results of the search.
	 */
	public RerankedHits search(String query, Reranker reranker)
			throws IOException {

		Hashtable results = new Hashtable(100);

		String words[] = query.split(" ");
		for (int i = 0; i < words.length; i++) {

			if (words[i].length() == 0)
				continue;

			// Get a hashtable with document/scores for this word
			Hashtable h = (Hashtable) invIndex.get(Integer.decode(words[i]));
			/*
			 * Debugging. if (h != null) System.err.println("There are
			 * "+h.size()+" documents with the word "+words[i]); else
			 * System.err.println("There are no documents with the word
			 * "+words[i]);
			 */

			// Add the score to a running total
			if (h != null) {
				Enumeration docs = h.keys();
				while (docs.hasMoreElements()) {
					Integer docId = (Integer) docs.nextElement();

					int docid = docId.intValue();
					double score = ((Double) h.get(docId)).doubleValue();

					// The score is like a dot product, but not normalized by
					// the
					// query size. But this is ok, since its constant. But we
					// need
					// to divide the score contribution by the norm of the
					// documents.
					ScoredDocument sd = (ScoredDocument) results.get(docId);
					if (sd == null) {
						sd = new ScoredDocument(documents[docid], docid, score / docSizes[docid]);
						results.put(docId, sd);
					} else {
						sd.updateScore(score / docSizes[docid], "");
						results.put(docId, sd);
					}
				}
			}
		}

		ScoredDocument resultArr[] = hashtableToArray(results);

		// Now sort by score, and truncate results if too many
		Arrays.sort(resultArr);

		int maxDocs = Options.getInt("SEARCHER_MAX_DOCS");
		
		if (resultArr.length > maxDocs) {
			ScoredDocument newResults[] = new ScoredDocument[maxDocs];
			for (int i = 0; i < maxDocs; i++)
				newResults[i] = resultArr[i];
			resultArr = newResults;
		}

		return new RerankedHits(resultArr);
	}

	public String[] loadFields() {
		return new String[] { "document", "id" };
	}

	/**
	 * Pick a random document from the collection.
	 * 
	 * @return The id of a random valid document in the index.
	 */
	protected int randomDoc() throws IOException {

		return (int) Math.floor(Math.random() * documents.length);
	}

	/**
	 * Pick a random document from the collection in the category specified.
	 * This is terribly inefficient!
	 * 
	 * @return The id of a random valid document in this category, or -1 if we
	 *         fail in finding on.
	 */
	protected int randomDoc(String category) throws IOException {

		// No categories.
		return randomDoc();
	}

	/**
	 * Return the unique identifier of a random document in the collection.
	 * 
	 * @return A random document identifier that is valid.
	 */
	public String randomDocUniqId() throws IOException {

		// Ids are the same as unique identifiers
		return "" + randomDoc();
	}

	/** Return a random document in a given category (though categories don't exist here) */
	public String randomDocUniqId(String category) throws IOException {
		
		// No categories
		return randomDocUniqId();
	}
	
	/** Returns the document with this unique ID, or null if id doesn't exist. */
	public ScoredDocument getDoc(String uniqId) throws IOException {

		int id = Integer.parseInt(uniqId);
		Document d = documents[id];
		ScoredDocument sd = new ScoredDocument(d, id, 0);

		return sd;
	}

	/**
	 * Return the maximum document id present in the index.
	 * 
	 * @return The maximum document id present in the index.
	 */
	public long getIndexSize() {
		return documents.length;
	}

	public Document getDoc(int id) {
		return documents[id];
	}
	
	/**
	 * Load the documents from the files specified.
	 * 
	 * @param documentFile
	 *            File containing the documents.
	 * @param labelFile
	 *            File containing the labels of the documents.
	 */
	private void loadDocuments(String docFile, String lblFile)
			throws IOException {

		BufferedReader brDocs, brLabels;
		String docLine, topicLine;
		int count;

		System.out.println("Loading documents.");

		// Count the number of documents
		brDocs = new BufferedReader(new InputStreamReader(new FileInputStream(
				docFile)));
		brLabels = new BufferedReader(new InputStreamReader(
				new FileInputStream(lblFile)));

		count = 0;
		while ((docLine = brDocs.readLine()) != null) {
			count++;
			topicLine = brLabels.readLine();
			if (topicLine == null)
				throw new IOException(
						"Document and label file of different lengths.");
		}

		documents = new Document[count];

		brDocs.close();
		brLabels.close();

		// Read the documents
		brDocs = new BufferedReader(new InputStreamReader(new FileInputStream(
				documentFile)));
		brLabels = new BufferedReader(new InputStreamReader(
				new FileInputStream(labelFile)));

		int id = 0;
		while ((docLine = brDocs.readLine()) != null) {
			topicLine = brLabels.readLine();
			Document doc = new Document();
			doc.add(new Field("id", "" + id, Field.Store.YES, Field.Index.UN_TOKENIZED));
			doc.add(new Field("document", docLine, Field.Store.YES, Field.Index.UN_TOKENIZED));
			doc.add(new Field("topics", topicLine, Field.Store.YES, Field.Index.UN_TOKENIZED));

			documents[id] = doc;
			id++;
		}
		System.out.println("Loaded " + id + " documents.");

		brDocs.close();
		brLabels.close();
	}

	private Hashtable makeInvIndex() {

		Hashtable h = new Hashtable(1000);
		Hashtable oneWord;

		for (int i = 0; i < documents.length; i++) {

			String content = documents[i].get("document");
			String tokens[] = content.split(" ");
			for (int j = 0; j < tokens.length; j++) {

				// We assume tokens (i.e. document ids)

				String parts[] = tokens[j].split(":");
				int wordId = Integer.parseInt(parts[0]);
				double score = Double.parseDouble(parts[1]);

				oneWord = (Hashtable) h.get(new Integer(wordId));
				if (oneWord == null) {
					oneWord = new Hashtable();
				}

				// i is the document id, and we put the score as the object
				oneWord.put(new Integer(i), new Double(score));

				h.put(new Integer(wordId), oneWord);
			}
		}

		return h;
	}

	/** document size */
	private double docSize(Document d) {

		double norm = 0;
		String content = d.get("document");
		String tokens[] = content.split(" ");
		for (int i = 0; i < tokens.length; i++) {
			String parts[] = tokens[i].split(":");
			double value = Double.parseDouble(parts[1]);
			norm += value * value;
		}
		norm = Math.sqrt(norm);

		return norm;
	}

	public void main(String args[]) throws Exception {

		ModelSearcher s = new ModelSearcher(args[1], args[2]);
		s.search(args[3], null);
	}
	
	/** 
	 * Returns the clickable link for this collection, just the id
	 */
	public String toHtml(ScoredDocument sd) {
		return sd.getDoc().get("id");
	}

}
