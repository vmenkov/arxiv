package edu.cornell.cs.osmot.searcher;

import java.io.IOException;
import java.util.HashSet;
import java.util.Vector;
import org.apache.lucene.search.*;

import edu.cornell.cs.osmot.logger.*;
import edu.cornell.cs.osmot.options.*;

/**
 * This is a wrapper for Hits, so that we can modify the ranking. You create a set
 * of RerankerHits by passing it an array of results (as ScoredDocuments) and a
 * Hits object. The results are taken as the first results, then they are padded
 * with the results from Hits in order, as needed.
 * 
 * @author Filip Radlinski
 *
 */

public class RerankedHits {
	
	private Hits hits;
	private HashSet resultsPresent;
	private ScoredDocument[] initialResults;
	private Vector offsets;
	private boolean[] sourceBits;

	// For FairPairs: reordering is done on the fly when results are requested.
	// Similarly for WorseShuffle (which reduces the quality of rankings intentionally)
	private int fpReordering[] = null;

	// For debugging
	private String mode = null;

	// For sorting by date
	private boolean byDate;
	private Vector dateOffsets; // Where to look to get specific result numbers
	private int irPos;     // Maximum position in initial results already consumed
	private int hitsPos;   // Maximum position in hits already consumed

	// Upper and lower bound on number of results (we know it better as we get results)
	private int numResultsLB = -1;  
	private int numResultsUB = -1;
 	
	private static boolean debug = Options.getBool("DEBUG");
	
	public RerankedHits(ScoredDocument[] r) {
		this(r, null);
	}
	 
	public RerankedHits(ScoredDocument[] r, Hits h) {
		this(r, h, false, null);
	}

	public RerankedHits(ScoredDocument[] r, Hits h, boolean bd, boolean[] b) {

		hits = h;
		initialResults = r;
		sourceBits = b;

		if (initialResults == null) {
			if(debug) Logger.log(" **** No Initial Results");
			initialResults = new ScoredDocument[1];
			initialResults[0] = null;
			sourceBits = new boolean[1];
			sourceBits[0] = true;
		}

		resultsPresent = new HashSet(initialResults.length);
		for (int i=0; i<initialResults.length; i++)
			if(initialResults[i] != null)
				resultsPresent.add(new Integer(initialResults[i].getId()));
		
		Logger.log("Results present has "+resultsPresent.size()+" elements.");
		fpReordering = null;
		offsets = new Vector();
		
		// Initialize date sort things.
		byDate = bd;
		dateOffsets = new Vector();
		irPos = 0;
		hitsPos = 0;
		
		// Get the bounds on the lengths;
		if (hits == null) {
			numResultsLB = initialResults.length;
			numResultsUB = initialResults.length;
		} else {
			numResultsLB = Math.max(initialResults.length, hits.length());
			numResultsUB = initialResults.length + hits.length();
		}
		
		if (debug) Logger.log("There are "+numResultsLB+" - "+numResultsUB+" results in RerankedHits.");
	}

	public int getSourceBit(int rank) {
		if((sourceBits == null)||(rank >= initialResults.length))
			return -1;
		return ((sourceBits[rank] == true) ? 1 : 0);
	}

	public boolean setSourceBit(int rank, boolean source) {
		if((sourceBits == null)||(rank >= initialResults.length))
			return false;
		sourceBits[rank] = source;
		return true;
	}

	public void setReordering(int reordering[]) {
		fpReordering = reordering;
	}
	
	public int[] getReordering() {
		return fpReordering;
	}

	public void setMode(String debug) {
		mode = debug;
	}

	public String getMode() {
		return mode;
	}
		
	public boolean getByDate() {
		return byDate;
	}
	
	/**
	 * Gets the result at this rank, using the fairpairs lookup table to
	 * reorder results on the fly as needed.
	 */
	private int getPos(int rank) {
		if (fpReordering == null)
			return rank;
		if (rank >= fpReordering.length)
			return rank;
		return fpReordering[rank];
	}
	
	/** 
	 * Returns the approximate number of results - impossible to know exactly
	 * until we actually walk through all the results and see which ones are
	 * also in initialResults
	 *
	 * @return The approximate number of results
	 */
	public int length() {
		return (numResultsLB + numResultsUB)/2;
	}

	/** 
	 * Returns a lower bound on the number of results
	 *
	 * @return A lower bound on the number of results
	 */
	public int lengthLB() {
		return numResultsLB;
	}
	
	
	/**
	 * Returns an upper bound on the number of results
	 * @return An upper bound on the number of results
	 */
	public int lengthUB() {
		return numResultsUB;
	}
	
	/**
	 * Returns the number of results that are in the initial results list.
	 */
	public int prefixLength() {
		return initialResults.length;
	}

	/**
	 * Tells where to find document number i in the hits. This is called when we 
	 * want the i^th document that is not in the original set. We need to find the
	 * i^th document that does not occur in the original set. 
	 * 
	 * @param i   The document we want (absolute number in results, starting at 0)
	 * @return The number of the hit to take to get this result
	 * @throws IOException   Thrown if i is too small
	 */
	private int getOffset(int i) throws IOException {
		
		if (i < initialResults.length)
			throw new IOException("getOffset called when result is in the original set.");
		if (i > numResultsUB)
			throw new IOException("Document index "+i+" too big. Result count may have changed.");
		
		int offsetPos = i - initialResults.length;
		
		// Make sure we have a some past the one we want.
		if (offsets.size() <= offsetPos + 10) {
			
			// Get the last offset in hits that we have know to not be in the initial results
			int lastOffset = -1;
			if (offsets.size() > 0)
				lastOffset = ((Integer)offsets.elementAt(offsets.size()-1)).intValue();

			int id, tmpOffset;
			
			// Until we get to the result we want plus a few more (to have an better
			// count of how many more results there may be), keep finding results not yet
			// in the result set.
			boolean keepGoing = true;
			while (offsets.size() <= offsetPos + 10 && keepGoing) {

				boolean goodOffset = true;
				
				// This is the result after the last one we have previously 
				// seen. Get the id to check it.
				tmpOffset = lastOffset;
				
				do {
					// Get the next offset value, see if its good
					tmpOffset++;
					if (tmpOffset < hits.length()) {
						id = hits.id(tmpOffset);
						//Logger.log("Trying: hits("+tmpOffset+") = docid:"+id);
					} else {
						// The new upper bound is the length of the offsets - all offsets
						// are valid but we know we can't get any more.
						if (offsets.size() + initialResults.length < numResultsUB) {
							numResultsUB = offsets.size() + initialResults.length;
							//Logger.log("gO-2: New length upper bound:"+numResultsUB);
						}
						goodOffset = false;
						id = -1;
					}
					// Continue so long as this result is in the initialResults set
				} while (goodOffset && resultsPresent.contains(new Integer(id)));
				
				// We might have discovered that i is too big, so we wouldn't
				// want to add an offset
				if (goodOffset) {
					// We know the tmpOffset'th result in hits is not in the orignal
					// result set, so it is the curPos'th result of the merged set.
					offsets.add(new Integer(tmpOffset));
					lastOffset = tmpOffset;

					// Make sure we keep the lower bound up to date.
					if (offsets.size() + initialResults.length > numResultsLB) {
						numResultsLB = offsets.size() + initialResults.length;
						//Logger.log("gO-3: New length lower bound:" + numResultsLB);			
					}

				} else if (offsets.size() <= offsetPos){
					throw new IOException ("Result number "+i+" is too big. Result count may have changed.");
				} else { // We died when trying to look ahead.
					keepGoing = false;
				}
			} // End of while we don't have 10 past the one we want

		} // End of if we don't have the one we want
		
		if (i > numResultsUB)
			throw new IOException("Document index "+i+" too big");
		
		return ((Integer)offsets.elementAt(offsetPos)).intValue();
	}

	public double score(int i) throws IOException {

		int oldI = i;
		
		// Get the reordered position, for FairPairs
		i = getPos(i);
		
		if (byDate) {
			int p = datePos(i);
			if (p < initialResults.length)
				return initialResults[p].getScore();
			else {
				double score = hits.score(p-initialResults.length);
				if (oldI > numResultsLB) {
					numResultsLB = oldI;
					//Logger.log("s-1: New length lower bound:"+numResultsLB);
				}
				return score;
			}
		} else {
			if (i < initialResults.length)
				return initialResults[i].getScore();
			else
				return hits.score(getOffset(i));
		}
	}
	
	public ScoredDocument doc(int i) throws IOException {
		
		// Get the reordered position, for FairPairs
		int oldI = i;
		i = getPos(i);
		if (debug)
			Logger.log("Asked for "+oldI+", gave "+i);
		
		if (byDate) {
			int p = datePos(i);
			if (p < initialResults.length) {
				// The result comes from the initial set
				ScoredDocument sd = initialResults[p];
				if (fpReordering != null)
					sd.setRanks(oldI, i);
				return sd;
			} else {
				// The result come from the "padding" hits
				int newP = p-initialResults.length;
				double score = hits.score(newP);
				if (oldI > numResultsLB) {
					numResultsLB = oldI;
					//Logger.log("d-1: New length lower bound:"+numResultsLB);
				}
				ScoredDocument sd = new ScoredDocument(hits.doc(newP), hits.id(newP), 0);
				sd.updateScore(score, "Score from all-hits query");
				if (fpReordering != null)
					sd.setRanks(oldI,i);
				else
					// The result is not in either ranking (if interleaved). In fact,
					// the low results should not be used for learning. These ranks
					// are only used with with FairPairs or when interleaving.
					sd.setRanks(-1,-1);
				return sd;
			}
		} else { // Not sorted by date
			if (i < initialResults.length) {
                if (debug) Logger.log ("Finding rank " + i +" out of " + initialResults.length); 
				ScoredDocument sd = initialResults[i];
				if (fpReordering != null)
					sd.setRanks(oldI, i);
				return sd;
			} else {
                if (debug) Logger.log ("Out of range, finding low result"); 
				int o = getOffset(i);
				ScoredDocument sd = new ScoredDocument(hits.doc(o), hits.id(o), 0);
				sd.updateScore(hits.score(o), "Score from all-hits query");
				if (fpReordering != null)
					sd.setRanks(oldI,i);
				else
					// The result is not in either ranking (if interleaved). In fact,
					// the low results should not be used for learning. These ranks
					// are only used with with FairPairs or when interleaving.
					sd.setRanks(-1,-1);
				return sd;
			}
		}
	}
	
	public int id(int i) throws IOException {

		int oldI = i;

		// Get the reordered position, for FairPairs
		i = getPos(i);
		
		if (byDate) {
			int p = datePos(i);
			if (p < initialResults.length)
				return initialResults[p].getId();
			else {
				int id = hits.id(p-initialResults.length);
				if (oldI > numResultsLB) {
					numResultsLB = oldI;
					//Logger.log("i-1: New length lower bound:"+numResultsLB);
				}
				return id;
			}
		} else {
			if (i < initialResults.length)
				return initialResults[i].getId();
			else
				return hits.id(getOffset(i));
		}
	}
	
	/**
	 * Return the position to look to get the i^th object when sorting by date.
	 * Return the position in the initial results, or if its not there then
	 * the position in the original results + the initial results length.
	 * 
	 * @param i
	 * @return
	 */
	private int datePos(int i) throws IOException {
		
		//Logger.log("Want datePos at "+i+", have "+dateOffsets.size());
		
		if (dateOffsets.size() > i)
			return ((Integer)dateOffsets.get(i)).intValue();
		
		int curKey = dateOffsets.size()-1;

		//Logger.log("Need to find a new dateOffset. curKey: "+curKey);
		
		int curPos = -1;
		if (curKey >= 0)
			curPos = ((Integer)dateOffsets.get(curKey)).intValue();
		
		while (curKey < i) {
			
			//Logger.log(""+irPos+" "+initialResults.length+" "+hitsPos+" "+hits.length());
			
			curKey++;
			if (irPos >= initialResults.length && hitsPos >= hits.length()) {
				numResultsUB = Math.min(numResultsUB, i); 
				throw new IOException("Requested too many documents ("+i+")");
			} else if (irPos >= initialResults.length) {
				curPos = hitsPos + initialResults.length;
				hitsPos++;
			} else if (hitsPos >= hits.length()) {
				curPos = irPos;
				irPos++;
			} else if (initialResults[irPos].getDate().compareTo(ScoredDocument.getDate(hits.doc(hitsPos))) >= 0) {
				curPos = irPos;
				irPos++;
			} else {
				curPos = hitsPos+initialResults.length;
				hitsPos++;
			}
			dateOffsets.add(new Integer(curPos));
		}
		
		if (i+1 > numResultsLB) {
			numResultsLB = i+1;
		}
		
		return curPos;
	}
	
	/**
	 * Return the internal set of hits - for creating a new reranked hits when interleaving.
	 */
	public Hits hits() {
		return hits;
	}
	
	/**
	 * For easy conversion to strings
	 */
	public String toString() {
		return "[ResultSet: length in "+numResultsLB+"-"+numResultsUB+". Prefix of length "+initialResults.length+" and "+hits.length()+" other hits]";
	}
	
	/** RerankedHits is meant to be used throughout now.
	 * Return the initial results, for old code
	 */
	public ScoredDocument[] initialResults() {
		return initialResults;
	}
}
