package edu.cornell.cs.osmot.searcher;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.Hits;

import java.io.IOException;
import java.io.File;
import java.io.FilenameFilter;

import edu.cornell.cs.osmot.options.Options;
import edu.cornell.cs.osmot.reranker.Reranker;
import edu.cornell.cs.osmot.logger.Logger;

import org.apache.nutch.searcher.*;
import org.apache.nutch.segment.SegmentReader;
import org.apache.nutch.fs.LocalFileSystem;
//import net.nutch.searcher.*;
//import net.nutch.segment.*;
//import net.nutch.fs.*;
//import org.dom4j.DocumentException;

class NutchFilter implements FilenameFilter {
	public boolean accept (File dir, String name) {
		return (name.length() == 14);
	}
}

/**
 * This class implements searching a Lucene index.
 * 
 * @author Filip Radlinski
 * @version 1.0, April 2005
 */
public class NutchSearcher extends Searcher {

	private boolean debug;
	private String indexDir;
	private SegmentReader sr[];
	private int numSr; // Number of non-null segment readers
	
	private IndexSearcher indexSearcher;
	
	private org.apache.nutch.searcher.Searcher searcher;
	private org.apache.nutch.searcher.HitDetailer detailer;
	//private net.nutch.searcher.Searcher searcher;
	//private net.nutch.searcher.HitDetailer detailer;
	private HitSummarizer summarizer;
	
	/**
	 * Initializes the searcher.
	 * 
	 * @param indexDir
	 *            the directory where the index is stored.
	 */
	private void init(String pIndexDir) throws IOException {

		this.indexDir = pIndexDir;

		// Get the fields that exist in the document collection.
		fields = loadFields();
		fieldsShort = new String[fields.length];
		for (int i = 0; i < fields.length; i++) {
			fieldsShort[i] = fields[i].toUpperCase().replaceAll("-", "");
		}

		// For searching
		if (Options.getBool("DEBUG"))
			Logger.log("Making an index searcher at "+indexDir);
		
		if (!(new File(indexDir,"segments").exists()) ||
			!(new File(indexDir,"index").exists())) {
			Logger.log("Error: segments and/or index does not exist in "+indexDir+". Bad index directory");
			throw new IOException("No index and/or segments found. See Osmot log file for details.");
		}
		
		File segmentsFile = new File(indexDir,"segments");
		NutchFilter nf = new NutchFilter();
		File segmentDirs[] = segmentsFile.listFiles(nf);
		
		if (Options.getBool("DEBUG"))
			Logger.log("There are "+segmentDirs.length+" segments.");
		//indexSearcher = new IndexSearcher(segmentDirs);
		indexSearcher = new IndexSearcher(new File(indexDir,"index").getCanonicalPath());
		
		searcher = indexSearcher;
		detailer = indexSearcher;
				
		// For random document generation
		if (segmentDirs == null) {
			Logger.log("Error: No files found in "+indexDir+"/segments/. Can't pick random documents.");
			throw new IOException("No segments found. See Osmot log file for details.");
		}
		sr = new SegmentReader[segmentDirs.length];
		numSr = 0;
		for(int i=0; i<segmentDirs.length; i++) {
			try {
				sr[i] = new SegmentReader(segmentDirs[i]);
				numSr++;
			} catch (Exception e) {
				sr[i] = null;
			}
		}
	
		summarizer = new FetchedSegments(new LocalFileSystem(), new File(indexDir,"segments").getCanonicalPath());
		
		if (summarizer == null) {
			throw new IOException("Can't open summarizer at " + indexDir);
		}
	}

	/**
	 * Create a new searcher with no learned ranking functions. We'll just use
	 * the default ranking function defined below in this class.
	 * 
	 * @param indexDir
	 *            The directory where the Lucene index is stored.
	 */
	public NutchSearcher(String indexDir) throws IOException {

		debug = Options.getBool("DEBUG");
		
		init(indexDir);
	}

	/**
	 * @deprecated Use origHits() now.
	 * 
	 * Return the original results for this query for each field.
	 * 
	 * @param query
	 *            The query to run.
	 * @return An array of results for each field.
	 */
	public String[][] origResults(String query) throws IOException {

		org.apache.nutch.searcher.Hits hits;
		HitDetails[] details;
		
		String[][] oResults = new String[2][];

		query = query.trim().toLowerCase();

		if (query.equals("")) {
			for (int i = 0; i < oResults.length; i++)
				oResults[i] = new String[0];
			return oResults;
		}

		// A stray AND at the end of a query can confuse the parser.
		if (query.length() > 4) {
			if (query.substring(query.length() - 3, query.length()).equals(
					" and")) {
				//log("Warning: Removed an AND at the end of query "+query);
				query = query.substring(0, query.length() - 4);
			}
		}

		try {
			Query q = Query.parse(query);
			hits = searcher.search(q, Options.getInt("SEARCHER_MAX_DOCS"), null, null, false);
			//hits = searcher.search(q, Options.getInt("SEARCHER_MAX_DOCS"));
			details = detailer.getDetails(hits.getHits(0, hits.getLength()));
		} catch (Exception e) {
			log("Error: Strange exception when trying to rerun query "
					+ query);
			log(e.toString());
			hits = null;
			details = null;
		}

		// This is the query as given to nutch
		oResults[0] = new String[hits.getLength()];
		for (int i = 0; hits != null && i < hits.getLength(); i++) {
			oResults[0][i] = details[i].getValue(Options.get("UNIQ_ID_FIELD"));
		}
		
		// This is the second field, the URL. You can't search on it with
		// Nutch, so the results are empty.
		oResults[1] = new String[0];
		
		return oResults;
	}
	
	/**
	 * Return the original results for this query for each field.
	 * The results are returned by origResults. This is a separate
	 * function since we didn't need the scores originally, and this
	 * is an experiment to see if they help the learner. So its not
	 * yet used, so its not implemented.
	 * 
	 * @param query
	 *            The query to run.
	 * @return The results for each field.
	 */
	public Hits[] origHits(String query) throws IOException {

		throw new IOException("NutchSearcher.origHits NOT IMPLEMENTED!");
	}	

	/**
	 * @deprecated Use origHits() instead.
	 * 
	 * Return the original scores for this query for each field.
	 * The results are returned by origResults. This is a separate
	 * function since we didn't need the scores originally, and this
	 * is an experiment to see if they help the learner. Becauase of
	 * this, the function isn't actually implemented.
	 * 
	 * @param query
	 *            The query to run.
	 * @return An array of results for each field.
	 */
	public double[][] origScores(String query) {
		
		return null;
	}
		
	/**
	 * Return a snippet for this document for this query. Some searchers may 
	 * want to over-ride this.
	 * 
	 * @param d     The document to get a snippet of.
	 * @param query The query to return a snippet for.
	 * @return The snippet to display.
	 */
	public String getSnippet(ScoredDocument d, String query) {
		String snippet = d.getDoc().get("summary");
		
		if (snippet==null || snippet.equals("null")) {
			// This document wasn't in the orignal nutch results for this query,
			// but we need a snippet. So we must ask Nutch for one.
			try {
				RerankedHits results = search(d.getDoc().get("url"),null);
				snippet = results.doc(0).getDoc().get("summary");
				snippet = Snippeter.boldify(snippet.replaceAll("<b>","").replaceAll("</b>",""),query);
			} catch (IOException e) {
			} catch (ParseException e) {
			}
		}
			
		return snippet;
	}
	
	/**
	 * Search for this query, then rerank the results with the specified
	 * reranker.
	 * 
	 * @param query
	 *            The query to run
	 * @param reranker
	 *            The reranker to use. Set to null for no reranking.
	 * @param overrideMax 
	 * 			  Use a larger maximum on the number of documents to get.
	 * @return The ranked results of the search.
	 */
	public RerankedHits search(String query, Reranker reranker)
			throws IOException, ParseException {

		int maxDocs = Options.getInt("SEARCHER_MAX_DOCS");
	
		Query q = Query.parse(query);

		// It dies here. I can't see why: parse fails on a strange error (ExceptionInInitializerError in NutchAnalysis)
		// The same parse works fine in pure nutch. 
		// It seems the parser has more state that doesn't initialize right. I don't know why...
		
		if (debug)
			Logger.log("Running search.");
		org.apache.nutch.searcher.Hits hits = searcher.search(q, maxDocs, null, null, false);
		//Hits hits = searcher.search(q, Options.getInt("SEARCHER_MAX_DOCS"));
		if (debug)
			Logger.log("Getting details.");
		HitDetails [] details = detailer.getDetails(hits.getHits(0,hits.getLength()));
		if (debug)
			Logger.log("Done.");
			
		// We just get a list of hits, we need to convert them to 
		// an array of scored documents.
		ScoredDocument[] results = new ScoredDocument[hits.getLength()];

		double rankScore, nutchScore;
		Document doc;
		ScoredDocument sd;
		String [] summaries = summarizer.getSummary(details, q);
		
		for (int i = 0; i < hits.getLength(); i++) {

			/* Nutch 0.7 no longer has a simple score as far as I can tell. */
			//nutchScore = hits.getHit(i).getScore();
			nutchScore = 1.0/Math.log(2+i);			

			/* Unfortunately, Nutch only gives us the list of fields and values back. We want
			 * some convenient "package" to pass around, a Lucene "Document". So we need to 
			 * put the document back together, after the the HitDetailer gave us just the 
			 * fields & values. This is inefficient, but hopefully not a problem. An alternative
			 * would be to use exactly a HitDetails entry just like Nutch throughout Osmot...
			 */ 
			doc = new Document();
			for(int j=0; j < details[i].getLength(); j++) {
				doc.add(new Field(details[i].getField(j), details[i].getValue(j), Field.Store.YES, Field.Index.NO));
			}
		
			doc.add(new Field("summary", summaries[i], Field.Store.YES, Field.Index.NO));
			
			if (reranker != null) {
				// WARNING: This assumes we are scoring with the ranks, not with actual scores.
				// This might not be true for new models.
				// TODOL: Fix this code to work with both types of scores.
				rankScore = reranker.score(0, i);
				sd = new ScoredDocument(doc, -1, rankScore);
				sd.addExplanation("Field " + fields[0] + ", top " 
						+ (i + 1) + " => " + rankScore);
			} else {
				sd = new ScoredDocument(doc, -1, nutchScore);
				sd.addExplanation("Hits[" + (i + 1)
						+ "] (base 1) on field " + fields[0] + " => "
						+ nutchScore);
			}
			results[i] = sd;
		}		
		
		// results should already be sorted and of the right length.

		RerankedHits rh = new RerankedHits(results);
		
		return rh;
	}

	/**
	 * Return the fields present in the document collection. In the case of
	 * Nutch, the only field we use is the one that stores the score as
	 * computed by Nutch on the query. We do not try to learn over different
	 * Nutch-internal fields.
	 * 
	 * @return An array of the fields present in the index.
	 */
	protected String[] loadFields() throws IOException {

		String[] f = {"NUTCH","url"};

		return f;
	}
	
	/**
	 * Pick a random document from the collection.
	 * 
	 * @return The id of a random valid document in the index.
	 */
	protected int randomDoc() throws IOException {

		// We always return a dummy document as the "random" one.
		// In the future we should pick a real document, its just tricky
		// to do without making any changes to the Nutch source.
		return -1;
	}

	/**
	 * Pick a random document from the collection in the category specified.
	 * 
	 * @return The id of a random valid document in this category, or -1 if we
	 *         fail in finding one.
	 */
	protected int randomDoc(String category) throws IOException {

		return -1;
	}

	/**
	 * Return the unique identifier of a random document in the collection.
	 * 
	 * @return A random document identifier that is valid.
	 */
	public String randomDocUniqId() throws IOException {

		return "http://random-document-not-picked/";
	}

	public String randomDocUniqId(String category) throws IOException {
		
		return "http://random-document-not-picked/";
	}
	
	/** Returns the document with this unique ID, or null if id doesn't exist. */
	public ScoredDocument getDoc(String uniqId) throws IOException {

		Query q = Query.parse("url:"+uniqId);
		org.apache.nutch.searcher.Hits hits = searcher.search(q, 1, null, null, false);
		//Hits hits = searcher.search(q, 1);
		if (hits.getLength() == 0)
			return null;
		
		HitDetails details = detailer.getDetails(hits.getHit(0));
		
		Document doc = new Document();
		for(int j=0; j < details.getLength(); j++)
			doc.add(new Field(details.getField(j), details.getValue(j), Field.Store.YES, Field.Index.NO));
		
		ScoredDocument sd = new ScoredDocument(doc, -1, 0);

		return sd;
	}

	/**
	 * Used to run searches from the command line. There are a number of usage
	 * modes: If there is one argument, just run the query. If there is one
	 * argument and its "MULTI", repeatedly wait for a query and document. If
	 * there is a query and document, return stats about the document for that
	 * query.
	 */
	public static void main(String[] args) throws IOException, ParseException {

		if (args.length == 1) {

			String queryString = args[0];

			Searcher s = new NutchSearcher(Options.get("INDEX_DIRECTORY"));
			RerankedHits r = s.search(queryString, null);

			System.out.println("Query is: " + queryString);
			System.out.println("Found " + r.length() + " hits.\n");

			for (int i = 0; i < r.length(); i++) {
				System.out.println((i + 1) + ". "
						+ r.doc(i).getUniqId() + ": score = "
						+ r.score(i));
				System.out.println(s.getSnippet(r.doc(i), queryString));
				System.out.println("");
			}

		} else if (args.length == 2) {
			// Its asking for a document and stats about it

			String queryString = args[0];
			String wantedDoc = args[1];

			Searcher s = new NutchSearcher(Options.get("INDEX_DIRECTORY"));
			RerankedHits r = s.search(queryString, null);

			System.out.println("Query is: " + queryString);
			System.out.println("Found " + r.length() + " hits.\n");

			for (int i = 0; i < r.length(); i++) {
				if (r.doc(i).getUniqId().equals(wantedDoc)) {
					System.out.println((i + 1) + ". "
							+ r.doc(i).getUniqId() + ": score = " + r.score(i));
					System.out.println(Snippeter.getSnippet(r.doc(i).getDoc(), queryString, false,false));
					System.out.println("");
				}
			}

		} else {

			System.out
					.println("Usage:\n\tSearcher <query>          : Run query.");
			System.out
					.println("\tSearcher <uniqId> <query> : Print match of document to query.");
			System.out
					.println("\tSearcher MULTI            : Print match of many documents to many queries.");
		}

	}
	
	/** 
	 * Return the HTML clickable link of the result.
	 */
	public String toHtml(ScoredDocument sd) {
		Document doc = sd.getDoc();
		if (doc.get("title") == null)
			return "(No Title)";

		return doc.get("title");
	}
	
	// Not implemented.
	public Document getDoc(int id) {
		return null;
	}
}
