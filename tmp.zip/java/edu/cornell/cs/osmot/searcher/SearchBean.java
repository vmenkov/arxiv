package edu.cornell.cs.osmot.searcher;

import java.io.IOException;

import java.util.Date;
import java.util.Random;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.lucene.queryParser.ParseException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.math.BigInteger;

import edu.cornell.cs.osmot.options.Options;
import edu.cornell.cs.osmot.searcher.Searcher;
import edu.cornell.cs.osmot.searcher.WeightedLuceneSearcher;
import edu.cornell.cs.osmot.searcher.Snippeter;
import edu.cornell.cs.osmot.reranker.FeatureConverter;
import edu.cornell.cs.osmot.reranker.Reranker;
import edu.cornell.cs.osmot.reranker.LinearReranker;
import edu.cornell.cs.osmot.logger.Logger;

/**
 * Allows sorting by decreasing date.
 */
class DateComparator implements java.util.Comparator {
	public int compare(Object o1, Object o2) {
		Date d1 = ((ScoredDocument)o1).getDate();
		Date d2 = ((ScoredDocument)o2).getDate();
		
		if (d1 == null && d2 == null)
			return 0;
		else if (d1 == null)
			return -1;
		else if (d2 == null)
			return 1;
		
		return d2.compareTo(d1);
	}
}

/**
 * This class implements the servlet interface for the search engine.
 * 
 * @author Filip Radlinski
 * @version 1.0, April 2005
 */
public class SearchBean {

	private Searcher s;
	protected Searcher s1;
	protected Searcher sw;
	protected int randomizationLimit = 11;
	protected String indexDirectory;

	private FeatureConverter fc;

	private Reranker rChains = null;
	private Reranker rNoChains = null;
    private Reranker linearReranker = null;

	private static boolean debug;
	
	private double modeProbs[] = null;
	
	/** Look up the SearchBean for an application. */
	public synchronized static SearchBean get(ServletContext app)
			throws Exception {
		
		SearchBean bean = (SearchBean) app.getAttribute("searchBean");

		if (bean == null) {
			debug = Options.getBool("DEBUG");
			if(debug) Logger.log("Creating a SearchBean");
			bean = new SearchBean();
			app.setAttribute("searchBean", bean);
			if(debug) Logger.log("SearchBean ready");
		}

		return bean;
	}

	/** Create a new SearchBean with default file names. */
	public SearchBean() throws Exception {
		this(Options.get("INDEX_DIRECTORY"), Options
				.get("RERANKER_CHAINS_MODEL_FILE"), Options
				.get("RERANKER_NOCHAINS_MODEL_FILE"), Options
				.get("RERANKER_FEATURE_FILE"));
	}

	/**
	 * Create a search bean with these index and cache files, and with no
	 * learned ranking functions.
	 * 
	 * @param indexDir
	 *            The index directory.
	 * @param cacheDir
	 *            The cache directory.
	 */
	public SearchBean(String indexDir) throws Exception {

		debug = Options.getBool("DEBUG");
		
		if (Options.get("SEARCHER_TYPE").equals("NutchSearcher"))
			s = new NutchSearcher(indexDir);
		else if (Options.get("SEARCHER_TYPE").equals("LuceneSearcher"))
			s = new LuceneSearcher(indexDir);
		
		init(indexDir);
		
		// No rerankers
		fc = null;
		rChains = null;
		rNoChains = null;
	}

	/** Create a search bean with these files. */
	public SearchBean(String indexDir, String chainsModel,
			String nochainsModel, String featureFile) throws IOException {

		debug = Options.getBool("DEBUG");
		
		if (debug)
		{
			Logger.log("Searcher type is "+Options.get("SEARCHER_TYPE"));
		}
		
		if (Options.get("SEARCHER_TYPE").equals("NutchSearcher"))
			s = new NutchSearcher(indexDir);
		else if (Options.get("SEARCHER_TYPE").equals("LuceneSearcher"))
			s = new LuceneSearcher(indexDir);
	
		init(indexDir);

		if (debug)
			Logger.log("Making feature converter from "+featureFile+", and rerankers.");
		
		fc = new FeatureConverter(featureFile);
		if (fc.numFeatures() > 0) {
			try {
				rChains = new Reranker(chainsModel, fc, s.getFields(),
						  Options.getBool("RERANKER_CHAINS_USE_SCORES"), 
						  Options.getBool("RERANKER_CHAINS_ONE_VALUE"));
			} catch (IOException e) {
				Logger.log("Loading chains reranker using model "+chainsModel+" failed: "+e.toString()+"; "+e.getMessage());
				// Do nothing - we failed in tring to load the reranker, so it stays null
			}
			try {
				rNoChains = new Reranker(nochainsModel, fc, s.getFields(),
						  Options.getBool("RERANKER_NOCHAINS_USE_SCORES"),
						  Options.getBool("RERANKER_NOCHAINS_ONE_VALUE"));
			} catch (IOException e) {
				Logger.log("Loading nochains reranker using model "+nochainsModel+" failed: "+e.toString()+"; "+e.getMessage());
				// Do nothing - we failed in tring to load the reranker, so it stays null
			}
		} else {
			Logger.log("Warning: No reranker features, so rerankers not created.");
		}
		
		if (debug)
			Logger.log("Done creating SearchBean.");
	}	

	/** 
         * Initialization code common to all constructors
         */

	protected void init(String indexDir) {
		indexDirectory = indexDir;	
	}

	/**
	 * Faster version of main search function. Run a search for the query, 
	 * given some information needed for the logging, as well as the mode of 
	 * the query to run.
	 * 
	 * @param query
	 *            The query to run
	 * @param session
	 *            The session, used to generate seed.
	 * @param request
	 *            The request, used to generate log. If null, no log is made.
	 * @param mode
	 *            The mode of the query, set to null to use default.
	 * @param log
	 * 			  If true, the the query is logged.
	 * @param byDate
	 * 		      If true, results are sorted by date instead of by score.
	 * @param min
	 * 		      Minimum result number that will be displayed to users
	 * @param max 
	 *            Maximum result number that will be displayed to users
	 * @return An array of results, sorted as they are to be displayed to the
	 *         user.
	 */
	public RerankedHits searchFast(String query, String session,
			HttpServletRequest request, String mode, boolean log, boolean byDate) 
		throws IOException, ParseException {

        if(debug) Logger.log("Starting SearchBean.SearchFast");

		long seed = getSeed(session);

		String qid = request.getParameter("qid");

        if(debug) Logger.log("Qid: " + qid);

        if(qid != null)
            mode = Logger.qidMode(qid);

        if(debug) Logger.log("Mode: " + mode);

		if (byDate) {
			mode = "dt";
		} else if (mode == null) {
			mode = pickMode(request);
		}
		
		// Get a qid
        if(qid == null) qid = getQid(request, mode);
		
		// Anything following "category:" in the query
		String category = Searcher.getCategory(query);

		// Log the request
		Logger.logRequest(request, mode);
		
		if (debug) Logger.log("SearchBean.SearchFast Called. Mode is "+mode+". Log is "+log);
		
		// Run the search
		RerankedHits finalResults;
		
		if (mode.equals("1a")) { // Mix chains reranker with nochains reranker

			RerankedHits resultsCh = ((LuceneSearcher)s).search(query, rChains);
			RerankedHits resultsNC = ((LuceneSearcher)s).search(query, rNoChains);
			if (debug) Logger.log("Combining "+resultsCh+" and "+resultsNC);
			finalResults = s.combine(resultsCh, resultsNC, category, seed);

			if (debug) {
				int ranks[] = finalResults.doc(0).getRanks();
				Logger.log("After combining, first doc has ranks "+ranks[0]+","+ranks[1]);
			}
			
		} else if (mode.equals("1b")) { // Mix chains reranker with original

			RerankedHits resultsCh = ((LuceneSearcher)s).search(query, rChains);
			RerankedHits resultsOrig = ((LuceneSearcher)s).search(query, null);
			if (debug) Logger.log("Combining "+resultsCh+" and "+resultsOrig);
			finalResults = s.combine(resultsCh, resultsOrig, category, seed);
			
		} else if (mode.equals("1c")) { // Mix nochains reranker with original
			
			RerankedHits resultsNC = ((LuceneSearcher)s).search(query, rNoChains);
			RerankedHits resultsOrig = ((LuceneSearcher)s).search(query, null);
			if (debug) Logger.log("Combining "+resultsNC+" and "+resultsOrig);
			finalResults = s.combine(resultsNC, resultsOrig, category, seed);
		
		} else if (mode.equals("2a")) { // Simple search, reranked with nochains

			finalResults = ((LuceneSearcher)s).search(query, rNoChains);

		} else if (mode.equals("2b")) { // Simple search, reranked with chains

			finalResults = ((LuceneSearcher)s).search(query, rChains);
			
		} else if (mode.equals("2c")) { // Simple search, not reranked
		
			finalResults = ((LuceneSearcher)s).search(query, null);

		} else if (mode.charAt(0) == '3' ||
				   mode.charAt(0) == '4') { // FairPairs
			
			finalResults = ((LuceneSearcher)s).search(query, rChains);
			
			int setSize = 2;
			if (mode.charAt(0) == '4')
				setSize = 4;

			String strSeed = session+query;
			int length = Math.min(100, finalResults.lengthLB());
			
			finalResults.setReordering(s.FairPairs(setSize, mode, strSeed, length));

		} else if (mode.equals("5a")) {	// Base query results only on a smaller set of attributes

			secondarySearcher();
			finalResults = ((LuceneSearcher)s1).search(query, null);
		
		} else if (mode.equals("5b")) { // Takes the top N output of 5a and randomizes them

			secondarySearcher();
			finalResults = ((LuceneSearcher)s1).search(query, null);
			finalResults.setReordering(generateRandomization(getSeed(session), randomizationLimit, finalResults.prefixLength()));

		} else if ( (mode.equals("5c")) ||
			    (mode.equals("8a")) ||
			    (mode.equals("8b")) ) { // Combines normal, unweight
		
			secondarySearcher();

			RerankedHits[] dataSources = new RerankedHits[2];
			dataSources[0] = ((LuceneSearcher)s).search(query, null); 
			dataSources[1] = ((LuceneSearcher)s1).search(query, null);
			finalResults = s.combineGameSelection(dataSources[0], dataSources[1], category,getQuerySeed(session, query));

		} else if (mode.equals("5d")) { // Combines unweight, unweighted randomized
		
			secondarySearcher();

			RerankedHits[] dataSources = new RerankedHits[2];
			dataSources[0] = ((LuceneSearcher)s1).search(query, null);
			dataSources[1] = ((LuceneSearcher)s1).search(query, null);
			dataSources[1].setReordering(generateRandomization(getSeed(session), randomizationLimit, dataSources[1].prefixLength()));
			finalResults = s.combine(dataSources[0], dataSources[1], category, seed);

		} else if( (mode.equals("5e"))  ||
			    (mode.equals("8c")) ||
			    (mode.equals("8d")) ) { // Combines normal, unweight randomized
		
			secondarySearcher();

			// uggh, recursive, need to be careful	
			RerankedHits[] dataSources = new RerankedHits[2];
			dataSources[0] = ((LuceneSearcher)s).search(query, null); 
			dataSources[1] = ((LuceneSearcher)s1).search(query, null);
			dataSources[1].setReordering(generateRandomization(getSeed(session), randomizationLimit, dataSources[1].prefixLength()));
			finalResults = s.combineGameSelection(dataSources[0], dataSources[1], category, getQuerySeed(session, query));

		} else if (mode.equals("6a")) {
			// Like the best (2c) search except we randomly swap two docs in the top 5 
			// for two at ranks 6-10 seeded by (query,"6a")
			
			finalResults = ((LuceneSearcher)s).search(query, null);
			// Second parameter of WorseShuffle is the seed for shuffling
			finalResults.setReordering(s.WorseShuffle(2, query+"2", finalResults.initialResults().length));
			
		} else if (mode.equals("6b")) {
			// Like the best (2c) search except we randomly swap four docs in the top 5 
			// for two at ranks 6-10 seeded by (query,"6a")
			
			finalResults = ((LuceneSearcher)s).search(query, null);
			finalResults.setReordering(s.WorseShuffle(4, query+"4", finalResults.initialResults().length));
			
		} else if (mode.equals("6c")) {
			// Interleave 2c and 6a

			RerankedHits resultsOrig = ((LuceneSearcher)s).search(query, null);
			RerankedHits results6a = ((LuceneSearcher)s).search(query, null);
			results6a.setReordering(s.WorseShuffle(2, query+"2", results6a.initialResults().length));			
			if (debug) Logger.log("Combining "+resultsOrig+" and "+results6a);
			finalResults = s.combine(resultsOrig, results6a, category, seed);

		} else if (mode.equals("6d")) {
			// Interleave 2c and 6b
			
			RerankedHits resultsOrig = ((LuceneSearcher)s).search(query, null);
			RerankedHits results6b = ((LuceneSearcher)s).search(query, null);
			results6b.setReordering(s.WorseShuffle(4, query+"4", results6b.initialResults().length));			
			if (debug) Logger.log("Combining "+resultsOrig+" and "+results6b);
			finalResults = s.combine(resultsOrig, results6b, category, seed);
			
		} else if (mode.equals("6e")) {
			// Interleave 6a and 6b
			
			RerankedHits results6a = ((LuceneSearcher)s).search(query, null);
			results6a.setReordering(s.WorseShuffle(2, query+"2", results6a.initialResults().length));			
			RerankedHits results6b = ((LuceneSearcher)s).search(query, null);
			results6b.setReordering(s.WorseShuffle(4, query+"4", results6b.initialResults().length));			
			if (debug) Logger.log("Combining "+results6a+" and "+results6b);
			finalResults = s.combine(results6a, results6b, category, seed);
			
		} else if (mode.equals("6f")) {
			// Like the best (2c) search except we randomly swap half the docs first page with second page 
			
			finalResults = ((LuceneSearcher)s).search(query, null);
			// Second parameter of WorseShuffle is the seed for shuffling
			// Last parameter is the half_length, so swap 5 from first 10 with 5 from last 10
			finalResults.setReordering(s.WorseShuffle(5, query+"5", finalResults.initialResults().length, 10));
			
		} else if (mode.equals("7a")) { 
			// Interleave 2c and 5a

			secondarySearcher();

			RerankedHits[] dataSources = new RerankedHits[2];
			dataSources[0] = ((LuceneSearcher)s).search(query, null); 
			dataSources[1] = ((LuceneSearcher)s1).search(query, null);
			finalResults = s.combineGameSelection(dataSources[0], dataSources[1], category, getQuerySeed(session, query));

		} else if (mode.equals("7b")) { 
			// Interleave 5a and 5b
		
			secondarySearcher();

			RerankedHits[] dataSources = new RerankedHits[2];
			dataSources[0] = ((LuceneSearcher)s1).search(query, null);
			dataSources[1] = ((LuceneSearcher)s1).search(query, null);
			dataSources[1].setReordering(generateRandomization(getSeed(session), randomizationLimit, dataSources[1].prefixLength()));

			finalResults = s.combineGameSelection(dataSources[0], dataSources[1], category, getQuerySeed(session, query));

		} else if (mode.equals("7c")) { 
			// Interleave 2c and 5b
			
			secondarySearcher();

			RerankedHits[] dataSources = new RerankedHits[2];
			dataSources[0] = ((LuceneSearcher)s).search(query, null);
			dataSources[1] = ((LuceneSearcher)s1).search(query, null);
			dataSources[1].setReordering(generateRandomization(getSeed(session), randomizationLimit, dataSources[1].prefixLength()));
			
			finalResults = s.combineGameSelection(dataSources[0], dataSources[1], category, getQuerySeed(session, query));
		
		} else if (mode.equals("7d")) { 
			// Interleave 2c and 6a

			RerankedHits resultsOrig = ((LuceneSearcher)s).search(query, null);
			RerankedHits results6a = ((LuceneSearcher)s).search(query, null);
			results6a.setReordering(s.WorseShuffle(2, query+"2", results6a.lengthLB()));			
			if (debug) Logger.log("Combining "+resultsOrig+" and "+results6a);
			finalResults = s.combineGameSelection(resultsOrig, results6a, category, getQuerySeed(session, query));
			
		} else if (mode.equals("7e")) { 
			// Interleave 2c and 6b
			
			RerankedHits resultsOrig = ((LuceneSearcher)s).search(query, null);
			RerankedHits results6b = ((LuceneSearcher)s).search(query, null);
			results6b.setReordering(s.WorseShuffle(4, query+"4", results6b.initialResults().length));			
			if (debug) Logger.log("Combining "+resultsOrig+" and "+results6b);
			finalResults = s.combineGameSelection(resultsOrig, results6b, category, getQuerySeed(session, query));
			
		} else if (mode.equals("7f")) {  
			// Interleave 6a and 6b
		
			RerankedHits results6a = ((LuceneSearcher)s).search(query, null);
			results6a.setReordering(s.WorseShuffle(2, query+"2", results6a.initialResults().length));
			RerankedHits results6b = ((LuceneSearcher)s).search(query, null);
			results6b.setReordering(s.WorseShuffle(4, query+"4", results6b.initialResults().length));			
			if (debug) Logger.log("Combining "+results6a+" and "+results6b);
			finalResults = s.combineGameSelection(results6a, results6b, category,  getQuerySeed(session, query));

        } else if (mode.equals("9a")) { // boost title
            weightedSearcher();
            double[] weights = boostWeight(sw.fields, "title", 5.0);
            ((WeightedLuceneSearcher)sw).setWeights(weights);
			finalResults = ((WeightedLuceneSearcher)sw).search(query, null);

        } else if (mode.equals("9b")) { // boost abstract
            weightedSearcher();
            double[] weights = boostWeight(sw.fields, "abstract", 5.0);
            ((WeightedLuceneSearcher)sw).setWeights(weights);
			finalResults = ((WeightedLuceneSearcher)sw).search(query, null);

        } else if (mode.equals("9c")) { // boost article
            weightedSearcher();
            double[] weights = boostWeight(sw.fields, "article", 5.0);
            ((WeightedLuceneSearcher)sw).setWeights(weights);
			finalResults = ((WeightedLuceneSearcher)sw).search(query, null);

        } else if (mode.equals("9d")) { // swap 5 in first 10 and next 10

            finalResults = ((LuceneSearcher)s).search(query,null);
			finalResults.setReordering(s.WorseShuffle(7, query+"9d", finalResults.initialResults().length, 10));
			
        } else if (mode.equals("9e")) { // swap 5 in first and next 10 for 9a
            weightedSearcher();
            double[] weights = boostWeight(sw.fields, "title", 5.0);
            ((WeightedLuceneSearcher)sw).setWeights(weights);
			finalResults = ((WeightedLuceneSearcher)sw).search(query, null);
			finalResults.setReordering(s.WorseShuffle(7, query+"9e", finalResults.initialResults().length, 10) );

        } else if (mode.equals("9f")) { // swap 5 in first and next 10 for 9b
            weightedSearcher();
            double[] weights = boostWeight(sw.fields, "abstract", 5.0);
            ((WeightedLuceneSearcher)sw).setWeights(weights);
			finalResults = ((WeightedLuceneSearcher)sw).search(query, null);
			finalResults.setReordering(s.WorseShuffle(7, query+"9f", finalResults.initialResults().length, 10));

        } else if (mode.equals("9g")) { // swap 5 in first and next 10 for 9c
            weightedSearcher();
            double[] weights = boostWeight(sw.fields, "article", 5.0);
            ((WeightedLuceneSearcher)sw).setWeights(weights);
			finalResults = ((WeightedLuceneSearcher)sw).search(query, null);
			finalResults.setReordering(s.WorseShuffle(7, query+"9g", finalResults.initialResults().length, 10));
		} else if (mode.equals("9h")) {	// Base query results only on a smaller set of attributes

			secondarySearcher();
			finalResults = ((LuceneSearcher)s1).search(query, null);

        } else if (mode.charAt(0) == '9') {
            String mode1 = mode.substring(1,2);
            String mode2 = mode.substring(2,3);

            
			RerankedHits results1 = computeWeightedSwappedSearch(query, mode1);
			RerankedHits results2 = computeWeightedSwappedSearch(query, mode2);

			if (debug) Logger.log("Combining "+results1+" and "+results2);
            finalResults = s.combineGameSelection(results1, results2, category, getQuerySeed(session, query));
			//finalResults = s.combineGameSelection(results2, results1, category, getQuerySeed(session, query));
        } else if (mode.equals("Aa")) {
            finalResults = computeTitleWeightedSearch(query,"a");
        } else if (mode.equals("Ab")) {
            finalResults = computeTitleWeightedSearch(query,"b");
        } else if (mode.substring(0,1).equals("A") || mode.substring(0,1).equals("B")) {
            String mode1 = mode.substring(1,2);
            String mode2 = mode.substring(2,3);
			RerankedHits results1 = computeTitleWeightedSearch(query, mode1);
			RerankedHits results2 = computeTitleWeightedSearch(query, mode2);
			if (debug) Logger.log("Combining "+results1+" and "+results2);
            finalResults = s.combineGameSelection(results1, results2, category, getQuerySeed(session, query));
		} else if (mode.equals("dt")) { // Sort by date
			
			finalResults = ((LuceneSearcher)s).searchDate(query, null);
			
		} else {
			
			Logger.log("ERROR: Invalid mode " + mode);
			return null;
			
		}

        if (debug) Logger.log("Mode: " + mode + " searching complete.");

		// Save mode for debugging
		finalResults.setMode(mode);	

		// Don't log repeated queries from a long time ago
		if (Math.abs(new Date().getTime() - qidTime(qid)) > 24 * 3600 * 1000)
			log = false;
			
		// Log the query and results
		if (log) {
			Logger.logQuery(request, query, mode, finalResults, qid, session, true);		
			if (debug) Logger.log("Query logged.");	
		}
			
		if (debug) Logger.log("Query finished.");
	
		return finalResults;
	}
	
	/**
	 * Generates a randomization of results
	 *
	 * @param seed Random seed
	 * @param howMany how many results do you want randomized
	 */
	private int[] generateRandomization(long seed, int howMany, int maxLimit) {
		
		// defensive
		if(maxLimit < howMany)
			howMany = maxLimit;

		int[] newRanking = new int[howMany];
		for(int i=0;i<howMany;i++)
			newRanking[i] = howMany - i - 1;

		// implementing http://en.wikipedia.org/wiki/Fisher-Yates_shuffle
		Random rng = new Random (seed);
		int n = howMany;
		while (--n > 0) {
			int k = rng.nextInt(n + 1);  // 0 <= k <= n (!)
			int temp = newRanking[n];
			newRanking[n] = newRanking[k];
			newRanking[k] = temp;
		}
		return newRanking;	
	}
		
	/** 
	 * Sets up the secondary searcher which is using less fields to search on
	 *
	 */
	protected void secondarySearcher() 
		  throws IOException {

		// Secondary searcher
		String[] sparseVersion = new String[] { "article", "authors", "paper"};
		if(debug) Logger.log("Creating with : " + indexDirectory + " " + sparseVersion[0]);
		if(s1 == null) {
			s1 = new SparseLuceneSearcher(indexDirectory, sparseVersion);
		}
	}

	/** 
	 * Sets up the secondary searcher which uses linear weighted reranking
	 *
	 */
    protected void weightedSearcher()
        throws IOException {

       /*
        String[] fields = s.getFields();
        double[] weights = new double[fields.length];
        for (int i = 0; i < fields.length; i++)
        {
            if(fields[i].equals("title"))
                weights[i] = 2.0;
            else
                weights[i] = 1.0;
            if(debug) Logger.log("Weight for " + fields[i] + ": " + weights[i]);
        }

        if(debug) Logger.log("Created Linear Reranker");
        linearReranker = new LinearReranker(fields, weights);
        if(debug) Logger.log("Done creating Linear Reranker");
        */
		// Secondary searcher
		if(debug) Logger.log("Creating WeightedLuceneSearcher with : " + indexDirectory);
		if(sw == null) {
			sw = new WeightedLuceneSearcher(indexDirectory);
		}
	}

        /** 
         * Force the index to be reloaded.
	 */
 	public void updateSearcher() {
	        ((LuceneSearcher)s).updateSearcher(true);
	}

        /**
	 * Generates a query id. It tells us about the mode, the reranking model file used,
	 * and the time. 
	 * 
	 * @param request  The request object that keeps track of the session.
	 * @param mode     The mode of the request.
	 * @return
	 */
	private String getQid(HttpServletRequest request, String mode) {
		
		String qid = request.getParameter("qid");
		if (qid == null) {
			qid = (String) request.getAttribute("qid");
		}
		
		if (qid == null) {
				
			long now = new Date().getTime();
			String modelStr = "";
			if (rChains == null) 
				modelStr += "nC";
			else 
				modelStr += rChains.getId();
			if (rNoChains == null)
				modelStr += "nN";
			else 
				modelStr += rNoChains.getId();
				
			qid = "" + now + mode + "_" + modelStr  + "_" +  request.getRemoteAddr().hashCode();
		}
		request.setAttribute("qid", qid);

		return qid;
	}
	
	/**
	 * Returns a snippet for a given query and result document.
	 * 
	 * @param query
	 *            The query.
	 * @param d
	 *            The document for this result.
	 */
	public String getSnippet(ScoredDocument d, String query, String mode) {

		if(mode.charAt(0) == '8') {
			if((mode.charAt(1) == 'a')||(mode.charAt(1) == 'c'))
				return s.getAbstractSnippet(d.getDoc(), query);
			return s.getLongSnippet(d.getDoc(),query);
		}
		String ans =  s.getSnippet(d, query);
        if(mode != null && mode.substring(0,1).equals("B"))
            return ans;
        return Snippeter.boldify(ans, query);
	}

	/**
	 * Returns an extended snippet for a given query and result document.
	 * 
	 * @param query
	 *            The query.
	 * @param d
	 *            The document for this result.
	 */
	public String getLongSnippet(ScoredDocument d, String query) {

		return s.getLongSnippet(d.getDoc(), query);
	}	

	/**
	 * Returns an extended snippet for a given query and result document for 
	 * use in the context of display of a particular paper.
	 * 
	 * @param query
	 *            The query.
	 * @param d
	 *            The document for this result.
	 */
	public String getPaperSnippet(ScoredDocument d, String query) {

		return s.getPaperSnippet(d.getDoc(), query);
	}	
	
	 
	/**
	 * Return the document with this unique identifier, or null if it doesn't
	 * exist. Sets the document and document id, but sets the score to 0.
	 */
	public ScoredDocument getDoc(String uniqId) throws IOException {
		return s.getDoc(uniqId);
	}
	
	/**
	 * Boldify a given string (usually the title string of a result) given a
	 * query.
	 * 
	 * @param s
	 *            The string to boldify.
	 * @param query
	 *            The query.
	 */
	public String boldify(String str, String query) {
        return boldify(str,query,null);
    }
	public String boldify(String str, String query, String mode) {
        if(mode != null && mode.substring(0,1).equals("B"))
            return str;

		return Snippeter.boldify(str, query);
	}

	/**
	 * Logs a click on a result that goes to the abstract page.
	 * 
	 * @param ip
	 *            The IP address of the user.
	 * @param session
	 *            The session id of the search session.
	 * @param qid
	 *            The unique id of the query that returned this result
	 * @param doc
	 *            The unique identifier of the document
	 */
	public void logClick(HttpServletRequest request, String session, String qid,
			String doc, boolean byDate) {
		this.logClick(request, session, qid, doc, "abs", byDate);
	}

	/**
	 * Logs a click on a result that goes to the any format of the page.
	 * 
	 * @param ip
	 *            The IP address of the user.
	 * @param session
	 *            The session id of the search session.
	 * @param qid
	 *            The unique id of the query that returned this result
	 * @param doc
	 *            The unique identifier of the document
	 * @param format
	 *            The format requested
	 */
	public void logClick(HttpServletRequest request, String session, String qid,
			String doc, String format, boolean byDate) {
		long seed = getSeed(session);
		String mode;
		if (byDate) 
			mode = "dt";
		else 
			mode = pickMode(request);

        if(debug) Logger.log("Query time: " + qidTime(qid) + " Click time: " + new Date().getTime());
		
		// Only log clicks within a day of the query actually running. Otherwise
		// people might be following stale results, or following links to searches
		// posted on the web
		if (Math.abs(new Date().getTime() - qidTime(qid)) < 24 * 3600 * 1000)
        {
            if(debug) Logger.log("Logging Click");
			Logger.logClick(request, mode, session, qid, doc, format);
        }
	}
	
	/**
	 * Return the HTML link of a scored document that should be displayed.
	 * This is collection specific, which is why it is here, despite it being
	 * a method that should intuitively belong in ScoredDocument
	 * @param sd The scored document to generate the link
	 * @return Title string in HTML
	 */
	public String toHtml(ScoredDocument sd) {
		return s.toHtml(sd);
	}

	
	/**
	 * Picks a mode for a search. This is random, but takes a seed that is
	 * constant for the duration of a user's session so that page 2 is the same
	 * mode as page 1, and also so that if a query is re-run, it will also be
	 * run with the same mode.
	 * 
	 * @param seed
	 *            A random number generator seed.
	 */
	private String pickMode(HttpServletRequest request) {

		/*
		 * Search modes are: 1: EVALUATION 1a: Mix chains reranker with nochains
		 * reranker 1b: Mix chains reranker with no reranker 1c: Mix nochains
		 * reranker with no reranker 2: DATA COLLECTION 2a: Display results
		 * reranked with nochains reranker 2b: Display results reranked with
		 * chains reranker 2c: Display results without reranking
		 * 
		 * 3a: Results are randomly flipped 1-2 3-4 5-6, etc
		 * 3b: Results are randomly flipper (1) 2-3 4-5 6-7, etc
		 */
		
		if (modeProbs == null) {
			double total = 0;
			modeProbs = new double[Searcher.modes.length];
			for (int i=0; i<modeProbs.length; i++) {
				modeProbs[i] = Options.getDouble("SEARCHER_MODE_"+Searcher.modes[i]);
				if(debug) Logger.log("SEARCHER_MODE_"+Searcher.modes[i]+": "+modeProbs[i]);
				total += modeProbs[i];		
				modeProbs[i] = total;
			}
			// Normalize the probabilities to 1
			for (int i=0; i<modeProbs.length; i++) {
				modeProbs[i] /= total;
				if(debug) Logger.log("Source " + i + " == prob " + modeProbs[i]);
			}
		}
		
		// UserID is a combo of IP + userAgent
		String ip = request.getRemoteAddr();
		String userAgent = request.getHeader("user-agent");
		BigInteger hash ;
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("MD5");
			messageDigest.update(ip.getBytes(),0, ip.length());
			messageDigest.update(userAgent.getBytes(),0,userAgent.length());
			hash = new BigInteger(1,messageDigest.digest());
		} catch (NoSuchAlgorithmException e) {
			hash = null;
		}

		if(hash != null)
		{
			// get random in [0,1]
			int spread = Math.abs(hash.intValue());
			double r = (spread*1.0)/Integer.MAX_VALUE;

			if(debug) {
				Logger.log("Got user input as IP = '" + ip + "' UserAgent = '" + userAgent+"'");
				Logger.log("Resulted in hash value = " + spread + " which becomes " + r); 
			}
			for(int i=0; i<modeProbs.length; i++) {
				
				if(debug)Logger.log("Mode = " + i + " = " + modeProbs[i]);
				if (modeProbs[i] > r)
                {
                    if(debug) Logger.log("Found mode: " + Searcher.modes[i]);
					return Searcher.modes[i];
                }
				//r -= modeProbs[i];
			}
		}
		
		// Should never be reached, unless the random number is 1 or we get
		// a small number rounding effect.
		if(debug) {
			Logger.log("*** Reached end of all possibilities, bug?");
		}
		return "2c";
		
	}

	/**
	 * Return the string value of a given option. This is useful in the JSP
	 * code for getting things like URLs.
	 *
	 * @name Option name to return
	 * @return The value of the option (from osmot.conf)
	 */
	public String getOption(String name) {
		return Options.get(name);
 	}

	/**
	 * Return the seed for a given session. Used for randomization.
	 *
	 * @session Session to compute data for
	 * @return The value of the seed that could be used
	 */
	private long getSeed(String session) {
		return session.hashCode();
	}

	/**
	 * Return the string value of a given session query combination.
	 *
	 * @session Session to compute data for
	 * @query Query to compute data for
	 * @return The value of the seed that could be used
	 */
	private long getQuerySeed(String session, String query) { 
		return (session.hashCode() ^ query.hashCode());
	}
	
	public String getList() {
		try {
			return ((LuceneSearcher)s).makeList(null,-1);
		} catch (ParseException e) {
			return "Error making list: "+e.toString();
		} catch (IOException e) {
			return "Error making list: "+e.toString();			
		}
	}
	
	/**
	 * Return the time (milliseconds since 1/1/1970) when the qid was created.
	 * 
	 * @param qid A query id
	 * @return The time (milliseconds since 1/1/1970) when the qid was created.
	 */
	public static long qidTime(String qid) {
	    if (qid == null)
		    return 0;

	    if (qid.length() >= 13) 
		    return Long.parseLong(qid.substring(0,13));

	    return 0;
	}
    private double[] boostWeight(String fields[], String toBoost, double w)
    {
            double[] weights = new double[fields.length];
            for(int i = 0; i < fields.length; i++)
            {
                weights[i] = 1.0;
                if(fields[i].equals(toBoost))
                    weights[i] = w;
            }
            return weights;
    }

    private double[] boostWeight(String fields[], String toBoost[], double w)
    {
            double[] weights = new double[fields.length];
            for(int i = 0; i < fields.length; i++)
            {
                weights[i] = 1.0;
                for(int j = 0; j<toBoost.length; j++)
                {
                    if(fields[i].equals(toBoost[j]))
                        weights[i] = w;
                }
            }
            return weights;
    }

    private RerankedHits computeTitleWeightedSearch(String query, String mode)
        throws IOException, ParseException {

        RerankedHits tempResults = null;
        Logger.log("Running Mode: " + mode);

        String strs[] = {"title", "abstract"};

        if (mode.equals("a")) { // suppress title -
            weightedSearcher();
            double[] weights = boostWeight(sw.fields, strs, 0);
            ((WeightedLuceneSearcher)sw).setWeights(weights);
			tempResults = ((WeightedLuceneSearcher)sw).search(query, null);
        } else if (mode.equals("b")) { // boost factor 10
            weightedSearcher();
            double[] weights = boostWeight(sw.fields, strs, 10);
            ((WeightedLuceneSearcher)sw).setWeights(weights);
			tempResults = ((WeightedLuceneSearcher)sw).search(query, null);
        } else { //original ranking 
            tempResults = ((LuceneSearcher)s).search(query,null);
        }

        return tempResults;
    }

    private RerankedHits computeWeightedSwappedSearch(String query, String mode)
        throws IOException, ParseException {

        RerankedHits tempResults = null;
        Logger.log("Running Mode: " + mode);

        if (mode.equals("a")) { // boost title
            weightedSearcher();
            double[] weights = boostWeight(sw.fields, "title", 5.0);
            ((WeightedLuceneSearcher)sw).setWeights(weights);
			tempResults = ((WeightedLuceneSearcher)sw).search(query, null);

        } else if (mode.equals("b")) { // boost abstract
            weightedSearcher();
            double[] weights = boostWeight(sw.fields, "abstract", 5.0);
            ((WeightedLuceneSearcher)sw).setWeights(weights);
			tempResults = ((WeightedLuceneSearcher)sw).search(query, null);

        } else if (mode.equals("c")) { // boost article
            weightedSearcher();
            double[] weights = boostWeight(sw.fields, "article", 5.0);
            ((WeightedLuceneSearcher)sw).setWeights(weights);
			tempResults = ((WeightedLuceneSearcher)sw).search(query, null);

        } else if (mode.equals("d")) { // swap 5 in first 10 and next 10

            tempResults = ((LuceneSearcher)s).search(query,null);
			tempResults.setReordering(
                    s.WorseShuffle(7, query+"9d", tempResults.initialResults().length, 10));
			
        } else if (mode.equals("e")) { // swap 5 in first and next 10 for a
            weightedSearcher();
            double[] weights = boostWeight(sw.fields, "title", 5.0);
            ((WeightedLuceneSearcher)sw).setWeights(weights);
			tempResults = ((WeightedLuceneSearcher)sw).search(query, null);
			tempResults.setReordering(
                    s.WorseShuffle(7, query+"9e", tempResults.initialResults().length, 10) );

        } else if (mode.equals("f")) { // swap 5 in first and next 10 for b
            weightedSearcher();
            double[] weights = boostWeight(sw.fields, "abstract", 5.0);
            ((WeightedLuceneSearcher)sw).setWeights(weights);
			tempResults = ((WeightedLuceneSearcher)sw).search(query, null);
			tempResults.setReordering(
                    s.WorseShuffle(7, query+"9f", tempResults.initialResults().length, 10));

        } else if (mode.equals("g")) { // swap 5 in first and next 10 for c
            weightedSearcher();
            double[] weights = boostWeight(sw.fields, "article", 5.0);
            ((WeightedLuceneSearcher)sw).setWeights(weights);
			tempResults = ((WeightedLuceneSearcher)sw).search(query, null);
			tempResults.setReordering(
                    s.WorseShuffle(7, query+"9g", tempResults.initialResults().length, 10));
		} else if (mode.equals("h")) {	// Base query results only on a smaller set of attributes

			secondarySearcher();
		    tempResults = ((LuceneSearcher)s1).search(query, null);

		
        } else { //original ranking 
            tempResults = ((LuceneSearcher)s).search(query,null);
        }

        return tempResults;
    }
}
