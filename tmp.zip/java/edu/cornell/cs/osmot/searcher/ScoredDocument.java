package edu.cornell.cs.osmot.searcher;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.DateTools;

// This is used for the old index.
//import org.apache.lucene.document.DateField;
import java.text.ParseException;
import java.util.Date;

import edu.cornell.cs.osmot.options.Options;
import edu.cornell.cs.osmot.logger.Logger;

/**
 * This class implements a document with a score attached. We also store two
 * ranks. This is so that when we combine two rankings, we can keep track of
 * which ranking which document came from. The class is comparable, so we can
 * sort by score, but obviously in the case of combined rankings we don't want
 * to do that.
 * 
 * @author Filip Radlinski
 * @version 1.0, April 2005
 */
public class ScoredDocument implements Comparable {

	private Document doc;

	private double score;
	private int docId;
	private String uniqId;
	private Date docDate;
	
	private int ranks[];
	
	// An explanation of why the score is what it is.
	private String explanation;

	/**
	 * Create a new scored document with given document id and score.
	 * 
	 * @param d
	 *            The document.
	 * @param id
	 *            The document id in the lucene index.
	 * @param s
	 *            The score of the document.
	 */
	public ScoredDocument(Document d, int id, double s) {
		doc = d;
		score = s;
		explanation = "";
		ranks = new int[2];
		ranks[0] = 0;
		ranks[1] = 0;
		docId = id;
		docDate = null;
		
		// Set to null if d is null
		uniqId = getField(Options.get("UNIQ_ID_FIELD"));
	}

	/** 
	 * Sets the docid to something new.
	 */
	public void setId(int id) {
		docId = id;
	}
	
	/**
	 * Returns the two ranks of the document.
	 * 
	 * @return The two ranks of the document.
	 */
	public int[] getRanks() {
		return ranks;
	}

	/** 
	 * Returns the id of the document.
	 * @return the id of the document
	 */
	public int getId() {
		return docId;
	}
	
	/**
	 * Set the two ranks of the document.
	 * 
	 * @param i1
	 *            The rank of the document according to the first ranking.
	 * @param i2
	 *            The rank of the document according to the second ranking.
	 */
	public void setRanks(int i1, int i2) {
		ranks[0] = i1;
		ranks[1] = i2;
	}

	/**
	 * Set the two ranks of the document.
	 * 
	 * @param i1
	 *            The rank of the document according to the first ranking.
	 * @param i2
	 *            The rank of the document according to the second ranking.
	 */
	public void setNRanks(int rankInput[]) {
		ranks = rankInput;
	}

	/**
	 * Returns the document stored in this scored document.
	 * 
	 * @return The document stored in this scored document.
	 */
	public Document getDoc() {
		return doc;
	}

	/**
	 * Sets the stored document
	 * @param doc The document to set.
	 */
	public void setDoc(Document d) {
		doc = d;
		uniqId = getField(Options.get("UNIQ_ID_FIELD"));
	}
	
	/**
	 * Returns the contents of the named field in the document.
	 * 
	 * @param name
	 *            The name of a document field.
	 * @return The contents of the field.
	 */
	public String getField(String name) {
		if (doc != null)
			return doc.get(name);
		
		return "";
	}

	/**
	 * Return the score of the scored document.
	 * 
	 * @return The score of the scored document.
	 */
	public double getScore() {
		return score;
	}

	/**
	 * Return the age of the document, in days by using the document field named
	 * in the parameter. Returns -1 on failure to parse this field.
	 * 
	 */
	public int getAge(String fieldName) {

		Date docDate = getDate();

		if (docDate != null) {
			Date now = new Date();
			double age = Math.floor(1.0 * (now.getTime() - docDate.getTime())
					/ (24 * 3600000));

			return (int) age;
		} else {
			return -1;
		}
	}
	
	/**
	 * Update the score by adding delta to it.
	 * 
	 * @param delta
	 *            The change in the score for this document.
	 * @param expl
	 *            The explanation for this change.
	 */
	public void updateScore(double delta, String expl) {
		if (delta != 0) {
			score = score + delta;
			this.addExplanation(expl + " => " + delta);
		} else {
			this.addExplanation(expl + " => 0");
		}
	}


	/**
	 * Set the explanation for the score to this string.
	 * 
	 * @param s
	 *            The new explanation for the score.
	 */
	public void setExplanation(String s) {
		this.explanation = s;
	}

	/**
	 * Adds to the explanation for the score.
	 * 
	 * @param s
	 *            The string to add to the explanation.
	 */
	public void addExplanation(String s) {
		if (this.explanation.length() > 0)
			this.explanation += "<br />" + s;
		else
			this.explanation = s;
	}

	/**
	 * Returns the explanation and the final score and ranks.
	 * 
	 * @return The explanation, and the final score and document ranks.
	 */
	public String getExplanation() {
		return explanation + "<br />Final score is " + score + "<br />Ranks are "
				+ ranks[0] + "," + ranks[1];
	}

	/**
	 * Allows us to easily compare ScoredDocuments, and therefore sort an array
	 * of them by score.
	 */
	public int compareTo(Object sd) throws ClassCastException {
		if (!(sd instanceof ScoredDocument))
			throw new ClassCastException("Must compare to a ScoredDocument");

		double sd_score = ((ScoredDocument) sd).getScore();
		if (this.score > sd_score)
			return -1;
		else if (this.score < sd_score)
			return 1;

		return 0;
	}

	public String toString() {
		return getUniqId() + ":" + score;
	}

	/** Return the uniq id of this document */
	public String getUniqId() {
		return uniqId;
	}

	/** Set the uniq id of the document, even if we don't have the document */
	public void setUniqId(String s) {
		uniqId = s;
	}
	
	public Date getDate() {

		if (docDate != null)
			return docDate;
		
		String strDate = getField("date");
		if (strDate == null || strDate.length() == 0)
			return null;
		
		try {
			docDate = DateTools.stringToDate(strDate);
		} catch (ParseException e) {
			// Try the old function. It may fail silently.
			//docDate = DateField.stringToDate(strDate);
			docDate = null;
		}
		
		return docDate;
 	}
	
	public static Date getDate(Document d) {
			
		String strDate = d.get("date");

		if (strDate == null || strDate.length() == 0)
			return null;
		
		Date docDate = null;
		try {
			docDate = DateTools.stringToDate(strDate);
		} catch (ParseException e) {
			// Try the old function. It may fail silently.
			//docDate = DateField.stringToDate(strDate);
			docDate = null;
		}
		
		Logger.log("Converts to "+docDate.toString());
		
		return docDate;
	}
	
	/** Return the link to the document. */
	public String getLink() {
		return Options.get("SEARCHER_BASE_URL") + getUniqId();
	}

	/** Return the link we show the user for the document. */
	public String getVisibleLink() {
		return Options.get("SEARCHER_BASE_VISIBLE_URL") + getUniqId();
	}
}
