package edu.cornell.cs.osmot.searcher;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.DateTools;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.analysis.PerFieldAnalyzerWrapper;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.*;

import java.util.*;

import java.io.IOException;

import edu.cornell.cs.osmot.options.Options;
import edu.cornell.cs.osmot.reranker.Reranker;
import edu.cornell.cs.osmot.logger.Logger;

/**
 * This class implements searching a Lucene index.
 * 
 * @author Madhu M Kurup
 * @version 1.0, October 2007
 */
public class SparseLuceneSearcher extends LuceneSearcher {

	private String [] chosenFields;
	
	/**
	 * Create a new searcher with no learned ranking functions. We'll just use
	 * the default ranking function defined below in this class.
	 * 
	 * @param indexDir
	 *            The directory where the Lucene index is stored.
	 */
	public SparseLuceneSearcher(String indexDir, String[] selectOnlyThese) throws IOException {

		chosenFields = selectOnlyThese;
		init(indexDir);
	}

	/**
	 * Return the fields present in the document collection.
	 * 
	 * @return An array of the fields present in the index.
	 */
	protected String[] loadFields() throws IOException {
		return chosenFields;
	}
}
