package edu.cornell.cs.osmot.indexer;

import java.io.DataInputStream;

import javax.servlet.http.HttpServletRequest;

import java.util.List;
import java.util.Iterator;

import java.net.URL;

import javax.servlet.ServletContext;

import org.apache.lucene.document.Document;

import org.apache.commons.fileupload.DiskFileUpload;
import org.apache.commons.fileupload.FileItem;

import edu.cornell.cs.osmot.cache.Cache;
import edu.cornell.cs.osmot.options.Options;
import edu.cornell.cs.osmot.logger.Logger;
import edu.cornell.cs.osmot.indexer.Indexer;

/**
 * This class implements the servlet interface for adding documents to the
 * index, and updating them. It is very collection specific, so you certainly
 * don't want to use it. It is included in this source file just as an example
 * of how to insert documents into a Lucene index.
 * 
 * @author Filip Radlinski
 * @version 1.0, April 2005
 */

public class IndexBean {

	private Indexer i;

	private Cache cache;

	public synchronized static IndexBean get(ServletContext app)
			throws Exception {
		IndexBean bean = (IndexBean) app.getAttribute("indexBean");
		if (bean == null) {
			log("Creating an IndexBean");
			bean = new IndexBean();
			app.setAttribute("indexBean", bean);
			log("IndexBean ready");
		}

		return bean;
	}

	public IndexBean() throws Exception {
		this(Options.get("INDEX_DIRECTORY"), Options.get("CACHE_DIRECTORY"));
	}

	public IndexBean(String indexDir, String cacheDir) throws Exception {

		i = new Indexer(indexDir, cacheDir);
		cache = new Cache(cacheDir);
	}

	public String reIndex(HttpServletRequest req) throws Exception {

		DiskFileUpload fu = new DiskFileUpload();
		Document d;
		String paper = "(blank)";

		try {
			// maximum size before a FileUploadException will be thrown (5 Meg)
			fu.setSizeMax(Options.getInt("INDEXER_MAX_LENGTH"));

			// maximum size that will be stored in memory (5 Meg)
			fu.setSizeThreshold(Options.getInt("INDEXER_MAX_LENGTH"));

			// the location for saving data that is larger than
			// getSizeThreshold()
			fu.setRepositoryPath("/tmp");

			List fileItems = fu.parseRequest(req);

			// There are two files. The shorter one is the abstract, the longer
			// is
			// the document
			Iterator iter = fileItems.iterator();
			FileItem fi = (FileItem) iter.next();
			String abs, doc, docName = "";
			if (fi.getFieldName().equals("abstract")) {
				abs = fi.getString();
				fi = (FileItem) iter.next();
				doc = fi.getString();
				docName = fi.getName();
			} else if (fi.getFieldName().equals("document")) {
				doc = fi.getString();
				docName = fi.getName();
				abs = ((FileItem) iter.next()).getString();
			} else {
				throw new Exception("Got invalid field " + fi.getFieldName());
			}

			d = i.parse(abs, doc);

			if (d.get("paper").equals("")) {
				throw new Exception("Document " + docName
						+ " has a blank paper field.");
			} else {
				paper = d.get("paper");
			}

			// RE-ADD ANY NEW OR SPECIAL FIELDS

			// This includes deleting any old document with the same paper
			// number
			// It also puts the document into the cache
			i.indexDocument(d);

			// Overwrite the old file in the cache with the new file
			cache.cacheDocument(d.get("paper"), doc);

		} catch (Exception e) {
			log("FAILED POST UPD: " + e.toString());
			Logger.logIndexUpdate(paper, 0);
			throw new Exception(e);
		}

		log("UPD:" + d.get("paper"));
		Logger.logIndexUpdate(paper, 1);
		return d.get("paper");
	}

	public boolean reIndex(String absFileURL, String txtFileURL)
			throws Exception {

		int MAX_LENGTH = Options.getInt("INDEXER_MAX_LENGTH");

		String whole_abstract, whole_document;
		byte[] bytes = new byte[MAX_LENGTH];
		DataInputStream dis;
		URL url;
		int n;
		Document d;
		String paper = "(blank)";
		
		try {

			url = new URL(absFileURL);
			dis = new DataInputStream(url.openStream());
			n = dis.read(bytes);
			whole_abstract = new String(bytes);
			if (n < whole_abstract.length()) {
				whole_abstract = whole_abstract.substring(0, n);
			}

			url = new URL(txtFileURL);
			dis = new DataInputStream(url.openStream());
			n = dis.read(bytes);
			whole_document = new String(bytes);
			if (n < whole_document.length()) {
				whole_document = whole_document.substring(0, n);
			}

			d = i.parse(whole_abstract, whole_document);

			// RE-ADD ANY NEW OR SPECIAL FIELDS

			// This includes deleting any old document with the same paper
			// number
			// It also puts the document into the cache
			i.indexDocument(d);

			if (!d.get("paper").equals("")) {
				paper = d.get("paper");
			}
			
			// Overwrite the old file in the cache with the new file
			cache.cacheDocument(d.get("paper"), whole_document);

		} catch (Exception e) {
			log("FAILED UPD:" + absFileURL + ":" + txtFileURL);
			Logger.logIndexUpdate(paper, 0);
			return false;
		}

		log("UPD:" + absFileURL + ":" + txtFileURL);
		Logger.logIndexUpdate(paper, 1);
		return true;
	}

	private static void log(String log) {
		Logger.log(log);
	}

}
