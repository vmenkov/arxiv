package edu.cornell.cs.osmot.indexer;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;

import edu.cornell.cs.osmot.cache.Cache;
import edu.cornell.cs.osmot.options.Options;
import edu.cornell.cs.osmot.logger.Logger;

/**
 * This class shows how to create a simple Lucene index. Use it as a basis for
 * your indexer, if you want to write your own Lucene index.
 * 
 * @author Filip Radlinski
 * @version 1.0, May 2005
 */

public class SimpleIndexer {

	// Where our index lives.
	private String indexDirectory;

	private String cacheDirectory;

	/** Create a new indexer with this index directory and cache directory */
	public SimpleIndexer(String indexDir, String cacheDir) {
		indexDirectory = indexDir;
		cacheDirectory = cacheDir;
		log("Created an indexer.");
	}

	/** Returns a lucene document with some content. */
	private static Document createDocument(String id, String title, String content) {

		Document document = new Document();

		document.add(new Field("uniqId", id, Field.Store.YES, Field.Index.UN_TOKENIZED));
		document.add(new Field("title", title, Field.Store.YES, Field.Index.TOKENIZED));
		document.add(new Field("content", content, Field.Store.YES, Field.Index.TOKENIZED));

		return document;
	}

	/** Add a lucene document to the lucene index. */
	public boolean indexDocument(Document document) throws Exception {
		Analyzer analyzer = new StandardAnalyzer();

		deleteDocument(document.get("uniqId"));

		IndexWriter writer = new IndexWriter(indexDirectory, analyzer, false);
		writer.addDocument(document);
		writer.close();

		Cache c = new Cache(cacheDirectory);
		c.cacheDocument(document.get("uniqId"), document.get("content"));

		return true;
	}

	/** Delete any document with this uniqId, if present. */
	public void deleteDocument(String uniqId) throws Exception {

		IndexReader reader = IndexReader.open(indexDirectory);
		reader.deleteDocuments(new Term("uniqId", uniqId));
		reader.close();

		Cache c = new Cache(cacheDirectory);
		c.deleteDocument(uniqId);
	}

	/** Optimize the Lucene index. */
	public void optimize() throws Exception {
		Analyzer analyzer = new StandardAnalyzer();
		IndexWriter writer = new IndexWriter(indexDirectory, analyzer, false);
		writer.optimize();
		writer.close();
	}

	/** Create a new Lucene index. */
	public void newIndex() throws Exception {

		Analyzer analyzer = new StandardAnalyzer();
		IndexWriter writer = new IndexWriter(indexDirectory, analyzer, true);
		writer.close();
	}

	/** Interface so we can do things from teh command line. */
	public static void main(String[] args) throws Exception {

		String usage = "SimpleIndexer new\nSimpleIndexer add <id> <title> <content>\nSimpleIndexer delete <id>\nSimpleIndexer optimize";

		SimpleIndexer i = new SimpleIndexer(Options.get("INDEX_DIRECTORY"),
				Options.get("CACHE_DIRECTORY"));

		if (args.length == 0) {
			System.out.println(usage);
		} else {

			if (args[0].equals("new")) {

				// Create a new index

				i.newIndex();

			} else if (args[0].equals("add")) {

				// Add a new document

				if (args.length != 4) {
					System.out.println(usage);
					System.exit(1);
				}

				Document d = SimpleIndexer.createDocument(args[1], args[2], args[3]);
				if (i.indexDocument(d))
					System.out.println("Document added.");
				else
					System.out.println("Error: Document not added.");

			} else if (args[0].equals("delete")) {

				// Delete an existing document

				if (args.length != 2) {
					System.out.println(usage);
					System.exit(1);
				}

				i.deleteDocument(args[1]);

			} else if (args[0].equals("optimize")) {

				// Optimize the index

				i.optimize();

			}
		}
	}

	private void log(String msg) {

		// Save in the message in the top level log file
		Logger.log(msg);
	}
}
