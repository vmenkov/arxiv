package edu.cornell.cs.osmot.logger;

/**
 * This class represents an log entry that is for a click. They can be sorted by
 * the time.
 * 
 * @author Filip Radlinski
 * @version 1.0, May 2005
 */

public class ClickEntry implements Comparable {

	private long time, lastTime;

	private String type, ip, session, doc, qid;

	public ClickEntry(long time, String type, String doc, String qid,
			String ip, String session) {

		this.time = time;
		this.lastTime = time;
		this.type = type;
		this.doc = doc;
		this.qid = qid;
		this.ip = ip;
		this.session = session;
	}

	public String toString() {
		String result;

		result = type + ":" + doc + " (" + time + ", " + qid + ").";

		return result;
	}

	/**
	 * Allows us to sort by the document (so we don't store multiple clicks on
	 * the same document) then the time.
	 */
	public int compareTo(Object sd) throws ClassCastException {
		if (!(sd instanceof ClickEntry))
			throw new ClassCastException("Must compare to a ClickEntry");

		long otherTime = ((ClickEntry) sd).getTime();
		if (this.doc.compareTo(((ClickEntry) sd).getDoc()) != 0) {
			return this.doc.compareTo(((ClickEntry) sd).getDoc());
		} else if (this.time < otherTime) {
			return -1;
		} else if (this.time > otherTime) {
			return 1;
		}

		return 0;
	}

	/** Add a second click time, for documents that are clicked multiple times. Used when 
	 * computing time to last click - we need the last click time. Otherwise, we usually
	 * need the time of the first click (e.g. in a double-click). */
	public void addTime(long t) {
		if (t < time)
			time = t;
		if (t > lastTime)
			lastTime = t;
	}
	
	public long getTime() {
		return time;
	}

	public long getLastTime() {
		return lastTime;
	}
	
	public String getQid() {
		return qid;
	}

	public String getType() {
		return type;
	}

	public String getIP() {
		return ip;
	}

	public String getSession() {
		return session;
	}

	public String getDoc() {
		return doc;
	}
}
