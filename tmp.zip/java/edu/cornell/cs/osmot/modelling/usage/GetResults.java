package edu.cornell.cs.osmot.modelling.usage;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.Runtime;
import java.util.Random;

import edu.cornell.cs.osmot.searcher.ModelSearcher;
import edu.cornell.cs.osmot.searcher.Searcher;
import edu.cornell.cs.osmot.searcher.ScoredDocument;
import edu.cornell.cs.osmot.reranker.Reranker;
import edu.cornell.cs.osmot.reranker.FeatureConverter;

import org.apache.lucene.document.Document;

import cern.jet.stat.Gamma;

/**
 * @deprecated This class was used for modelling. It doesn't use the database
 * logging functionality and so uses lots of old code. Use at your own risk.
 * Also, it also only works on RANK BASED features.
 * 
 * This class implements the main loop for getting user performance for a given
 * search engine. In order to use it, you must have a document collection that
 * consists of three files: documents.dat, topics.dat, and document_labels.dat.
 * The first two are just sparse vector format files with one document or topic
 * per line. The label file has one line corresponding to each document and one
 * feature corresponding to each topic. The relevance of each document to each
 * topic is specified by topic:relevance entires.
 * 
 * @author Filip Radlinski
 * @version 1.0, April 2005
 */

public class GetResults {

	// The documents and topics
	private Topic[] topics;

	// Number of users we run experiments for
	private static int NUM_USERS = 4000;

	// The maximum distance in rank that we can be off in perceived relevance
	private double noise;

	// How likely the user is to give up after each query
	private double give_up;

	// Perceived relevance bonus for higher ranked documents
	private int bonus;

	// Determines the minimum click threshold
	private double threshold;

	// Determines the distribution of the patience
	private int patience;

	// Do queries improve (i.e. get longer)
	private int improvement;

	// What "substantially better" means in terms of score
	private double substantially;

	// Number of words per query
	private static int MAX_QUERY_LENGTH = 3;

	private static int MIN_QUERY_LENGTH = 1;

	private String topicFile = "topics.dat";

	private String documentFile = "documents.dat";

	private String labelFile = "documnet_labels.dat";

	/** Initialize the variables */
	private GetResults() {
		// Default values
		noise = 6;
		give_up = 0.5;
		bonus = 0;
		patience = 8;
		threshold = 1;
		improvement = 0;

		// Note: This option can't be set elsewhere.
		substantially = 0.2;
	}

	private void loadFiles() throws IOException {
		topics = loadTopics(topicFile);
	}

	/** Main program. See comments embedded in the source. */
	public static void main(String[] args) throws Exception {

		GetResults r = new GetResults();
		Reranker reranker = null;
		FeatureConverter fc = null;
		String rerankerFile = "";
		boolean useReranker = false;

		if (args.length == 0) {
			System.out.println("Usage:\n\tedu.cornell.cs.osmot.usage.GetResults --files <docs> <labels> <topics>");
			System.out.println("\tOther options: --use-reranker --noise, --give-up --threshold --bonus --patience --improvement");
			return;
		}
		
		// Some time in 2005, for simplicity in analysis
		long time = new Long("1102100000000").longValue();

		// Parse arguments.
		for (int i = 0; i < args.length; i++) {
			if (args[i].equals("--use-reranker")) {
				useReranker = true;
				rerankerFile = args[i + 1];
				fc = new FeatureConverter(args[i + 2]);
				i += 2;
			} else if (args[i].equals("--noise")) {
				r.noise = Double.parseDouble(args[i + 1]);
				i++;
			} else if (args[i].equals("--give-up")) {
				r.give_up = Double.parseDouble(args[i + 1]);
				i++;
			} else if (args[i].equals("--threshold")) {
				r.threshold = Double.parseDouble(args[i + 1]);
				i++;
			} else if (args[i].equals("--bonus")) {
				r.bonus = Integer.parseInt(args[i + 1]);
				i++;
			} else if (args[i].equals("--patience")) {
				r.patience = Integer.parseInt(args[i + 1]);
				i++;
			} else if (args[i].equals("--improvement")) {
				r.improvement = Integer.parseInt(args[i + 1]);
				i++;
			} else if (args[i].equals("--files")) {
				r.documentFile = args[i + 1];
				r.labelFile = args[i + 2];
				r.topicFile = args[i + 3];
				i += 3;
			} else {
				System.err.println("Error: Unkown parameter " + args[i]);
				return;
			}
		}

		Searcher s = new ModelSearcher(r.documentFile, r.labelFile);
		if (s == null) {
			throw new Exception("Can't create searcher.");
		}
		if (useReranker) {
			reranker = new Reranker(rerankerFile, fc, s.getFields(), false, false);
		}

		System.out.println("Running for " + NUM_USERS + " users");
		if (reranker == null)
			System.out.println("Not using a reranker.");
		else
			System.out.println("Using reranker model from "
					+ reranker.getModelFile());

		System.out.println("Parameters:\n\tnoise:     " + r.noise
				+ "\n\tgive_up:   " + r.give_up + "\n\tthreshold: "
				+ r.threshold + "\n\tbonus:     " + r.bonus + "\n\tpatience:  "
				+ r.patience + "\n\timprove:   " + r.improvement
				+ "\n\tdocFile:   " + r.documentFile + "\n\tlabelFile: "
				+ r.labelFile + "\n\ttopicFile: " + r.topicFile);

		// We can now load the files.
		r.loadFiles();

		// For each users
		for (int user = 0; user < NUM_USERS; user++) {
 
			// Pick a mode (for FairPairs reranking)
			String mode;		
			Random gen = new Random();		
			int choice = gen.nextInt(2);	
			switch (choice) {
			case 0:
				mode = "3a";
				break;
			default:
				mode = "3b";
				break;
			}
			
			System.gc();
			System.out.println("Free Memory: "
					+ (Runtime.getRuntime().totalMemory() - Runtime
							.getRuntime().freeMemory()));

			String session = "USER" + user;
			String ip = "1." + (user / 1000000) % 1000 + "." + (user / 1000)
					% 1000 + "." + user % 1000;
			long queryId = user * 1000;

			double maxRelevance = 0;
			double curRelevance = 0;
			double highestRelevance = 0;
			int highestIndex = -1;

			// User has a threshold match quality, and a total patience

			double threshold = Utils.random() * 0.5;
			threshold += r.threshold * 0.25;

			double patienceTotal = Utils.random();
			patienceTotal *= (1 + r.patience * 0.5);

			double rankBonus = 0.2 * r.bonus;
			double patience;

			// Pick a topic

			Topic topic = r.topics[Utils.pickPowerLaw(r.topics.length)];
			long topicId = topic.getId();

			System.out.println("Topic: " + topicId);

			// Its the first query (used when queries improve)
			int queryN = 0;

			int stop = 0;
			while (stop == 0) {

				System.out.println("New Query.\nPatience is " + patienceTotal);
				System.out.println("Threshold is " + threshold);

				queryId++;
				time++;

				// Generate a query in the topic
				Query query = r.generateQuery(topic, queryN, r.improvement);
				System.out.println("");
				String queryString = query.toString();

				// Execute query
				ScoredDocument[] results = s.search(queryString, reranker).initialResults();
				//s.FairPairs(results, mode, session+queryString, -1);
				for (int i = 0; i < results.length; i++) {
					System.out.print(results[i].toString() + " ");
				}
				System.out.println("");
				if (reranker != null) {
					//results = reranker.rerank(results, queryString, fc, s, null);
					for (int i = 0; i < results.length; i++) {
						System.out.print(results[i].toString() + " ");
					}
					System.out.println("");
				}

				// Work out the perceived relevances
				double[] perceivedRelevance = getPercRel(results, r.noise,
						topicId);

				// Print query
				printQuery(time, query.toString(), queryId, ip, session,
						results, topicId);

				// Work out the highest relevance in the top 5
				highestRelevance = -1;
				for (int i = 0; i < Math.min(results.length, 5); i++) {
					Document d = results[i].getDoc();
					if (GetResults.getRelevance(d, topicId) > highestRelevance) {
						highestRelevance = GetResults.getRelevance(d, topicId);
						highestIndex = i;
					}
				}

				// No results.
				if (highestRelevance == -1) {
					highestIndex = 0;
					highestRelevance = 0;
				}

				System.out.println("\nHighest relevance in top 5: "
						+ highestIndex + ":" + highestRelevance + "\n");

				/*
				 * Scan documents one by one. If above threshold, click.
				 * Otherwise subtract difference between threshold and relevance
				 * from patience
				 */
				patience = patienceTotal;
				int i = 0;
				int lastlook = -1;
				curRelevance = 0;
				double maxCurRelevance = 0;
				while (patience > 0 && i < results.length) {

					double pr = perceivedRelevance[i];
					double bonus = rankBonus / (i + 1);

					/*
					 * i is where we are looking now. If we haven't printed out
					 * a look for i, then print one out now. This is needed
					 * since we might otherwise look at the same result multiple
					 * times.
					 */
					if (lastlook < i) {
						printLook(i, results[i], r.noise, topicId,
								perceivedRelevance[i]);
						lastlook = i;
					}

					// If its good enough, we probably want to click on it.
					if (pr + bonus > threshold) {

						// Look at next result, if it exists.
						int stopLoop = 0;
						while (stopLoop == 0 && i + 1 < results.length) {
							System.out.println("Doc " + i
									+ " looks promising, looking ahead to "
									+ (i + 1));
							stopLoop = 1;

							if (lastlook < i + 1) {
								printLook(i + 1, results[i + 1], r.noise,
										topicId, perceivedRelevance[i + 1]);
								lastlook = i + 1;
							}

							//If its better, move on to it and repeat the look
							// ahead.
							if (perceivedRelevance[i + 1] > pr
									+ r.substantially) {
								System.out.println("Document " + (i + 1)
										+ " is substantially better.");
								i++;
								pr = perceivedRelevance[i];
								stopLoop = 0;
							}
						}

						// Click on this best result.
						curRelevance = GetResults.getRelevance(results[i].getDoc(),
								topic.getId());
						System.out.println("Document " + i
								+ " looks best. Clicking. See relevance as "
								+ curRelevance);
						printClick(time, results[i], queryId, ip, session);

						// Patience drops with relevance of document clicked,
						// but also
						// it just takes time, which reduces patience by a fixed
						// amount
						patience -= 0.5;
						patience -= (1 - curRelevance);
						if (curRelevance == 1)
							patience = 0;

						if (curRelevance > maxCurRelevance)
							maxCurRelevance = curRelevance;
					} else {
						// Looks bad, patience goes down.
						patience -= (threshold - pr);
					}
					System.out.println("Patience is now " + patience);
					i++;
				}

				System.out.println("Top relevance seen this query is "
						+ maxCurRelevance);
				if (maxCurRelevance > maxRelevance)
					maxRelevance = maxCurRelevance;

				// If max real relevance is 1, next user
				if (maxRelevance == 1) {
					System.out.println("FOUND MAX RELEVANCE, STOPPING.");
					stop = 1;
				}

				// Else, run another query with 50% chance
				if (Utils.random() < r.give_up)
					stop = 1;

				// If queries improve, we increment the count in the current
				// chain.
				queryN++;

			} // End loop until we stop

			System.out.println("Max relevance seen: " + maxRelevance + "\n");
			System.out.println("=== NEW USER : " + user + " === \n");
		} // End of loop over all users

	}

	/**
	 * Generate a query in the given topic. We are given the query number in
	 * case queries are to improve, where the rate of improvement is given by
	 * imprv.
	 * 
	 * @param t
	 *            Topic of the query to generate.
	 * @param queryN
	 *            The number of the query in the current query chain.
	 * @param imprv
	 *            The rate with which queries improve.
	 */
	private Query generateQuery(Topic t, int queryN, int imprv)
			throws Exception {

		int numWords = Utils.pickBinomial(MAX_QUERY_LENGTH - MIN_QUERY_LENGTH,
				0.5)
				+ MIN_QUERY_LENGTH;

		// If queries improve, we make them longer as the query number goes up
		// (starts at 0)
		numWords += queryN * imprv;

		System.out.println("Query has " + numWords + " words.");

		Query q = new Query(numWords, t);

		return q;
	}

	/** Gets the relevance of a scored document to a topic * */
	private static double getRelevance(Document d, long topic) {
		String topics = d.get("topics");
		if (topics == null || topics.length() == 0)
			return 0;

		String tokens[] = topics.split(" ");
		for (int i = 0; i < tokens.length; i++) {
			String parts[] = tokens[i].split(":");
			long id = Long.parseLong(parts[0]);
			if (id == topic)
				return Double.parseDouble(parts[1]);
		}

		return 0;
	}

	/**
	 * Load the topics from the file specified.
	 * 
	 * @param topicFile
	 *            File containing the topics.
	 */
	private Topic[] loadTopics(String pTopicFile) throws IOException {

		BufferedReader br;
		Topic loadedTopics[];
		int id = 0, count;
		String line;

		System.out.println("Loading topics.");

		br = new BufferedReader(new InputStreamReader(new FileInputStream(
				pTopicFile)));

		count = 0;
		while ((line = br.readLine()) != null)
			count++;
		loadedTopics = new Topic[count];
		br.close();

		br = new BufferedReader(new InputStreamReader(new FileInputStream(
				pTopicFile)));
		while ((line = br.readLine()) != null) {
			loadedTopics[id] = new Topic(id, line);
			id++;
		}
		System.out.println("Loaded " + id + " topics.");
		br.close();

		return loadedTopics;
	}

	/**
	 * Prints out a log entry for when users look at a result.
	 * 
	 * @param rank
	 *            The rank of the document.
	 * @param r
	 *            The result at that rank (contains the document).
	 * @param noise
	 *            The current set noise level.
	 */
	private static void printLook(int rank, ScoredDocument sd, double noise,
			long topicId, double pRel) {
		System.out.println("Looking at document " + rank + ":" + sd.getUniqId()
				+ " score:" + 0.001 * Math.round(1000 * sd.getScore())
				+ " rel:" + 0.001
				* Math.round(1000 * getRelevance(sd.getDoc(), topicId))
				+ " pRel:" + 0.001 * Math.round(1000 * pRel) 
				+ " noise:" + 0.01 * Math.round(100 * noise));
	}

	/** Print out a log entry for when users click on a result. */
	private static void printClick(long time, ScoredDocument sd, long qid,
			String ip, String session) {
		System.out.println(time + " abs:" + sd.getUniqId() + " qid:" + qid
				+ " ip:" + ip + " s:" + session);
	}

	/** Prints out the log entry for the user running a query. */
	private static void printQuery(long time, String query, long qid,
			String ip, String session, ScoredDocument results[], long topicId) {

		System.out.print(time + " " + "q:" + query + " qid:" + qid + " ip:"
				+ ip + " s:" + session + " ref:topic-" + topicId + " n:");

		System.out.print(results.length + " ");
		for (int i = 0; i < results.length; i++) {
			System.out.print(results[i].getUniqId());
			if (i + 1 < results.length)
				System.out.print(",");
		}
		System.out.print("\n");
	}

	private static double[] getPercRel(ScoredDocument sd[], double noise,
			long topicId) {

		double[] pRel = new double[sd.length];
		for (int i = 0; i < sd.length; i++) {
			pRel[i] = getPerceivedRelevance(getRelevance(sd[i].getDoc(),
					topicId), noise);
		}

		return pRel;

	}

	/**
	 * Returns the perceived relevance of this result given a specified noise
	 * level. A noise level of 7 means that the relevance is ignored, a noise
	 * level of 5 means that the relevance is close to the perceived relevance.
	 * This function uses an Incomplete Beta Distribution to model the noise in
	 * observing the relevance. Users are most likely to see a relevance close
	 * to the true relevance, but could get it wrong. The result is consistent,
	 * in that if this is called multiple times for any one result, the value
	 * returned will always be the same. But if a second result for the same
	 * document is created, that will have a different perceived relevance.
	 * 
	 * @param noise
	 *            The noise level (good values are 5-7).
	 * @return The perceived relevance for this result.
	 */
	private static double getPerceivedRelevance(double relevance, double noise) {

		double alpha, mode, pRel = 0;

		alpha = Math.pow(2, 7 - noise);
		/*
		 * Where we want the beta distribution to peak. Its always 0 at 0, so we
		 * can make it peak low if the actual relevance is 0.
		 */
		if (relevance == 0)
			mode = 0.05;
		else
			mode = relevance;
		double beta = (alpha - 1 - mode * alpha + 2 * mode) / mode;

		double target = Utils.random();

		// If the target is so big that we never get to it, the pRel stays at
		// 1.0
		pRel = 1.0;

		for (double v = 0; v < 1; v += 0.01) {
			if (Gamma.incompleteBeta(alpha, beta, v) > target) {
				pRel = v;
				break;
			}
		}

		/*
		 * Debugging... System.out.print("Target:"+target+"
		 * relevance:"+relevance); System.out.print(" pr:"+perceivedRelevance+"
		 * alpha:"+alpha); System.out.println(" beta:"+beta+" mode:"+mode+"
		 * noise:"+noise);
		 */

		return pRel;
	}
}
