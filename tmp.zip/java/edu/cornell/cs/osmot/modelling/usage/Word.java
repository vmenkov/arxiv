package edu.cornell.cs.osmot.modelling.usage;

/**
 * The Word class represents a single word feature, which is simply a word id
 * and a double value (which should always be positive, but this is not
 * enforced). We also implement Comparable so that we can order the feature
 * vector by word id, so that we can easily sort it and output sparse vectors
 * representing documents to train an SVM on.
 * 
 * @author Filip Radlinski
 * @version 1.0, April 2005
 */

public class Word implements Comparable {

	private int wordId;

	private double value;

	/**
	 * Create a word feature with id wid and value w.
	 * 
	 * @param wid
	 *            The id of the word feature.
	 * @param v
	 *            The value or weight of this word feature.
	 */
	public Word(int wid, double v) {
		this.wordId = wid;
		this.value = v;
	}

	/**
	 * Used when we sort.
	 */
	public int compareTo(Object w) {

		if (((Word) w).getWord() > this.wordId)
			return -1;
		else if (((Word) w).getWord() == this.wordId)
			return 0;
		else
			return 1;
	}

	/**
	 * Return the word id .
	 * 
	 * @return The id of this word.
	 */
	public int getWord() {
		return wordId;
	}

	/**
	 * Returns the value of this word feature.
	 * 
	 * @return The value of this word feature.
	 */
	public double getValue() {
		return value;
	}

}
