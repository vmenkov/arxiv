package edu.cornell.cs.osmot.modelling.usage;

import java.util.Date;
import edu.cornell.lassp.houle.RngPack.Ranlux;

/**
 * Utilities for picking words and topics.
 * 
 * @author Filip Radlinski
 * @version 1.0, April 2005
 */

public class Utils {

	static int last_max = -1;

	static double last_total = -1;

	static Ranlux ranlux = null;

	/**
	 * Just a wrapper for the Ranlux random number generator.
	 */
	public static double random() {

		if (ranlux == null) {
			Date d = new Date();
			ranlux = new Ranlux(d);
		}

		return ranlux.raw();
	}

	/**
	 * Pick an integer from the power law distribution.
	 * 
	 * @param max
	 *            Maximum integer we are allowed to pick.
	 * @param total
	 *            The sum of 1/i for i=1..max (assumed correct)
	 * @return An integer in the range 0..max-1
	 */
	public static int pickPowerLawFast(int max, double total) {

		double picked = random() * total;
		int i = 1;

		while (picked > 1.0 / i) {
			picked -= 1.0 / i;
			i++;
		}

		if (i - 1 > max) {
			System.err.println("modelling.Utils picked too large a value (" + i
					+ " vs " + max + ")");
			return max;
		}

		return i - 1;

	}

	/**
	 * Pick an integer from the power law distribution.
	 * 
	 * @param max
	 *            Maximum integer we are allowed to pick.
	 * @return An integer in the range 0..max-1
	 */
	public static int pickPowerLaw(int max) {

		double total = 0;
		int i;

		if (max == last_max) {
			total = last_total;
		} else {
			for (i = 1; i <= max; i++) {
				total += 1.0 / i;
			}
			last_max = max;
			last_total = total;
		}

		return pickPowerLawFast(max, total);
	}

	/**
	 * Pick an integer uniformly in 0..max-1
	 * 
	 * @param max
	 *            The maximum we can pick, plus 1.
	 * @return An integer in the range 0..max-1
	 */
	public static int pickUniformly(int max) {

		return (int) (random() * max);
	}

	/**
	 * Pick an integer in the range 0..thrws, with a binomial distribution. The
	 * expected value is p*thrws.
	 * 
	 * @param thrws
	 *            The maximum value we can pick.
	 * @param p
	 *            Determines the expected value returns.
	 * @return An integer in the range 0..thrws.
	 */
	public static int pickBinomial(int thrws, double p) {

		int i;
		int n = 0;

		for (i = 0; i < thrws; i++) {
			if (random() > p)
				n++;
		}

		return n;
	}
}
