package edu.cornell.cs.osmot.modelling.usage;

import java.util.Arrays;
import java.util.StringTokenizer;

import edu.cornell.cs.osmot.modelling.usage.Utils;

/**
 * This class implements topics, which are sets of words. Each word is an
 * integer.
 * 
 * @author Filip Radlinski
 * @version 1.0, April 2005
 */

public class Topic {

	private long topicId;

	private int words[];

	/*
	 * Offsets[id] is a sum of 1/1 through 1/id to speed up picking words.
	 */
	private double offsets[];

	private int numWords;

	private double maxOffset;

	/**
	 * Add a word to the topic, only used by the constructor.
	 */
	private void addWord(int wordId) {

		words[numWords] = wordId;
		if (numWords == 0)
			offsets[numWords] = 1.0 / (wordId + 1);
		else
			offsets[numWords] = offsets[numWords - 1] + 1.0 / (wordId + 1);
		maxOffset = offsets[numWords];

		numWords++;
	}

	/**
	 * Picks a word randomly from the topic, from something close to a Zipf
	 * distribution.
	 * 
	 * We pick each word with probability proportional to 1/word id. This tries
	 * to ensure that overall words obey a Zipf distribution. Note however than
	 * within the topic, when we pick a word this distribution is not obeyed
	 * because not all words are present in the topic. If one word with low id
	 * is present, it will be picked more often than we may expect.
	 * 
	 * @return A word in the topic.
	 */
	public int pickWord() {

		double picked = Utils.random() * maxOffset;

		for (int i = 0; i < numWords; i++) {
			if (picked < offsets[i])
				return words[i];
		}

		return words[numWords - 1];

	}

	/**
	 * Returns the id of this topic (a unique identifier).
	 * 
	 * @return The id of this topic.
	 */
	public long getId() {
		return topicId;
	}

	/**
	 * Creates a topic with the given id from the SparseVector provided. This
	 * allows us to load topics saved previously. This is the only way we do it
	 * here since this is only modelling code given a document collection from
	 * somewhere else.
	 * 
	 * @param id
	 *            The topic id.
	 * @param sparseVector
	 *            A string describing the topic in the form word_id:1.0
	 *            word_id:1.0 ...
	 */
	public Topic(int id, String sparseVector) {

		topicId = id;
		numWords = 0;
		maxOffset = 0;

		StringTokenizer st = new StringTokenizer(sparseVector);

		int length = st.countTokens();
		words = new int[length];
		offsets = new double[length];

		while (st.hasMoreTokens()) {
			String token = st.nextToken();
			String[] results = token.split(":");
			addWord(Integer.parseInt(results[0]));
		}

		// Make sure words are sorted
		Arrays.sort(words);
	}

}
