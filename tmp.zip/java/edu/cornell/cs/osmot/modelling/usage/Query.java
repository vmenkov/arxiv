package edu.cornell.cs.osmot.modelling.usage;

import java.util.Arrays;

/**
 * The Query class represents a query, which is a set of integers. Each integer
 * represents a word. Each word is allowed to occur at most once.
 * 
 * @author Filip Radlinski
 * @version 1.0, April 2005
 */

public class Query {

	private int words[];

	private int numWords;

	/**
	 * Return the number of words in the query.
	 * 
	 * @return The number of words in the query.
	 */
	public int getLength() {
		return numWords;
	}

	/**
	 * Appends a new word to the query. Only used by constructor.
	 * 
	 * @param wordId
	 *            The word to add.
	 * @return True if the word was added, false if it was already present.
	 */
	private boolean addWord(int wordId) {

		for (int i = 0; i < numWords; i++) {
			if (words[i] == wordId) {
				return false;
			}
		}

		// Add the word, update the size
		words[numWords] = wordId;
		numWords++;

		return true;
	}

	/**
	 * Returns the 2-norm of the query.
	 * 
	 * @return The 2-norm of the query.
	 */
	public double getSize() {
		return Math.sqrt(numWords);
	}

	/**
	 * Returns the word at the position specified.
	 * 
	 * @param pos
	 *            The position of the word.
	 * @return The word at that position, or -1 if the position is invalid.
	 */
	public int getWord(int pos) {
		if (pos >= 0 && pos < numWords)
			return words[pos];
		else
			return -1;
	}

	/**
	 * Creates a query of the given length for the given topic.
	 * 
	 * @param size
	 *            The length of the query.
	 * @param t
	 *            The topic of the query.
	 */
	public Query(int size, Topic t) {

		this.words = new int[size];
		this.numWords = 0;

		for (int i = 0; i < size; i++)
			words[i] = -1;

		int i = 0;
		while (i < size) {
			if (addWord(t.pickWord()))
				i++;
		}

		Arrays.sort(this.words);
	}

	/**
	 * Returns the query as a string (used for logging).
	 * 
	 * @return The query as a string.
	 */
	public String toString() {

		String theString = "";

		for (int i = 0; i < words.length; i++) {
			theString += words[i] + " ";
		}

		return theString;
	}

}
