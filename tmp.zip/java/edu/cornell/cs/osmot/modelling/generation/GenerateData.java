package edu.cornell.cs.osmot.modelling.generation;

import java.util.Iterator;
import java.util.TreeSet;
import java.util.SortedSet;
import java.io.PrintWriter;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import edu.cornell.cs.osmot.modelling.usage.Utils;

public class GenerateData {

	private static boolean debug = false;
	
	// Small Set: 500 words, 8 topics, 80 words per topic, 200 documents, 24
	// words per doc, max 4 topics per doc.
	//  if no overlap: 60 words per topic
	//  if more overlap: 100 words per topic
	// Medium Set: 2000 words, 40 topics, 100 words per topic, 5k documents, 48
	// words per doc, max 4 topics per doc.
	//  if no overlap: 45 words per topic
	//  if more overlap: 150 words per topic
	// Large Set: 50k words, 1k topics, 100 words per topic, 50k documents, 48
	// words per doc, max 4 topics per doc.
	//  if no overlap: 45 words per topic
	//  if more overlap: 150 words per topic

	// Number of words in our vocabulary
	public static int NUM_WORDS = 2000;

	// Number of topics
	public static int NUM_TOPICS = 40;

	// Number of words per topic
	public static int WORDS_PER_TOPIC = 100;

	// Number of documents
	public static int NUM_DOCUMENTS = 5000;

	// Length of each topic in each document
	public static int WORDS_PER_DOCUMENT = 48;

	// Number of topics per document (max)
	public static int MAX_TOPICS_PER_DOCUMENT = 4;

	// Set to true if we want to force the topics to be disjoint
	public static boolean DISJOINT = false;

	// Prints out the average overlap between topics.
	private static void printOverlaps(Topic topics[]) {

		double avgOverlap = 0;
		int pairCount = 0;

		// Don't measure overlap if more than 20 topics.
		if (topics.length > 20)
			return;
		
		// For every pair of topics
		for (int i = 0; i < topics.length; i++) {
			for (int j = 0; j < i; j++) {

				// Measure overlap
				int overlap = 0;
				Iterator iter = topics[i].getWordIterator();
				while (iter.hasNext()) {
					Word w = (Word) iter.next();
					if (topics[j].getWordValue(w.getWord()) != 0)
						overlap++;
				}

				avgOverlap += overlap;
				pairCount++;

				//System.out.println("Overlap of "+i+" and "+j+" is "+overlap+"
				// words.");

			}
		}

		avgOverlap /= pairCount;
		System.out.println("The average overlap is " + 1.0 * avgOverlap
				/ WORDS_PER_TOPIC);
	}

	// Write everything to a file
	private static void writeFiles(Document documents[], String docFilename,
			String labelFilename, Topic topics[], String topicFilename,
			Word wordIdfs[], String idfFilename) throws IOException {

		PrintWriter docFile = new PrintWriter(new BufferedWriter(
				new FileWriter(docFilename)));
		PrintWriter topicFile = new PrintWriter(new BufferedWriter(
				new FileWriter(labelFilename)));
		for (int d = 0; d < NUM_DOCUMENTS; d++) {

			topicFile.println(documents[d].getRelevantTopics());

			// Print the documents normalized (thats what the true does)
			docFile.println(documents[d].toString(true));
		}
		docFile.close();
		topicFile.close();

		// Write out the words in each topic to file
		topicFile = new PrintWriter(new BufferedWriter(new FileWriter(
				topicFilename)));
		for (int t = 0; t < NUM_TOPICS; t++) {
			topicFile.println(topics[t].toString(false));
		}
		topicFile.close();

		// Write the IDF scores to a file
		PrintWriter idfFile = new PrintWriter(new BufferedWriter(
				new FileWriter(idfFilename)));

		for (int w = 0; w < NUM_WORDS; w++) {
			idfFile.println(wordIdfs[w].getValue());
		}
		idfFile.close();

		printOverlaps(topics);
	}

	// Make a document
	private static Document newDocument(Topic topics[]) {

		Document d = new Document();

		// Work out number of topics
		int numTopics = Utils.pickBinomial(MAX_TOPICS_PER_DOCUMENT, 0.5);

		if (numTopics == 0) {

			// We picked 0 topics. So select words totally randomly.
			for (int w = 0; w < WORDS_PER_DOCUMENT; w++) {
				d.addWord(Utils.pickPowerLaw(NUM_WORDS));
			}
		} else {

			// There is a non-zero number of topics. Pick the words
			// appropriately.
			for (int t = 0; t < numTopics; t++) {

				int topic = Utils.pickPowerLaw(NUM_TOPICS);

				//System.out.println("Picked topic "+topic);
				d.addRelevantTopic(topic);

				// Count the number of total relevant documents for this topic.
				if (numTopics == 1)
					topics[topic].addRelevant();

				// Pick words from topic (assume
				// WORDS_PER_DOCUMENT is dividible by topics,
				// always)
				for (int w = 0; w < (WORDS_PER_DOCUMENT / numTopics); w++) {
					d.addWord(topics[topic].pickWord());
				}
			}
		} // End of check if 0 topics

		return d;
	}

	// Print out how often each word occurs in the topics (for debugging)
	private static void topicStats(Topic[] t) {

		int count[] = new int[NUM_WORDS];

		for (int i = 0; i < NUM_WORDS; i++) {
			boolean occurs = false;
			for (int j = 0; j < t.length; j++) {
				if (t[j].getWordValue(i) != 0) {
					occurs = true;
					count[i]++;
				}
			}
			if (occurs)
				System.out.println(i + ": " + count[i]);
		}

	}

	// Generate all the topics
	private static Topic[] generateTopics() {

		Topic topics[] = new Topic[NUM_TOPICS];

		// If we have set DISJOINT, we maintain a list of words that are still
		// free.
		TreeSet freeWords = new TreeSet();
		for (int i = 0; i < NUM_WORDS; i++)
			freeWords.add(new Integer(i));

		// For each topic, pick words
		for (int t = 0; t < NUM_TOPICS; t++) {

			topics[t] = new Topic();

			// Pick out the words in the topic
			int numWords = 0;
			while (numWords < WORDS_PER_TOPIC) {

				// Pick a word
				int i = Utils.pickUniformly(NUM_WORDS);

				// If its not yet in the topic
				if (topics[t].getWordValue(i) == 0) {

					// If we have DISJOINT set, map the picked word to the first
					// free word
					// (we might have most words already taken, so this speeds
					// things up a
					// lot). We find the first word bigger than i that is free.
					// If none bigger, take the smallest word available.
					// Then remove the word chosen from the list of free words.
					if (DISJOINT) {
						Integer word;
						if (((Integer) freeWords.last()).intValue() >= i) {
							SortedSet tmpTS = freeWords.tailSet(new Integer(i));
							word = (Integer) tmpTS.first();
						} else {
							word = (Integer) freeWords.first();
						}
						i = word.intValue();
						freeWords.remove(word);
					}

					topics[t].addWord(i);
					numWords++;
				}
			}
		}
		System.out.println("");

		return topics;
	}

	// Main loop
	public static void doEverything(String docFile, String labelFile,
			String topicFile, String idfFile) throws IOException {

		System.out.println("Generating topics...");
		Topic topics[] = generateTopics();

		if (debug)
			topicStats(topics);
		
		System.out.println("Generating documents...");
		Document documents[] = new Document[NUM_DOCUMENTS];

		int relevanceCount[] = new int[MAX_TOPICS_PER_DOCUMENT + 1];
		for (int d = 0; d < NUM_DOCUMENTS; d++) {
			if (d % 1000 == 0)
				System.out.print(d + " ");
			documents[d] = newDocument(topics);
			relevanceCount[documents[d].numTopics()]++;
		}
		System.out.println("");
		for (int i = 0; i < relevanceCount.length; i++)
			System.out.println("  Number of docs relevant to " + i
					+ " topics: " + relevanceCount[i]);

		int missingCount = 0;
		for (int t = 0; t < NUM_TOPICS; t++) {
			if (topics[t].numRelevant() == 0) {
				missingCount++;
				System.out
						.println("Warning: No totally relevant documents to topic "
								+ t);
			}
		}
		if (missingCount > 0)
			System.out.println("To summarize: " + missingCount
					+ " topics have no totally relevant documents.");

		// Now normalize the documents with TFIDF scores

		// First, work out the IDF for each word
		System.out.println("Computing IDF scores.");

		// The value will store the IDF of each word.
		Word wordIdfs[] = new Word[NUM_WORDS];

		for (int w = 0; w < NUM_WORDS; w++) {
			wordIdfs[w] = new Word(w, 0);
		}

		for (int d = 0; d < NUM_DOCUMENTS; d++) {
			Iterator i = documents[d].getWordIterator();
			while (i.hasNext()) {
				Word w = (Word) i.next();
				wordIdfs[w.getWord()].incValue();
			}
		}

		for (int w = 0; w < NUM_WORDS; w++) {
			wordIdfs[w].setValue(1.0 / wordIdfs[w].getValue());
		}

		// Next, update the word scores

		System.out.println("Computing real document word scores.");

		for (int d = 0; d < NUM_DOCUMENTS; d++) {

			if (d % 1000 == 0)
				System.out.print(d + " ");

			// For every word in document, compute the TFIDF scores
			Iterator i = documents[d].getWordIterator();
			while (i.hasNext()) {
				Word w = (Word) i.next();
				int wordId = w.getWord();
				double oldValue = w.getValue();

				double tfidf = Math.log(oldValue + 1)
						* wordIdfs[wordId].getValue();
				w.setValue(tfidf);

				//boolean test = documents[d].setWordValue(wordId,
				// Math.log(oldValue+1) * wordIdfs[wordId].getValue());
				//if (!test) {
				//    System.err.println("Error: setWordValue failed");
				//}
			}
		}

		System.out.println("");
		System.out.println("Saving documents and topics.");

		// Write the documents to a file
		writeFiles(documents, docFile, labelFile, topics, topicFile, wordIdfs,
				idfFile);

		// Print out the topic stats
		//topicStats(topics);
	}

	public static void main(String args[]) throws IOException {

		// Sanity check
		if (NUM_TOPICS * WORDS_PER_TOPIC > NUM_WORDS && DISJOINT) {
			System.err
					.println("Error: Asked for disjoint topics but there aren't enough words.");
			System.exit(1);
		}

		// We generate 10 sets of documents for 10 really independent
		// trials when evaluating the method (we want to be
		// independent of the document collection too!
		for (int i = 1; i <= 10; i++) {
			System.out.println("Iteration " + i);
			String docFilename = "documents.iter" + i + ".dat";
			String labelFilename = "document_labels.iter" + i + ".dat";
			String topicFilename = "topics.iter" + i + ".dat";
			String idfFilename = "idf_scores.iter" + i + ".dat";
			doEverything(docFilename, labelFilename, topicFilename, idfFilename);
		}		
	}
}
