package edu.cornell.cs.osmot.modelling.generation;

import edu.cornell.cs.osmot.modelling.usage.Utils;

import java.util.Iterator;

/**
 * This class represents a topic. Its like a document except also has methods to
 * help pick words from the topic with Zipf distribution.
 * 
 * @author Filip Radlinski
 * @version 1.0, April 2005
 */

public class Topic extends Document {

	private double maxValue;

	private int numRelevant;

	public Topic() {
		maxValue = 0;
		numRelevant = 0;
	}

	/**
	 * Add a word to the topic. We do some housekeeping used in picking words in
	 * addition to the usual add.
	 * 
	 * @param wordId
	 *            The ID of the word to add
	 */
	public void addWord(int wordId) {
		maxValue += 1.0 / (wordId + 1);

		super.addWord(wordId);
	}

	/**
	 * Pick a word from the topic. The probability any given word is picked is
	 * proportional to 1/(wordId+1).
	 */
	public int pickWord() {

		Iterator i = words.iterator();
		double picked = Utils.random() * maxValue;

		while (i.hasNext()) {
			Word w = (Word) i.next();
			picked -= 1.0 / (w.getWord() + 1);
			if (picked <= 0)
				return w.getWord();
		}

		System.err.println("Error in word picking code.");
		return -1;
	}

	/** Mark that this topic has a relevant document. */
	public void addRelevant() {
		numRelevant++;
	}

	/**
	 * Return how many relevant documents there are for this topic.
	 * 
	 * @return The number of documents relevant to this topic.
	 */
	public int numRelevant() {
		return numRelevant;
	}
}
