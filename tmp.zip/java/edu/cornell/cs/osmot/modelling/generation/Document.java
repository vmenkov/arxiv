package edu.cornell.cs.osmot.modelling.generation;

import java.util.Iterator;
import java.util.TreeSet;

/**
 * This class represents a document.
 * 
 * @author Filip Radlinski
 * @version 1.0, April 2005
 */

public class Document {

	// The words in this document
	public TreeSet words;

	private TreeSet topics;

	private boolean sizeValid;

	private double size;

	private int numTopics;

	public Document() {
		words = new TreeSet();
		topics = new TreeSet();
		size = 0;
		sizeValid = true;
	}

	/**
	 * Return an iterator over the set of words for this document.
	 * 
	 * @return An iterator over the set of words for this document.
	 */
	public Iterator getWordIterator() {
		return words.iterator();
	}

	/**
	 * Add a word to this document. If the word is already present, its weight
	 * is increased by 1.
	 * 
	 * @param wordId
	 *            The word to add.
	 */
	public void addWord(int wordId) {

		double value;
		Word newWord = new Word(wordId, 1);
		Word oldWord = null;

		sizeValid = false;

		value = 1;

		if (words.tailSet(newWord).isEmpty() != true)
			oldWord = (Word) words.tailSet(newWord).first();

		// If the word was already there
		if (oldWord != null && oldWord.getWord() == wordId) {
			value += oldWord.getValue();
			words.remove(oldWord);
		}

		newWord.setValue(value);
		words.add(newWord);
	}

	/** Returns the 2-norm of the document. */
	public double getSize() {

		if (sizeValid == false) {
			sizeValid = true;
			size = 0;

			Iterator i = words.iterator();
			while (i.hasNext()) {
				Word w = (Word) i.next();
				size += w.getValue() * w.getValue();
			}

			size = Math.sqrt(size);
		}

		return size;
	}

	/**
	 * Return the weight of this word in the document. Return 0 if the word is
	 * not in the document.
	 */
	public double getWordValue(int wordId) {

		Word word = new Word(wordId, 1);
		Word word2 = null;

		if (words.tailSet(word).isEmpty() != true)
			word2 = (Word) words.tailSet(word).first();

		if (word2 != null && word2.getWord() == wordId)
			return word2.getValue();

		return 0;
	}

	/**
	 * Set the value for a given word in this document.
	 * 
	 * @param wordId
	 *            The id of the word whose value you want to adjust.
	 * @param newValue
	 *            The new value for this word.
	 * @return true on success, false if the word was not in the document.
	 */
	public boolean setWordValue(int wordId, double newValue) {

		Word word;

		word = new Word(wordId, newValue);

		if (words.tailSet(word).isEmpty() != true)
			word = (Word) words.tailSet(word).first();
		else
			return false;

		if (word != null && word.getWord() == wordId) {
			words.remove(word);
			word.setValue(newValue);
			words.add(word);
		} else {
			return false;
		}

		return true;
	}

	/** Return a string version of this document (word ids in sorted order) */
	public String toString(boolean normalized) {
		String result = "";
		Iterator i = words.iterator();

		while (i.hasNext()) {
			Word w = (Word) i.next();
			if (w.getValue() != 0) {
				result += w.getWord() + ":";
				if (normalized)
					result += w.getValue() / getSize();
				else
					result += w.getValue();
				result += " ";
			}
		}

		return result;
	}

	/**
	 * A document belongs to multiple topics. This adds a new topic the document
	 * is marked as relevant to.
	 * 
	 * @param topicId
	 *            The topic this document is now relevant to.
	 */
	public void addRelevantTopic(int topicId) {

		// We use words where the wordId represents the topicId, and the value
		// is the
		// number of topics the topic was added.

		double value;
		Word newTopic = new Word(topicId, 1);
		Word oldTopic = null;

		numTopics++;

		value = 1;

		if (topics.tailSet(newTopic).isEmpty() != true)
			oldTopic = (Word) topics.tailSet(newTopic).first();

		// If the word was already there
		if (oldTopic != null && oldTopic.getWord() == topicId) {
			value += oldTopic.getValue();
			topics.remove(oldTopic);
		}

		newTopic.setValue(value);
		topics.add(newTopic);
	}

	/**
	 * Lists the relevance to different topics.
	 * 
	 * @return A string with the relevant topics and their relevance.
	 */
	public String getRelevantTopics() {

		String result = "";
		Iterator i = topics.iterator();

		while (i.hasNext()) {
			Word t = (Word) i.next();
			result += t.getWord() + ":" + (t.getValue() / numTopics) + " ";
		}

		return result;
	}

	/**
	 * Returns the number of topics this document is relevant to.
	 * 
	 * @return The number of topics this document is relevant to.
	 */
	public int numTopics() {
		return numTopics;
	}

}
